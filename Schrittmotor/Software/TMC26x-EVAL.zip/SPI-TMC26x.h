/****************************************************
  Projekt: TMC26x

  Modul:   SPI-TMC26x.h
           Funktionen f�r das SPI-Interface

  Datum:   23.3.2007 OK
*****************************************************/

#ifndef __SPI_TMC26x_H
#define __SPI_TMC26x_H

void InitSPI(void);
UCHAR ReadWriteSPI(UCHAR DeviceNumber, UCHAR Data, UCHAR LastTransfer);

#endif
