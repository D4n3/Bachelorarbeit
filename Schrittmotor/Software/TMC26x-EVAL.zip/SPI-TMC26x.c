/****************************************************
  Projekt: TMC26x

  Modul:   SPI-TMC26x.c
           Funktionen f�r das SPI-Interface

  Datum:   23.3.2007 OK
*****************************************************/

#include "at91sam7x256.h"
#include "bits.h"
#include "TMC26x.h"


/*******************************************************************
   Funktion: InitSPI()
   Parameter: ---

   Zweck: Initialisierung des SPI
********************************************************************/
void InitSPI(void)
{
  //Clock f�r SPI einschalten
  AT91C_BASE_PMC->PMC_PCER=1 << AT91C_ID_SPI0;

  //SPI-Pins verbinden
  AT91C_BASE_PIOA->PIO_PDR=BIT18|BIT17|BIT16|BIT12;
  AT91C_BASE_PIOA->PIO_ASR=BIT18|BIT17|BIT16|BIT12;

  //SPI konfigurieren
  AT91C_BASE_SPI0->SPI_CR=AT91C_SPI_SWRST|AT91C_SPI_SPIEN;  //SPI-Reset
  AT91C_BASE_SPI0->SPI_CR=AT91C_SPI_SWRST|AT91C_SPI_SPIEN;  //SPI-Reset (zweimal wegen Rev. B Erratum)
  AT91C_BASE_SPI0->SPI_CR=AT91C_SPI_SPIEN;   //SPI ist eingeschaltet
  AT91C_BASE_SPI0->SPI_MR=AT91C_SPI_MODFDIS|AT91C_SPI_PS_VARIABLE|AT91C_SPI_MSTR;  //Master Mode, Chip Select ohne Dekoder
                                                                                                    //MODFDIS ist hier sehr wichtig!!!
  AT91C_BASE_SPI0->SPI_CSR[0]=AT91C_SPI_CPOL|AT91C_SPI_CSAAT|(24<<8);  //2MBit (Device 0)
  AT91C_BASE_SPI0->SPI_CSR[1]=AT91C_SPI_CPOL|AT91C_SPI_CSAAT|(24<<8);  //2MBit (Device 1)
  AT91C_BASE_SPI0->SPI_CSR[2]=AT91C_SPI_CPOL|AT91C_SPI_CSAAT|(24<<8);  //2MBit (Device 2)
  AT91C_BASE_SPI0->SPI_CSR[3]=AT91C_SPI_CPOL|AT91C_SPI_CSAAT|(24<<8);  //2MBit (Device 3)
}


/*******************************************************************
   Funktion: ReadWriteSPI
   Parameter: DeviceNumber: Ger�tenummer (s. Konstanten in SDNG.h)
              Data: Zu sendendes Byte
              LastTransfer: FALSE: Ger�t bleibt nach dem Transfer selektiert (f�r weitere Transfers)
                            TRUE: Ger�t wird nach dem Transfer deselektiert
   Zweck: Senden/Empfangen �ber SPI
********************************************************************/
UCHAR ReadWriteSPI(UCHAR DeviceNumber, UCHAR Data, UCHAR LastTransfer)
{
  //Transfer initiieren
  if(LastTransfer)
    AT91C_BASE_SPI0->SPI_TDR=(DeviceNumber<<16)|Data|AT91C_SPI_LASTXFER;
  else
    AT91C_BASE_SPI0->SPI_TDR=(DeviceNumber<<16)|Data;

  //Warte bis Transfer beendet (Byte empfangen)
  while((AT91C_BASE_SPI0->SPI_SR & AT91C_SPI_RDRF)==0);

  //Empfangenes Byte zur�ckgeben
  return AT91C_BASE_SPI0->SPI_RDR & 0xff;
}
