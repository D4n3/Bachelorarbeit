/****************************************************
  Projekt: TMC26x

  Modul:   UART-TMC26x.h
           UART-Funktionen (Bytes Senden/Empfangen)

  Datum:   23.3.2007 OK
*****************************************************/

#ifndef __UART_TMC26x_H
#define __UART_TMC26x_H

#define UART_BUFFER_SIZE 32

void InitUART(UCHAR Baudrate);
void WriteUART(UCHAR ch);
UINT ReadUART(UCHAR *ch);
UINT CheckUARTTimeout(void);
void SetUARTTransmitDelay(UINT Delay);

void InitSecondaryUART(UCHAR Baudrate);
void WriteSecondaryUART(UCHAR ch);
UINT ReadSecondaryUART(UCHAR *ch);
UINT CheckSecondaryUARTTimeout(void);
void SetSecondaryUARTTransmitDelay(UINT Delay);

#endif
