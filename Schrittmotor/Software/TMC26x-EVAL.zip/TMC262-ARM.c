/****************************************************
  Projekt: TMC26x

  Modul:   TMC262-ARM.c
           Zugriffsfunktionen f�r den TMC262

  Datum:   12.11.2009 OK
*****************************************************/
//#define COOL_STEP_DEMO

#include "bits.h"
#include "at91sam7x256.h"
#include <stdlib.h>

#include "TMC26x.h"
#include "SPI-TMC26x.h"
#include "TMC262-ARM.h"
#include "Systimer-TMC26x.h"


//Datenstrukturen f�r Softwarekopien der TMC262-Register
typedef struct
{
  UCHAR APolarity;  //nur bei TMC259-FPGA
  UCHAR BPolarity;  //nur bei TMC259-FPGA
  UCHAR NPolarity;  //nur bei TMC259-FPGA
  UCHAR NContinous; //nur bei TMC259-FPGA
  UCHAR ClearOnN;   //nur bei TMC259-FPGA
  UCHAR Intpol;
  UCHAR DEdge;
  UCHAR MRes;
} TStepDirConfig;

typedef struct
{
  UCHAR BlankTime;
  UCHAR ChopperMode;
  UCHAR HysteresisDecay;
  UCHAR RandomTOff;
  UCHAR HysteresisEnd;
  UCHAR HysteresisStart;
  UCHAR TOff;
  UCHAR DisableFlag;
} TChopperConfig;

typedef struct
{
  UCHAR SmartIMin;
  UCHAR SmartDownStep;
  UCHAR SmartStallLevelMax;
  UCHAR SmartUpStep;
  UCHAR SmartStallLevelMin;
} TSmartEnergyControl;

typedef struct
{
  UCHAR FilterEnable;
  signed char StallGuardThreshold;
  UCHAR CurrentScale;
} TStallGuardConfig;


typedef struct
{
  UCHAR TestMode;
  UCHAR SlopeHighSide;
  UCHAR SlopeLowSide;
  UCHAR ProtectionDisable;
  UCHAR ProtectionTimer;
  UCHAR StepDirectionDisable;
  UCHAR VSenseScale;
  UCHAR ReadBackSelect;
} TDriverConfig;


//Variablen
static TStepDirConfig StepDirConfig[N_O_MOTORS];           //Softwarekopien der DRVCTRL-Register aller Treiberchips
static TChopperConfig ChopperConfig[N_O_MOTORS];           //Softwarekopien der CHOPCONF-Register aller Treiberchips
static TSmartEnergyControl SmartEnergyControl[N_O_MOTORS]; //Softwarekopien der SMARTEN-Register aller Treiberchips
static TStallGuardConfig StallGuardConfig[N_O_MOTORS];     //Softwarekopien der SGSCONF-Register aller Treiberchips
static TDriverConfig DriverConfig[N_O_MOTORS];             //Softwarekopien der DRVCONF-Register aller Treiberchips
static UINT SPIReadInt;
static UINT SPIWriteInt;

static UINT SPIStepDirConf;
static UINT SPIChopperConf;
static UINT SPISmartConf;
static UINT SPISGConf;
static UINT SPIDriverConf;

static UINT RandomRegister;
static UINT RandomTimer;


//Funktionen

/*******************************************************************
   Funktion: ReadWrite262()
   Parameter: Which428: Auswahl des TMC262 bei Modulen mit mehr als 1 Achse
              Read: Zeiger auf Integer f�r das Ergebnis
              Write: Array mit drei Bytes die in den TMC262
                     hineingeschrieben werden sollen.

   R�ckgabewert: ---

   Zweck: SPI-Kommunikation mit dem TMC262. Die Telegramme werden gleich
          an die richtigen Positionen geschoben.
********************************************************************/
static void ReadWrite262(UCHAR Which262, UINT *ReadInt, UINT WriteInt)
{
  *ReadInt=ReadWriteSPI(SPI_DEV_TMC26x, WriteInt >> 16, FALSE);
  *ReadInt<<=8;
  *ReadInt|=ReadWriteSPI(SPI_DEV_TMC26x, WriteInt >> 8, FALSE);
  *ReadInt<<=8;
  *ReadInt|=ReadWriteSPI(SPI_DEV_TMC26x, WriteInt & 0xff, TRUE);
  *ReadInt>>=4;
}


/*******************************************************************
   Funktion: WriteStepDirConfig()
   Parameter: Which262: Auswahl des TMC262 bei Modulen mit mehr als 1 Achse

   R�ckgabewert: ---

   Zweck: Beschreiben des DRVCTRL-Registers des TMC262 im Step/Dir-Modus.
          Die Parameeter m�ssen in der globalen Variablen StepDirConfig
          stehen.
********************************************************************/
static void WriteStepDirConfig(UCHAR Which262)
{
  SPIWriteInt=0;
  if(StepDirConfig[Which262].Intpol) SPIWriteInt|=BIT9;
  if(StepDirConfig[Which262].DEdge) SPIWriteInt|=BIT8;
  if(StepDirConfig[Which262].MRes>15) StepDirConfig[Which262].MRes=15;
  SPIWriteInt|=StepDirConfig[Which262].MRes;

  ReadWrite262(Which262, &SPIReadInt, SPIWriteInt);
  SPIStepDirConf=SPIWriteInt;
}


/*******************************************************************
   Funktion: WriteChopperConfig()
   Parameter: Which262: Auswahl des TMC262 bei Modulen mit mehr als 1 Achse

   R�ckgabewert: ---

   Zweck: Beschreiben des CHOPCONF-Registers des TMC262.
          Die Parameter m�ssen in der globalen Variablen ChopperConfig
          stehen.
********************************************************************/
static void WriteChopperConfig(UCHAR Which262)
{
  if(ChopperConfig[Which262].BlankTime>3) ChopperConfig[Which262].BlankTime=3;
  if(ChopperConfig[Which262].HysteresisDecay>3) ChopperConfig[Which262].HysteresisDecay=3;
  if(ChopperConfig[Which262].HysteresisEnd>15) ChopperConfig[Which262].HysteresisEnd=15;
  if(ChopperConfig[Which262].HysteresisStart>7) ChopperConfig[Which262].HysteresisStart=7;
  if(ChopperConfig[Which262].TOff>15) ChopperConfig[Which262].TOff=15;

  SPIWriteInt=0;
  SPIWriteInt|=BIT19;  //Registeraddresse CHOPCONF;
  SPIWriteInt|=((UINT) ChopperConfig[Which262].BlankTime) << 15;
  if(ChopperConfig[Which262].ChopperMode) SPIWriteInt|=BIT14;
  if(ChopperConfig[Which262].RandomTOff) SPIWriteInt|=BIT13;
  SPIWriteInt|=((UINT) ChopperConfig[Which262].HysteresisDecay) << 11;
  SPIWriteInt|=((UINT) ChopperConfig[Which262].HysteresisEnd) << 7;
  SPIWriteInt|=((UINT) ChopperConfig[Which262].HysteresisStart) << 4;
  if(!ChopperConfig[Which262].DisableFlag) SPIWriteInt|=((UINT) ChopperConfig[Which262].TOff);  //wenn DisableFlag gesetzt wird 0 gesendet

  ReadWrite262(Which262, &SPIReadInt, SPIWriteInt);
  SPIChopperConf=SPIWriteInt;
}


/*******************************************************************
   Funktion: WriteSmartEnergyControl()
   Parameter: Which262: Auswahl des TMC262 bei Modulen mit mehr als 1 Achse

   R�ckgabewert: ---

   Zweck: Beschreiben des DRVCTRL-Registers des TMC262.
          Die Parameter m�ssen in der globalen Variablen SmartEnergyControl
          stehen.
********************************************************************/
static void WriteSmartEnergyControl(UCHAR Which262)
{
  if(SmartEnergyControl[Which262].SmartIMin>1) SmartEnergyControl[Which262].SmartIMin=1;
  if(SmartEnergyControl[Which262].SmartDownStep>3) SmartEnergyControl[Which262].SmartDownStep=3;
  if(SmartEnergyControl[Which262].SmartStallLevelMax>15) SmartEnergyControl[Which262].SmartStallLevelMax=15;
  if(SmartEnergyControl[Which262].SmartUpStep>3) SmartEnergyControl[Which262].SmartUpStep=3;
  if(SmartEnergyControl[Which262].SmartStallLevelMin>15) SmartEnergyControl[Which262].SmartStallLevelMin=15;

  SPIWriteInt=0;
  SPIWriteInt|=BIT19|BIT17;  //Registeradresse SMARTEN
  SPIWriteInt|=((UINT) SmartEnergyControl[Which262].SmartIMin) << 15;
  SPIWriteInt|=((UINT) SmartEnergyControl[Which262].SmartDownStep)  << 13;
  SPIWriteInt|=((UINT) SmartEnergyControl[Which262].SmartStallLevelMax) << 8;
  SPIWriteInt|=((UINT) SmartEnergyControl[Which262].SmartUpStep) << 5;
  SPIWriteInt|=((UINT) SmartEnergyControl[Which262].SmartStallLevelMin);

  ReadWrite262(Which262, &SPIReadInt, SPIWriteInt);
  SPISmartConf=SPIWriteInt;
}


/*******************************************************************
   Funktion: WriteStallGuardConfig()
   Parameter: Which262: Auswahl des TMC262 bei Modulen mit mehr als 1 Achse

   R�ckgabewert: ---

   Zweck: Beschreiben des SGCSCONF-Registers des TMC262.
          Die Parameter m�ssen in der globalen Variablen StallGuardConfig
          stehen.
********************************************************************/
static void WriteStallGuardConfig(UCHAR Which262)
{
  if(StallGuardConfig[Which262].StallGuardThreshold>63) StallGuardConfig[Which262].StallGuardThreshold=63;
  if(StallGuardConfig[Which262].StallGuardThreshold<-63) StallGuardConfig[Which262].StallGuardThreshold=-63;
  if(StallGuardConfig[Which262].CurrentScale>31) StallGuardConfig[Which262].CurrentScale=31;

  SPIWriteInt=0;
  SPIWriteInt|=BIT19|BIT18;  //Registeradresse SGSCONF
  if(StallGuardConfig[Which262].FilterEnable==1) SPIWriteInt|=BIT16;
  SPIWriteInt|=((UINT) StallGuardConfig[Which262].StallGuardThreshold & 0x7f) << 8;
  SPIWriteInt|=((UINT) StallGuardConfig[Which262].CurrentScale);

  ReadWrite262(Which262, &SPIReadInt, SPIWriteInt);
  SPISGConf=SPIWriteInt;
}


/*******************************************************************
   Funktion: WriteDriverConfig()
   Parameter: Which262: Auswahl des TMC262 bei Modulen mit mehr als 1 Achse

   R�ckgabewert: ---

   Zweck: Beschreiben des DRVCONF-Registers des TMC262.
          Die Parameter m�ssen in der globalen Variablen DriverConfig
          stehen.
********************************************************************/
static void WriteDriverConfig(UCHAR Which262)
{
  SPIWriteInt=0;
  SPIWriteInt|=BIT19|BIT18|BIT17;  //Registeradresse DRVCONF
  SPIWriteInt|=((UINT) DriverConfig[Which262].SlopeHighSide & 0x03) << 14;
  SPIWriteInt|=((UINT) DriverConfig[Which262].SlopeLowSide & 0x03) << 12;
  if(DriverConfig[Which262].ProtectionDisable==1) SPIWriteInt|=BIT10;
  SPIWriteInt|=((UINT) DriverConfig[Which262].ProtectionTimer & 0x03) << 8;
  if(DriverConfig[Which262].StepDirectionDisable==1) SPIWriteInt|=BIT7;
  if(DriverConfig[Which262].VSenseScale==1) SPIWriteInt|=BIT6;
  SPIWriteInt|=((UINT) DriverConfig[Which262].ReadBackSelect & 0x03) << 4;
  if(DriverConfig[Which262].TestMode==1) SPIWriteInt|=BIT16;

  ReadWrite262(Which262, &SPIReadInt, SPIWriteInt);
  SPIDriverConf=SPIWriteInt;
}


/*******************************************************************
   Funktion: InitMotorDriver()
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Initialisierung des TMC259/TMC262 und der Variablen
********************************************************************/
void InitMotorDrivers(void)
{
  UINT i;
  UINT t;
  UCHAR TMC262Flags;

  //Datenstrukturen intialisieren
  for(i=0; i<N_O_MOTORS; i++)
  {
    //Parameter "non cool"
#ifndef COOL_STEP_DEMO
    StallGuardConfig[i].FilterEnable=1;
    StallGuardConfig[i].StallGuardThreshold=2;
    StallGuardConfig[i].CurrentScale=7;

    DriverConfig[i].SlopeHighSide=3;
    DriverConfig[i].SlopeLowSide=3;
    DriverConfig[i].ProtectionDisable=0;
    DriverConfig[i].ProtectionTimer=0;
    DriverConfig[i].StepDirectionDisable=0;
    DriverConfig[i].VSenseScale=0;
    DriverConfig[i].ReadBackSelect=TMC262_RB_SMART_ENERGY;

    SmartEnergyControl[i].SmartIMin=0;
    SmartEnergyControl[i].SmartDownStep=0;
    SmartEnergyControl[i].SmartStallLevelMax=0;
    SmartEnergyControl[i].SmartUpStep=0;
    SmartEnergyControl[i].SmartStallLevelMin=0;

    StepDirConfig[i].Intpol=0;
    StepDirConfig[i].DEdge=0;
    StepDirConfig[i].MRes=0;

    ChopperConfig[i].BlankTime=2;
    ChopperConfig[i].ChopperMode=0;
    ChopperConfig[i].RandomTOff=0;
    ChopperConfig[i].HysteresisDecay=0;
    ChopperConfig[i].HysteresisEnd=3;
    ChopperConfig[i].HysteresisStart=3;
    ChopperConfig[i].TOff=5;
#else
    StallGuardConfig[i].FilterEnable=1;
    StallGuardConfig[i].StallGuardThreshold=2;
    StallGuardConfig[i].CurrentScale=31;

    DriverConfig[i].SlopeHighSide=3;
    DriverConfig[i].SlopeLowSide=3;
    DriverConfig[i].ProtectionDisable=0;
    DriverConfig[i].ProtectionTimer=0;
    DriverConfig[i].StepDirectionDisable=0;
    DriverConfig[i].VSenseScale=0;
    DriverConfig[i].ReadBackSelect=TMC262_RB_SMART_ENERGY;

    SmartEnergyControl[i].SmartIMin=0;
    SmartEnergyControl[i].SmartDownStep=3;
    SmartEnergyControl[i].SmartStallLevelMax=4;
    SmartEnergyControl[i].SmartUpStep=0;
    SmartEnergyControl[i].SmartStallLevelMin=2;

    StepDirConfig[i].Intpol=0;
    StepDirConfig[i].DEdge=0;
    StepDirConfig[i].MRes=2;

    ChopperConfig[i].BlankTime=2;
    ChopperConfig[i].ChopperMode=0;
    ChopperConfig[i].HysteresisDecay=0;
    ChopperConfig[i].HysteresisEnd=3;
    ChopperConfig[i].HysteresisStart=3;
    ChopperConfig[i].TOff=5;
#endif
  }

  ENABLE_DRIVERS();

  //Warten bsi TMC262 ansprechbar ist (durch Test des Stand-Still-Flags)
  RESET_WATCHDOG();
  do
  {
    Read262State(WHICH_262(0), NULL, NULL, NULL, NULL, &TMC262Flags);
  } while((TMC262Flags & 0x80)==0x00);

  //weitere 100ms warten
  RESET_WATCHDOG();
  t=GetSysTimer();
  while(abs(GetSysTimer()-t)<100);

  //Initialwerte zum TMC262 senden
  for(i=0; i<N_O_MOTORS; i++)
  {
    WriteSmartEnergyControl(WHICH_262(i));
    WriteStallGuardConfig(WHICH_262(i));
    WriteDriverConfig(WHICH_262(i));
    WriteStepDirConfig(WHICH_262(i));
    WriteChopperConfig(WHICH_262(i));
  }
}


void Set262StepDirMStepRes(UCHAR Which262, UCHAR MicrostepResolution)
{
  StepDirConfig[Which262].MRes=MicrostepResolution;
  if(MicrostepResolution!=4) StepDirConfig[Which262].Intpol=0;

  WriteStepDirConfig(Which262);
}

void Set262StepDirInterpolation(UCHAR Which262, UCHAR Interpolation)
{
  StepDirConfig[Which262].Intpol=Interpolation;
  if(Interpolation) StepDirConfig[Which262].MRes=4;

  WriteStepDirConfig(Which262);
}

void Set262StepDirDoubleEdge(UCHAR Which262, UCHAR DoubleEdge)
{
  StepDirConfig[Which262].DEdge=DoubleEdge;

  WriteStepDirConfig(Which262);
}

UCHAR Get262StepDirMStepRes(UCHAR Which262)
{
  return StepDirConfig[Which262].MRes;
}

UCHAR Get262StepDirInterpolation(UCHAR Which262)
{
  return StepDirConfig[Which262].Intpol;
}

UCHAR Get262StepDirDoubleEdge(UCHAR Which262)
{
  return StepDirConfig[Which262].DEdge;
}


void Set262ChopperBlankTime(UCHAR Which262, UCHAR BlankTime)
{
  ChopperConfig[Which262].BlankTime=BlankTime;
  WriteChopperConfig(Which262);
}

void Set262ChopperMode(UCHAR Which262, UCHAR Mode)
{
  ChopperConfig[Which262].ChopperMode=Mode;
  WriteChopperConfig(Which262);
}

void Set262ChopperRandomTOff(UCHAR Which262, UCHAR RandomTOff)
{
  ChopperConfig[Which262].RandomTOff=RandomTOff;
  WriteChopperConfig(Which262);
}

void Set262ChopperHysteresisDecay(UCHAR Which262, UCHAR HysteresisDecay)
{
  ChopperConfig[Which262].HysteresisDecay=HysteresisDecay;
  WriteChopperConfig(Which262);
}

void Set262ChopperHysteresisEnd(UCHAR Which262, UCHAR HysteresisEnd)
{
  ChopperConfig[Which262].HysteresisEnd=HysteresisEnd;
  WriteChopperConfig(Which262);
}

void Set262ChopperHysteresisStart(UCHAR Which262, UCHAR HysteresisStart)
{
  ChopperConfig[Which262].HysteresisStart=HysteresisStart;
  WriteChopperConfig(Which262);
}

void Set262ChopperTOff(UCHAR Which262, UCHAR TOff)
{
  ChopperConfig[Which262].TOff=TOff;
  WriteChopperConfig(Which262);
}

UCHAR Get262ChopperBlankTime(UCHAR Which262)
{
  return ChopperConfig[Which262].BlankTime;
}

UCHAR Get262ChopperMode(UCHAR Which262)
{
  return ChopperConfig[Which262].ChopperMode;
}

UCHAR Get262ChopperRandomTOff(UCHAR Which262)
{
  return ChopperConfig[Which262].RandomTOff;
}

UCHAR Get262ChopperHysteresisDecay(UCHAR Which262)
{
  return ChopperConfig[Which262].HysteresisDecay;
}

UCHAR Get262ChopperHysteresisEnd(UCHAR Which262)
{
  return ChopperConfig[Which262].HysteresisEnd;
}

UCHAR Get262ChopperHysteresisStart(UCHAR Which262)
{
  return ChopperConfig[Which262].HysteresisStart;
}

UCHAR Get262ChopperTOff(UCHAR Which262)
{
  return ChopperConfig[Which262].TOff;
}


void Set262SmartEnergyIMin(UCHAR Which262, UCHAR SmartIMin)
{
  SmartEnergyControl[Which262].SmartIMin=SmartIMin;
  WriteSmartEnergyControl(Which262);
}

void Set262SmartEnergyDownStep(UCHAR Which262, UCHAR SmartDownStep)
{
  SmartEnergyControl[Which262].SmartDownStep=SmartDownStep;
  WriteSmartEnergyControl(Which262);
}

void Set262SmartEnergyStallLevelMax(UCHAR Which262, UCHAR StallLevelMax)
{
  SmartEnergyControl[Which262].SmartStallLevelMax=StallLevelMax;
  WriteSmartEnergyControl(Which262);
}

void Set262SmartEnergyUpStep(UCHAR Which262, UCHAR SmartUpStep)
{
  SmartEnergyControl[Which262].SmartUpStep=SmartUpStep;
  WriteSmartEnergyControl(Which262);
}

void Set262SmartEnergyStallLevelMin(UCHAR Which262, UCHAR StallLevelMin)
{
  SmartEnergyControl[Which262].SmartStallLevelMin=StallLevelMin;
  WriteSmartEnergyControl(Which262);
}

UCHAR Get262SmartEnergyIMin(UCHAR Which262)
{
  return SmartEnergyControl[Which262].SmartIMin;
}

UCHAR Get262SmartEnergyDownStep(UCHAR Which262)
{
  return SmartEnergyControl[Which262].SmartDownStep;
}

UCHAR Get262SmartEnergyStallLevelMax(UCHAR Which262)
{
  return SmartEnergyControl[Which262].SmartStallLevelMax;
}

UCHAR Get262SmartEnergyUpStep(UCHAR Which262)
{
  return SmartEnergyControl[Which262].SmartUpStep;
}

UCHAR Get262SmartEnergyStallLevelMin(UCHAR Which262)
{
  return SmartEnergyControl[Which262].SmartStallLevelMin;
}


void Set262StallGuardFilter(UCHAR Which262, UCHAR Enable)
{
  StallGuardConfig[Which262].FilterEnable=Enable;
  WriteStallGuardConfig(Which262);
}

void Set262StallGuardThreshold(UCHAR Which262, signed char Threshold)
{
  StallGuardConfig[Which262].StallGuardThreshold=Threshold;
  WriteStallGuardConfig(Which262);
}

void Set262StallGuardCurrentScale(UCHAR Which262, UCHAR CurrentScale)
{
  StallGuardConfig[Which262].CurrentScale=CurrentScale;
  WriteStallGuardConfig(Which262);
}

UCHAR Get262StallGuardFilter(UCHAR Which262)
{
  return StallGuardConfig[Which262].FilterEnable;
}

signed char Get262StallGuardThreshold(UCHAR Which262)
{
  return StallGuardConfig[Which262].StallGuardThreshold;
}

UCHAR Get262StallGuardCurrentScale(UCHAR Which262)
{
  return StallGuardConfig[Which262].CurrentScale;
}


void Set262DriverSlopeHighSide(UCHAR Which262, UCHAR SlopeHighSide)
{
  DriverConfig[Which262].SlopeHighSide=SlopeHighSide;
  WriteDriverConfig(Which262);
}

void Set262DriverSlopeLowSide(UCHAR Which262, UCHAR SlopeLowSide)
{
  DriverConfig[Which262].SlopeLowSide=SlopeLowSide;
  WriteDriverConfig(Which262);
}

void Set262DriverDisableProtection(UCHAR Which262, UCHAR DisableProtection)
{
  DriverConfig[Which262].ProtectionDisable=DisableProtection;
  WriteDriverConfig(Which262);
}

void Set262DriverProtectionTimer(UCHAR Which262, UCHAR ProtectionTimer)
{
  DriverConfig[Which262].ProtectionTimer=ProtectionTimer;
  WriteDriverConfig(Which262);
}

void Set262DriverStepDirectionOff(UCHAR Which262, UCHAR SDOff)
{
  DriverConfig[Which262].StepDirectionDisable=SDOff;
  WriteDriverConfig(Which262);
}

void Set262DriverVSenseScale(UCHAR Which262, UCHAR Scale)
{
  DriverConfig[Which262].VSenseScale=Scale;
  WriteDriverConfig(Which262);
}

void Set262DriverReadSelect(UCHAR Which262, UCHAR ReadSelect)
{
  DriverConfig[Which262].ReadBackSelect=ReadSelect;
  WriteDriverConfig(Which262);
}

void Set262DriverTestMode(UCHAR Which262, UCHAR TestMode)
{
  DriverConfig[Which262].TestMode=TestMode;
  WriteDriverConfig(Which262);
}

UCHAR Get262DriverSlopeHighSide(UCHAR Which262)
{
  return DriverConfig[Which262].SlopeHighSide;
}

UCHAR Get262DriverSlopeLowSide(UCHAR Which262)
{
  return DriverConfig[Which262].SlopeLowSide;
}

UCHAR Get262DriverDisableProtection(UCHAR Which262)
{
  return DriverConfig[Which262].ProtectionDisable;
}

UCHAR Get262DriverProtectionTimer(UCHAR Which262)
{
  return DriverConfig[Which262].ProtectionTimer;
}

UCHAR Get262DriverStepDirectionOff(UCHAR Which262)
{
  return DriverConfig[Which262].StepDirectionDisable;
}

UCHAR Get262DriverVSenseScale(UCHAR Which262)
{
  return DriverConfig[Which262].VSenseScale;
}

UCHAR Get262DriverReadSelect(UCHAR Which262)
{
  return DriverConfig[Which262].ReadBackSelect;
}

UCHAR Get262DriverTestMode(UCHAR Which262)
{
  return DriverConfig[Which262].TestMode;
}

/*******************************************************************
   Funktion: Read262State()
   Parameter: Which262: Achsenummer
              Phases: Zeiger auf Variable f�r Zustand der Phasenbits
              MStep: Zeiger auf Variable f�r Mikroschrittposition
              StallGuard: Zeiger auf Variable f�r StallGuard
              SmartEnergy: Zeiger auf Variable f�r SmartEnergy
              Flags: Zeiger auf Variable f�r Fehlerflags

   R�ckgabewert: ---

   Zweck: Auslesen des Zustands TMC259/TMC262. Abh�ngig von RDSEL werden
          die zur�ckgelesenen Werte entsprechend aus dem SPI-Telegramm
          extrahiert.
          F�r Werte, die nicht ben�tigt werden, kann NULL eingesetzt
          werden.
********************************************************************/
void Read262State(UCHAR Which262, UCHAR *Phases, UCHAR *MStep, UINT *StallGuard, UCHAR *SmartEnergy, UCHAR *Flags)
{
  WriteDriverConfig(Which262);

  switch(DriverConfig[Which262].ReadBackSelect)
  {
    case TMC262_RB_MSTEP:
      if(Phases!=NULL) *Phases=SPIReadInt >> 18;
      if(MStep!=NULL) *MStep=SPIReadInt >> 10;
      break;

    case TMC262_RB_STALL_GUARD:
      if(StallGuard!=NULL) *StallGuard=SPIReadInt >> 10;
      break;

    case TMC262_RB_SMART_ENERGY:
      if(StallGuard!=NULL)
      {
        *StallGuard=SPIReadInt >> 15;
        *StallGuard<<=5;
      }
      if(SmartEnergy!=NULL)
      {
        *SmartEnergy=(SPIReadInt >> 10) & 0x1f;
      }
      break;
  }

  if(Flags!=NULL) *Flags=SPIReadInt & 0xff;
}


/*******************************************************************
   Funktion: Disable262()
   Parameter: Which262: Achsenummer

   R�ckgabewert: ---

   Zweck: Motor stromlos schalten. Dies wird erreicht durch Setzen
          der TOff-Zeit auf 0 (wobei nat�rlich der zuletzt mit
          Set262ChopperTOff() gesetzte Wert erhalten bleibt).
********************************************************************/
void Disable262(UCHAR Which262)
{
  ChopperConfig[Which262].DisableFlag=TRUE;
  WriteChopperConfig(Which262);
}


/*******************************************************************
   Funktion: Enable262()
   Parameter: Which262: Achsenummer

   R�ckgabewert: ---

   Zweck: Motor einschalten. Dies wird erreicht durch Setzen
          der TOff-Zeit auf den zuletzt mit Set262ChopperTOff()
          eingestellten Wert.
********************************************************************/
void Enable262(UCHAR Which262)
{
  ChopperConfig[Which262].DisableFlag=FALSE;
  WriteChopperConfig(Which262);
}


/*******************************************************************
   Funktion: Read259Encoder()
   Parameter: Which259: Achsenummer

   R�ckgabewert: Encoderz�hler des TMC259 (geht nicht beim TMC26x!)

   Zweck: Encoderz�hler auslesen. Dies ist nur bei der FPGA-Version
          des TMC259 m�glich!
********************************************************************/
int Read259Encoder(UCHAR Which259)
{
  UCHAR ReadBackSelect;
  int Encoder;

  //Umschalten des Read Back Mode auf Encoder (wenn nicht schon geschehen)
  ReadBackSelect=Get262DriverReadSelect(Which259);
  if(ReadBackSelect!=TMC262_RB_ENCODER) Set262DriverReadSelect(Which259, TMC262_RB_ENCODER);

  //Abfragen des Encodez�hlers
  WriteDriverConfig(Which259);
  Encoder=SPIReadInt;
  if(Encoder & BIT19) Encoder|=0xfff00000;

  //Zur�ckschalten des Read Back Mode auf den vorherigen Wert
  if(ReadBackSelect!=TMC262_RB_ENCODER) Set262DriverReadSelect(Which259, ReadBackSelect);

  //Encoderwert zur�ckgeben
  return Encoder;
}


/*******************************************************************
   Funktion: Set259EncoderOptions()
   Parameter: Which259: Achsenummer
              APolarity: Polarit�t Kanal A bei Nulldurchgang
              BPolarity: Polarit�t Kanal B bei Nulldurchgang
              NPolarity: Polarit�t Kanal N bei Nulldurchgang
              NContinous: L�schen bei jedem Nulldurchgang
              ClearOnN:  L�schen beim n�chsten Nulldurchgang

   R�ckgabewert: ---

   Zweck: Optionen f�r das Encoder-Interface einstellen. Dies ist
          nur beim TMCM259-FPGA m�glich!
********************************************************************/
void Set259EncoderOptions(UCHAR Which262, UCHAR APolarity, UCHAR BPolarity, UCHAR NPolarity,
                          UCHAR NContinous, UCHAR ClearOnN)
{
  StepDirConfig[Which262].APolarity=APolarity;
  StepDirConfig[Which262].BPolarity=BPolarity;
  StepDirConfig[Which262].NPolarity=NPolarity;
  StepDirConfig[Which262].NContinous=NContinous;
  StepDirConfig[Which262].ClearOnN=ClearOnN;

  WriteStepDirConfig(Which262);
}


void GetSPIData(UCHAR Index, int *Data)
{
  switch(Index)
  {
    case 0:
      *Data=SPIReadInt;
      break;

    case 1:
      *Data=SPIStepDirConf;
      break;

    case 2:
      *Data=SPIChopperConf;
      break;

    case 3:
      *Data=SPISmartConf;
      break;

    case 4:
      *Data=SPISGConf;
      break;

    case 5:
      *Data=SPIDriverConf;
      break;
  }
}


void RandomTOff(void)
{
  UCHAR x;
  UCHAR TOff;

  if(abs(GetSysTimer()-RandomTimer)>0)
  {
    x=(RandomRegister>>8) & 0x81;

    if(x==0x80 || x==0x01)
      RandomRegister=RandomRegister << 1;
    else
      RandomRegister=(RandomRegister << 1)+1;

    TOff=ChopperConfig[0].TOff;
    if(RandomRegister & BIT0)
    {
      if(ChopperConfig[0].TOff<15) ChopperConfig[0].TOff+=1;
      LED_ON();
    }
    else LED_OFF();
    WriteChopperConfig(0);

    ChopperConfig[0].TOff=TOff;
    RandomTimer=GetSysTimer();
  }
}
