/****************************************************
  Projekt: TMC26x

  Modul:   Systimer-TMC26x.h
           System-Timer (1ms-Takt).

  Datum:   29.3.2007 OK
*****************************************************/

#ifndef __SYSTIMER_TMC26x_H
#define __SYSTIMER_TMC26x_H

UINT GetSysTimer(void);
void InitSysTimer(void);

#endif
