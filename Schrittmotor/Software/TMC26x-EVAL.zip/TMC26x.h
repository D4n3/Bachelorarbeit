/*************************************************
  Projekt: TMC26x

  Modul:   TMC26x.h
           Allgemeine Definitionen

  Datum:   22.4.2009 OK
**************************************************/

#ifndef __TMC26x_H
#define __TMC26x_H

typedef unsigned char UCHAR;
typedef unsigned short USHORT;
typedef unsigned int UINT;

#define FASTRUN __attribute__ ((long_call, section (".fastrun")))

#define TRUE 1
#define FALSE 0

#define MIN(a,b) (a<b) ? (a) : (b)
#define MAX(a,b) (a>b) ? (a) : (b)

#define TIMER_INTERRUPT_PRIORITY 7
#define UART_INTERRUPT_PRIORITY 6
#define ADC_INTERRUPT_PRIORITY 5
#define SYS_INTERRUPT_PRIORITY 0

#define RESET_WATCHDOG() AT91C_BASE_WDTC->WDTC_WDCR=(0xA5 << 24)|AT91C_WDTC_WDRSTT

#define SPI_DEV_TMC26x 0x00

#define LED_ON() (AT91C_BASE_PIOA->PIO_CODR=BIT7)
#define LED_OFF() (AT91C_BASE_PIOA->PIO_SODR=BIT7)
#define LED_STATE() (!(AT91C_BASE_PIOA->PIO_ODSR & BIT7))

#define USB_MONITOR() (AT91C_BASE_PIOA->PIO_PDSR & BIT29)
#define USB_PULLUP_OFF() AT91C_BASE_PIOA->PIO_CODR=BIT30
#define USB_PULLUP_ON()  AT91C_BASE_PIOA->PIO_SODR=BIT30

#define SW_TYPE_HIGH 0x01
#define SW_TYPE_LOW 0x06
#define SW_VERSION_HIGH 1
#define SW_VERSION_LOW 2

#define SAMPLING_BUFFER_SIZE 3000

#define N_O_MOTORS 1

#define ENABLE_DRIVERS() AT91C_BASE_PIOA->PIO_CODR=BIT11
#define DISABLE_DRIVERS() AT91C_BASE_PIOA->PIO_SODR=BIT11
#define WHICH_262(a) (a)

#define RM_VELOCITY  0
#define RM_POSITION  1

//Allgemeine Funktionen
extern void AT91F_DisableInterrupts(void);
extern void AT91F_EnableInterrupts(void);

#endif
