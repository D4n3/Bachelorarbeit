/*************************************************
  Projekt: TMC26x

  Modul:   TMC26x-Main.c
           Hauptprogramm f�r das TMC26x Eval

  Datum:   25.1.2010 OK
**************************************************/

//Includes & Defines
#include "at91sam7x256.h"
#include "bits.h"
#include <stdlib.h>

#include "TMC26x.h"
#include "SPI-TMC26x.h"
#include "UART-TMC26x.h"
#include "USB-TMC26x.h"
#include "Systimer-TMC26x.h"
#include "TMC26x-Commands.h"
#include "TMC262-ARM.h"
#include "StepDirIrq-TMC26x.h"


//Globale Variablen
volatile int Dummy;  //f�r Dummy-Reads bestimmter I/O-Register

extern volatile UINT ActualAcceleration;
extern volatile int TargetVelocity;

const char *VersionString="262V1.02";

//Funktionen

/*******************************************************************
   Funktion: InitIO
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Initialisierung der I/O-Ports
********************************************************************/
void InitIO(void)
{
  RESET_WATCHDOG();

  //Clock-Ausgang f�r den TMC262 einschalten mit Vorteiler (Main Clock/1 (16Mhz))
  AT91C_BASE_PIOB->PIO_PDR=BIT22;
  AT91C_BASE_PIOB->PIO_BSR=BIT22;
  AT91C_BASE_PMC->PMC_SCER=AT91C_PMC_PCK2;
  AT91C_BASE_PMC->PMC_PCKR[2]=AT91C_PMC_PRES_CLK|AT91C_PMC_CSS_MAIN_CLK;   //16Mhz an PCK2 (PB22)

  //Externen Reset erm�glichen
  AT91C_BASE_RSTC->RSTC_RMR = 0xA5000001;

  //Clock f�r PIOA und PIOB einschalten
  AT91C_BASE_PMC->PMC_PCER=1 << AT91C_ID_PIOA;
  AT91C_BASE_PMC->PMC_PCER=1 << AT91C_ID_PIOB;

  //Initialisierung der PIO A
  AT91C_BASE_PIOA->PIO_PER=BIT30|BIT29|BIT28|BIT27|BIT26|BIT25|BIT24|BIT23|BIT22|BIT21|BIT20|BIT19|BIT15|BIT14|BIT13|BIT11|BIT10|BIT9|BIT8|
                           BIT7|BIT6|BIT5|BIT4|BIT3|BIT2;
  AT91C_BASE_PIOA->PIO_OER=BIT30|BIT28|BIT26|BIT25|BIT22|BIT21|BIT20|BIT19|BIT15|BIT14|BIT13|BIT11|BIT9|BIT8|
                           BIT7|BIT6|BIT5|BIT4|BIT3|BIT2;
  AT91C_BASE_PIOA->PIO_ODR=BIT29|BIT27|BIT24|BIT23|BIT10;  //STEP und DIR sind zun�chst deaktiviert (f�r externes Step/Dir-Signal)
  AT91C_BASE_PIOA->PIO_CODR=BIT30|BIT26|BIT25|BIT24|BIT23|BIT22|BIT21|BIT20|BIT19|BIT15|BIT14|BIT13|BIT11|BIT9|BIT8|
                            BIT7|BIT6|BIT5|BIT4|BIT3|BIT2;
  AT91C_BASE_PIOA->PIO_PPUDR=BIT24|BIT23|BIT10;

  //Initialisierung der PIO B
  AT91C_BASE_PIOB->PIO_PER=BIT30|BIT29|BIT28|BIT27|BIT26|BIT25|BIT24|BIT23|BIT21|BIT20|BIT19|BIT18|BIT17|BIT16|BIT15|BIT14|BIT13|BIT12|
                           BIT11|BIT10|BIT9|BIT8|BIT7|BIT6|BIT5|BIT4|BIT3|BIT2|BIT1|BIT0;
  AT91C_BASE_PIOB->PIO_OER=BIT30|BIT29|BIT28|BIT27|BIT26|BIT25|BIT24|BIT23|BIT21|BIT20|BIT19|BIT18|BIT17|BIT16|BIT15|BIT14|BIT13|BIT12|
                           BIT11|BIT10|BIT9|BIT8|BIT7|BIT6|BIT5|BIT4|BIT3|BIT2|BIT1|BIT0;
  AT91C_BASE_PIOB->PIO_CODR=BIT30|BIT29|BIT28|BIT27|BIT26|BIT25|BIT24|BIT23|BIT21|BIT20|BIT19|BIT18|BIT17|BIT16|BIT15|BIT14|BIT13|BIT12|
                            BIT11|BIT10|BIT9|BIT8|BIT7|BIT6|BIT5|BIT4|BIT3|BIT2|BIT1|BIT0;
}


//Hauptprogramm
int main(void)
{
  UINT BlinkDelay;
  UINT i;
  UINT Count1;
  UINT Count2;
  UINT DemoMode;

  //Initialisierung
  InitIO();
  InitSPI();
  InitUART(7);
  InitUSB();
  InitSysTimer();
  InitStepDirIrq();

  //Pr�fen, ob die Pins RxD und TxD der RS232-Schnittstelle miteinander verbunden sind.
  //Wenn ja: Zur�cksetzen des Moduls auf Werkseinstellungen.
  Count1=Count2=0;
  for(i=0; i<10; i++)
  {
    AT91C_BASE_PIOA->PIO_CODR=BIT28;
    for(Dummy=0; Dummy<1000; Dummy++);
    if(!(AT91C_BASE_PIOA->PIO_PDSR & BIT27)) Count1++;

    AT91C_BASE_PIOA->PIO_SODR=BIT28;
    for(Dummy=0; Dummy<1000; Dummy++);
    if((AT91C_BASE_PIOA->PIO_PDSR & BIT27)) Count2++;
  }
  if(Count1==10 && Count2==10)
    DemoMode=TRUE;
  else
    DemoMode=FALSE;


  //Erste Initialisierungssequenz f�r den TMC262
/*  ReadWriteSPI(SPI_DEV_TMC259, 0x09, FALSE);
  ReadWriteSPI(SPI_DEV_TMC259, 0x01, FALSE);
  ReadWriteSPI(SPI_DEV_TMC259, 0xb5, TRUE);

  ReadWriteSPI(SPI_DEV_TMC259, 0x0c, FALSE);
  ReadWriteSPI(SPI_DEV_TMC259, 0x02, FALSE);
  ReadWriteSPI(SPI_DEV_TMC259, 0x1f, TRUE);

  ReadWriteSPI(SPI_DEV_TMC259, 0x0e, FALSE);
  ReadWriteSPI(SPI_DEV_TMC259, 0xf0, FALSE);
  ReadWriteSPI(SPI_DEV_TMC259, 0x00, TRUE);*/

  InitMotorDrivers();

  if(DemoMode)
  {
    Set262StepDirInterpolation(0, 1);
    Set262StepDirMStepRes(0, 4);
    Set262SmartEnergyIMin(0, 1);
    Set262SmartEnergyDownStep(0, 2);
    Set262SmartEnergyStallLevelMax(0, 2);
    Set262SmartEnergyUpStep(0, 0);
    Set262SmartEnergyStallLevelMin(0, 1);
    Set262StallGuardFilter(0, 1);

    ActivateStepDir();
    ActualAcceleration=10000;
    TargetVelocity=10000;
  }

  BlinkDelay=0;

  //Hauptschleife
  for(;;)
  {
    RESET_WATCHDOG();

    ProcessCommands();

    //Blinken der LED
    if(abs(GetSysTimer()-BlinkDelay)>5000)
    {
      if(LED_STATE())
        LED_OFF();
      else
        LED_ON();

      BlinkDelay=GetSysTimer();
    }
  }

  return 0;
}
