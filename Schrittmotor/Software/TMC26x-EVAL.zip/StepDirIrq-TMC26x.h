/****************************************************
  Projekt: TMC262

  Modul:   StepDirIrq-TMC26x.h
           Erzeugen eines Step/Dir-Signals f�r den
           TMC262 (interruptgesteuert).

  Datum:   18.11.2009 OK
*****************************************************/

#ifndef __STEP_DIR_IRQ_TMC26x_H
#define __STEP_DIR_IRQ_TMC26x_H

void InitStepDirIrq(void);
void ActivateStepDir(void);

#endif
