/****************************************************
  Projekt: TMC26x

  Modul:   USB-TMC26x.h
           USB-Funktionen (Bytes Senden/Empfangen)

  Datum:   29.8.2008 OK
*****************************************************/

#ifndef __USB_TMC26x_H
#define __USB_TMC26x_H

void InitUSB(void);
UCHAR GetUSBCmd(UCHAR *USBCmd);
UCHAR SendUSBReply(UCHAR *USBReply);
UINT GetUSBBuffer(UCHAR *USBCmd);
UCHAR SendUSBBuffer(UCHAR *Buffer, UINT Length);
UCHAR ReadUSBChar(UCHAR *InputChar);
void WriteUSBChar(UCHAR OutputChar, UCHAR WaitForCR);

#endif
