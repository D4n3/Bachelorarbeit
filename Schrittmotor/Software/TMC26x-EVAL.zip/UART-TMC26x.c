/****************************************************
  Projekt: TMC26x

  Modul:   UART-TMC26x.c
           UART-Funktionen (Bytes Senden/Empfangen)

  Datum:   23.3.2007 OK
*****************************************************/

#include "at91sam7x256.h"
#include "bits.h"
#include "TMC26x.h"
#include "UART-TMC26x.h"

//Puffer f�r UART
extern volatile UCHAR UARTRxBuffer[UART_BUFFER_SIZE];
extern volatile UCHAR UARTTxBuffer[UART_BUFFER_SIZE];
extern volatile UINT UARTRxReadPtr, UARTRxWritePtr, UARTTxReadPtr, UARTTxWritePtr;
extern volatile UCHAR UARTTimeoutFlag;
extern volatile UINT UARTTxDelay;

//Interrupt Handler (siehe UARTIrq-ARM.c)
extern void UARTInterruptHandler(void);

volatile UCHAR UARTRxBuffer1[UART_BUFFER_SIZE];
volatile UCHAR UARTTxBuffer1[UART_BUFFER_SIZE];
volatile UINT UARTRxReadPtr1, UARTRxWritePtr1, UARTTxReadPtr1, UARTTxWritePtr1;
volatile UCHAR UARTTimeoutFlag1;
volatile UINT UARTTxDelay1;
volatile UINT UARTTxDelayTimer1;

extern void UARTInterruptHandler1(void);




/*******************************************************************
   Funktion: InitUART()
   Parameter: Baudrate: Code f�r Baudrate

   Zweck: Intialisierung der UART
********************************************************************/
void InitUART(UCHAR Baudrate)
{
  UARTRxReadPtr=0;
  UARTRxWritePtr=0;
  UARTTxReadPtr=0;
  UARTTxWritePtr=0;

  //Clock f�r UART0 einschalten
  AT91C_BASE_PMC->PMC_PCER=1 << AT91C_ID_US0;

  //RxD und TxD auf die entsprechenden Pins legen
  AT91C_BASE_PIOA->PIO_PDR=BIT1|BIT0;
  AT91C_BASE_PIOA->PIO_ASR=BIT1|BIT0;

  //Baudrate setzen
  switch(Baudrate)
  {
    case 0:
      AT91C_BASE_US0->US_BRGR = 312|(4<<16); //((48000000)/9600x16) 312.5 (ergibt genau 9600)
      AT91C_BASE_US0->US_RTOR = 48;  //Timeout ca. 5ms bei 9600 bps (f�r andere Baudraten Wert anpassen!)
      break;

    case 1:
      AT91C_BASE_US0->US_BRGR = 208|(3<<16); //14400 bps  (208.3333, also 208.375, ergibt 14397)
      AT91C_BASE_US0->US_RTOR = 72;  //Timeout ca. 5ms
      break;

    case 2:
      AT91C_BASE_US0->US_BRGR = 156|(2<<16); //19200 bps  (156.25, ergibt genau 19200)
      AT91C_BASE_US0->US_RTOR = 96;  //Timeout ca. 5ms
      break;

    case 3:
      AT91C_BASE_US0->US_BRGR = 104|(1<<16); //28800 bps  (104.16666, also 104.125, ergibt 28811)
      AT91C_BASE_US0->US_RTOR = 144;  //Timeout ca. 5ms
      break;

    case 4:
      AT91C_BASE_US0->US_BRGR = 78|(1<<16);  //38400 bps  (78.125, ergibt genau 38400)
      AT91C_BASE_US0->US_RTOR = 192; //Timeout ca. 5ms
      break;

    case 5:
      AT91C_BASE_US0->US_BRGR = 52|(1<<16);  //57600 bps  (52.083333, 52.125 ergibt 57553, 52 w�rde 57693 ergeben)
      AT91C_BASE_US0->US_RTOR = 288; //Timeout ca. 5ms
      break;

    case 6:
      AT91C_BASE_US0->US_BRGR = 39;  //76800 bps  (39.0625, 39 ergibt 76923, 39.125 ergibt 76677)
      AT91C_BASE_US0->US_RTOR = 384; //Timeout ca. 5ms
      break;

    case 7:
      AT91C_BASE_US0->US_BRGR = 26;   //115200 bps (26.041666, 26 ergibt 115384)
      AT91C_BASE_US0->US_RTOR = 576;  //Timeout ca. 5ms
      break;

    case 8:
      AT91C_BASE_US0->US_BRGR = 13;    //230400 bps (13.0208333, 13 ergibt 230769)
      AT91C_BASE_US0->US_RTOR = 1152;  //Timeout ca. 5ms
      break;

    case 9:
      AT91C_BASE_US0->US_BRGR = 12;   //250000 bps  (12 ergibt genau 250000)
      AT91C_BASE_US0->US_RTOR = 1250; //Timeout ca. 5ms
      break;

    case 10:
      AT91C_BASE_US0->US_BRGR = 6;    //500000 bps  (6 ergibt genau 500000)
      AT91C_BASE_US0->US_RTOR = 2500; //Timeout ca. 5ms
      break;

    case 11:
      AT91C_BASE_US0->US_BRGR = 3;    //1000000 bps  (3 ergibt genau 1000000)
      AT91C_BASE_US0->US_RTOR = 5000; //Timeout ca. 5ms
      break;

    default:
      AT91C_BASE_US0->US_BRGR = 312|(4<<16); //((48000000)/9600x16) 312.5 (ergibt genau 9600)
      AT91C_BASE_US0->US_RTOR = 48;  //Timeout ca. 5ms bei 9600 bps (f�r andere Baudraten Wert anpassen!)
      break;
  }

  AT91C_BASE_US0->US_TTGR = 0;     //Transmitter Time Guard est einmal aus
  AT91C_BASE_US0->US_MR = 0x08c1;  //8N1, RS485-Modus
  AT91C_BASE_US0->US_CR = 0x0050;  //Receiver und Transmitter sowie Receiver-Timeout einschalten

  //Interrupthandler setzen und aktivieren
  AT91C_BASE_AIC->AIC_IDCR=1<<AT91C_ID_US0;
  AT91C_BASE_AIC->AIC_SVR[AT91C_ID_US0]=(unsigned int) UARTInterruptHandler;
  AT91C_BASE_AIC->AIC_SMR[AT91C_ID_US0]=UART_INTERRUPT_PRIORITY|AT91C_AIC_SRCTYPE_INT_HIGH_LEVEL;
  AT91C_BASE_AIC->AIC_ICCR=1<<AT91C_ID_US0;

  //Interrupt erst einmal nur f�r Empfangen (f�r Senden wird sp�ter eingeschaltet, wenn Daten im Sendepuffer sind)
  AT91C_BASE_US0->US_IER=AT91C_US_RXRDY;

  //USART0-Interrupt im AIC einschalten
  AT91C_BASE_AIC->AIC_IECR = 1<<AT91C_ID_US0;
}


/*******************************************************************
   Funktion: WriteUART()
   Parameter: ch: Zu schreibendes Zeichen

   Zweck: Senden eines Zeichens �ber UART
          (Einstellen in den Sendepuffer)
********************************************************************/
void WriteUART(UCHAR ch)
{
  UINT i;

  //Zeichen in die Warteschlange stellen
  i=UARTTxWritePtr+1;
  if(i==UART_BUFFER_SIZE) i=0;

  if(i!=UARTTxReadPtr)
  {
    UARTTxBuffer[UARTTxWritePtr]=ch;
    UARTTxWritePtr=i;

    //Sendeinterrupt aktivieren
    AT91C_BASE_US0->US_IER=AT91C_US_TXRDY;
  }
}


/*******************************************************************
   Funktion: ReadUART()
   Parameter: *ch: Zeiger auf Variable f�r zu lesendes Zeichen

   R�ckgabewert: TRUE bei Erfolg
                 FALSE wenn kein Zeichen da war
   Zweck: Lesen eines Zeichens aus dem Empfangspuffer
          (Einstellen in den Sendepuffer)
********************************************************************/
UINT ReadUART(UCHAR *ch)
{
  //Kein Zeichen vorhanden?
  if(UARTRxReadPtr==UARTRxWritePtr) return FALSE;

  //Zeichen aus dem Puffer holen
  *ch=UARTRxBuffer[UARTRxReadPtr++];
  if(UARTRxReadPtr==UART_BUFFER_SIZE)  UARTRxReadPtr=0;

  return TRUE;
}


/*******************************************************************
   Funktion: CheckUARTTimeout()
   Parameter: ---

   R�ckgabewert: TRUE wenn zwischenzeitlich ein Timeout aufgetreten ist
                 FALSE wenn kein Timeout aufgetreten ist
   Zweck: Pr�fen, ob beim Empfangen ein Timeout aufgetreten ist (also
          Zeit zwischen zwei Bytes >5ms) und Zur�cksetzen des
          Timeout-Flags.
********************************************************************/
UINT CheckUARTTimeout(void)
{
  if(UARTTimeoutFlag)
  {
    UARTTimeoutFlag=FALSE;
    return TRUE;
  }
  else return FALSE;
}


/*******************************************************************
   Funktion: SetUARTTransmitDelay()
   Parameter: Delay: Sendeverz�gerung in ms

   R�ckgabewert: ---

   Zweck: Setzen der Sendeverz�gerung
          (f�r einige RS485-Adapter wichtig)
********************************************************************/
void SetUARTTransmitDelay(UINT Delay)
{
  UARTTxDelay=Delay;
}



/*******************************************************************
   Funktion: InitUART1()
   Parameter: Baudrate: Code f�r Baudrate

   Zweck: Intialisierung der UART 1
********************************************************************/
void InitSecondaryUART(UCHAR Baudrate)
{
  UARTRxReadPtr1=0;
  UARTRxWritePtr1=0;
  UARTTxReadPtr1=0;
  UARTTxWritePtr1=0;

  //Clock f�r UART1 einschalten
  AT91C_BASE_PMC->PMC_PCER=1 << AT91C_ID_US1;

  //RxD, TxD und RTS auf die entsprechenden Pins legen
  AT91C_BASE_PIOA->PIO_PDR=BIT8|BIT6|BIT5;
  AT91C_BASE_PIOA->PIO_ASR=BIT8|BIT6|BIT5;

  //Baudrate setzen
  switch(Baudrate)
  {
    case 0:
      AT91C_BASE_US1->US_BRGR = 312|(4<<16); //((48000000)/9600x16) 312.5 (ergibt genau 9600)
      AT91C_BASE_US1->US_RTOR = 48;  //Timeout ca. 5ms bei 9600 bps (f�r andere Baudraten Wert anpassen!)
      break;

    case 1:
      AT91C_BASE_US1->US_BRGR = 208|(3<<16); //14400 bps  (208.3333, also 208.375, ergibt 14397)
      AT91C_BASE_US1->US_RTOR = 72;  //Timeout ca. 5ms
      break;

    case 2:
      AT91C_BASE_US1->US_BRGR = 156|(2<<16); //19200 bps  (156.25, ergibt genau 19200)
      AT91C_BASE_US1->US_RTOR = 96;  //Timeout ca. 5ms
      break;

    case 3:
      AT91C_BASE_US1->US_BRGR = 104|(1<<16); //28800 bps  (104.16666, also 104.125, ergibt 28811)
      AT91C_BASE_US1->US_RTOR = 144;  //Timeout ca. 5ms
      break;

    case 4:
      AT91C_BASE_US1->US_BRGR = 78|(1<<16);  //38400 bps  (78.125, ergibt genau 38400)
      AT91C_BASE_US1->US_RTOR = 192; //Timeout ca. 5ms
      break;

    case 5:
      AT91C_BASE_US1->US_BRGR = 52|(1<<16);  //57600 bps  (52.083333, 52.125 ergibt 57553, 52 w�rde 57693 ergeben)
      AT91C_BASE_US1->US_RTOR = 288; //Timeout ca. 5ms
      break;

    case 6:
      AT91C_BASE_US1->US_BRGR = 39;  //76800 bps  (39.0625, 39 ergibt 76923, 39.125 ergibt 76677)
      AT91C_BASE_US1->US_RTOR = 384; //Timeout ca. 5ms
      break;

    case 7:
      AT91C_BASE_US1->US_BRGR = 26;   //115200 bps (26.041666, 26 ergibt 115384)
      AT91C_BASE_US1->US_RTOR = 576;  //Timeout ca. 5ms
      break;

    case 8:
      AT91C_BASE_US1->US_BRGR = 13;    //230400 bps (13.0208333, 13 ergibt 230769)
      AT91C_BASE_US1->US_RTOR = 1152;  //Timeout ca. 5ms
      break;

    case 9:
      AT91C_BASE_US1->US_BRGR = 12;   //250000 bps  (12 ergibt genau 250000)
      AT91C_BASE_US1->US_RTOR = 1250; //Timeout ca. 5ms
      break;

    case 10:
      AT91C_BASE_US1->US_BRGR = 6;    //500000 bps  (6 ergibt genau 500000)
      AT91C_BASE_US1->US_RTOR = 2500; //Timeout ca. 5ms
      break;

    case 11:
      AT91C_BASE_US1->US_BRGR = 3;    //1000000 bps  (3 ergibt genau 1000000)
      AT91C_BASE_US1->US_RTOR = 5000; //Timeout ca. 5ms
      break;

    default:
      AT91C_BASE_US1->US_BRGR = 312|(4<<16); //((48000000)/9600x16) 312.5 (ergibt genau 9600)
      AT91C_BASE_US1->US_RTOR = 48;  //Timeout ca. 5ms bei 9600 bps (f�r andere Baudraten Wert anpassen!)
      break;
  }

  AT91C_BASE_US1->US_TTGR = 0;     //Transmitter Time Guard est einmal aus
  AT91C_BASE_US1->US_MR = 0x08c1;  //8N1, RS485-Modus
  AT91C_BASE_US1->US_CR = 0x0050;  //Receiver und Transmitter sowie Receiver-Timeout einschalten

  //Interrupthandler setzen und aktivieren
  AT91C_BASE_AIC->AIC_IDCR=1<<AT91C_ID_US1;
  AT91C_BASE_AIC->AIC_SVR[AT91C_ID_US1]=(unsigned int) UARTInterruptHandler1;
  AT91C_BASE_AIC->AIC_SMR[AT91C_ID_US1]=UART_INTERRUPT_PRIORITY|AT91C_AIC_SRCTYPE_INT_HIGH_LEVEL;
  AT91C_BASE_AIC->AIC_ICCR=1<<AT91C_ID_US1;

  //Interrupt erst einmal nur f�r Empfangen (f�r Senden wird sp�ter eingeschaltet, wenn Daten im Sendepuffer sind)
  AT91C_BASE_US1->US_IER=AT91C_US_RXRDY;

  //USART0-Interrupt im AIC einschalten
  AT91C_BASE_AIC->AIC_IECR = 1<<AT91C_ID_US1;
}


/*******************************************************************
   Funktion: WriteUART()
   Parameter: ch: Zu schreibendes Zeichen

   Zweck: Senden eines Zeichens �ber UART
          (Einstellen in den Sendepuffer)
********************************************************************/
void WriteSecondaryUART(UCHAR ch)
{
  UINT i;

  //Zeichen in die Warteschlange stellen
  i=UARTTxWritePtr1+1;
  if(i==UART_BUFFER_SIZE) i=0;

  if(i!=UARTTxReadPtr1)
  {
    UARTTxBuffer1[UARTTxWritePtr1]=ch;
    UARTTxWritePtr1=i;

    //Sendeinterrupt aktivieren
    AT91C_BASE_US1->US_IER=AT91C_US_TXRDY;
  }
}


/*******************************************************************
   Funktion: ReadUART()
   Parameter: *ch: Zeiger auf Variable f�r zu lesendes Zeichen

   R�ckgabewert: TRUE bei Erfolg
                 FALSE wenn kein Zeichen da war
   Zweck: Lesen eines Zeichens aus dem Empfangspuffer
          (Einstellen in den Sendepuffer)
********************************************************************/
UINT ReadSecondaryUART(UCHAR *ch)
{
  //Kein Zeichen vorhanden?
  if(UARTRxReadPtr1==UARTRxWritePtr1) return FALSE;

  //Zeichen aus dem Puffer holen
  *ch=UARTRxBuffer1[UARTRxReadPtr1++];
  if(UARTRxReadPtr1==UART_BUFFER_SIZE) UARTRxReadPtr1=0;

  return TRUE;
}


/*******************************************************************
   Funktion: CheckUARTTimeout()
   Parameter: ---

   R�ckgabewert: TRUE wenn zwischenzeitlich ein Timeout aufgetreten ist
                 FALSE wenn kein Timeout aufgetreten ist
   Zweck: Pr�fen, ob beim Empfangen ein Timeout aufgetreten ist (also
          Zeit zwischen zwei Bytes >5ms) und Zur�cksetzen des
          Timeout-Flags.
********************************************************************/
UINT CheckSecondaryUARTTimeout(void)
{
  UCHAR TimeoutFlag;

  TimeoutFlag=UARTTimeoutFlag1;
  UARTTimeoutFlag1=FALSE;

  return TimeoutFlag;
}


/*******************************************************************
   Funktion: SetUARTTransmitDelay()
   Parameter: Delay: Sendeverz�gerung in ms

   R�ckgabewert: ---

   Zweck: Setzen der Sendeverz�gerung
          (f�r einige RS485-Adapter wichtig)
********************************************************************/
void SetSecondaryUARTTransmitDelay(UINT Delay)
{
  UARTTxDelay1=Delay;
}
