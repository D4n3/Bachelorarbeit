/****************************************************
  Projekt: TMC26x

  Modul:   TMC26x-Commands.c
           Kommandointerpreter

  Datum:   23.4.2009 OK
*****************************************************/

#include "at91sam7x256.h"
#include "bits.h"
#include <stdlib.h>
#include <string.h>

#include "TMC26x.h"
#include "TMC26x-Commands.h"
#include "UART-TMC26x.h"
#include "USB-TMC26x.h"
#include "SPI-TMC26x.h"
#include "TMC262-ARM.h"
#include "StepDirIrq-TMC26x.h"
#include "Systimer-TMC26x.h"


//Die Adressen sind hier fest eingestellt
#define SERIAL_HOST_ADDRESS 2
#define SERIAL_MODULE_ADDRESS 1

//Globale Variablen
static UCHAR TMCLCommandState;
TTMCLCommand ActualCommand;
TTMCLReply ActualReply;
UCHAR TMCLReplyFormat;
UCHAR SpecialReply[9];
static UCHAR UARTCmd[9];
static UCHAR UARTCount;
static UCHAR ResetRequested;


//Importierte Variablen
extern const char *VersionString;

extern volatile int ActualVelocity;
extern volatile int ActualAcceleration;
extern volatile int ActualPosition;
extern volatile int TargetVelocity;
extern volatile int TargetPosition;
extern volatile int MaxPositioningSpeed;
extern volatile UCHAR RampMode;
extern volatile UCHAR TargetReachedFlag;


//Prototypen f�r die TMCL-Funktionen
static void RotateRight(void);
static void RotateLeft(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void UserFunc0(void);
static void UserFunc1(void);
static void UserFunc7(void);
static void GetVersion(void);
static void SoftwareReset(void);


/*******************************************************************
   Funktion: ResetCPU
   Parameter: ResetPeripherals: Gibt an, ob nur die eigentliche CPU
              oder auch die On-Chip-Peripherie zur�ckgesetzt werden
              soll (TRUE = auch Peripherie, FALSE = nur Core).

   R�ckgabewert: ---

   Zweck: Reset der CPU mit oder ohne der integrierten Peripherie.
********************************************************************/
void ResetCPU(UCHAR ResetPeripherals)
{
  if(ResetPeripherals)
    AT91C_BASE_RSTC->RSTC_RCR=AT91C_RSTC_PROCRST|AT91C_RSTC_PERRST|(0xA5<<24);
  else
    AT91C_BASE_RSTC->RSTC_RCR=AT91C_RSTC_PROCRST|(0xA5<<24);
}


void ShortDelay(void)
{
  UINT t1;

  t1=GetSysTimer();
  while(abs(t1-GetSysTimer())<2);
}

/*******************************************************************
   Funktion: ExecuteActualCommand()
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Ausf�hren des Befehls, der in der globalen Variablen
          ActualCommand steht.
********************************************************************/
void ExecuteActualCommand(void)
{
  //Antworttelegramm vorbelegen
  ActualReply.Opcode=ActualCommand.Opcode;
  ActualReply.Status=REPLY_OK;
  ActualReply.Value.Int32=ActualCommand.Value.Int32;

  //Befehl ausf�hren
  switch(ActualCommand.Opcode)
  {
    case TMCL_ROR:
      RotateRight();
      break;

    case TMCL_ROL:
      RotateLeft();
      break;

    case TMCL_MST:
      MotorStop();
      break;

    case TMCL_MVP:
      MoveToPosition();
      break;

    case TMCL_SAP:
      SetAxisParameter();
      break;

    case TMCL_GAP:
      GetAxisParameter();
      break;

    case TMCL_UF0:
      UserFunc0();
      break;

    case TMCL_UF1:
      UserFunc1();
      break;

    case TMCL_UF7:
      UserFunc7();
      break;

    case TMCL_GetVersion:
      GetVersion();
      break;

    case TMCL_SoftwareReset:
      SoftwareReset();
      break;

    default:
      ActualReply.Status=REPLY_INVALID_CMD;
      break;
  }
}


/*******************************************************************
   Funktion: ProcessCommands()
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Holen und Ausf�hren von Befehlen �ber RS232 und USB.
          Diese Funktion mu� periodisch aus der Hauptschleife
          heraus aufgerufen werden.
          Es werden 9-Byte-Kommandos �hnlich wie bei TMCL verwendet.
********************************************************************/
void ProcessCommands(void)
{
  UCHAR Byte;
  UCHAR Checksum;
  UINT i;
  UCHAR USBCmd[9];
  UCHAR USBReply[9];

  //**Antwort auf letzten Direktmodus-Befehl senden (wenn vorhanden)**
  if(TMCLCommandState==TCS_UART)  //Antwort �ber UART
  {
    if(TMCLReplyFormat==RF_STANDARD)
    {
      Checksum=SERIAL_HOST_ADDRESS+SERIAL_MODULE_ADDRESS+
               ActualReply.Status+ActualReply.Opcode+
               ActualReply.Value.Byte[3]+
               ActualReply.Value.Byte[2]+
               ActualReply.Value.Byte[1]+
               ActualReply.Value.Byte[0];

      WriteUART(SERIAL_HOST_ADDRESS);
      WriteUART(SERIAL_MODULE_ADDRESS);
      WriteUART(ActualReply.Status);
      WriteUART(ActualReply.Opcode);
      WriteUART(ActualReply.Value.Byte[3]);
      WriteUART(ActualReply.Value.Byte[2]);
      WriteUART(ActualReply.Value.Byte[1]);
      WriteUART(ActualReply.Value.Byte[0]);
      WriteUART(Checksum);
    }
    else if(TMCLReplyFormat==RF_SPECIAL)
    {
      for(i=0; i<9; i++)
      {
        WriteUART(SpecialReply[i]);
      }
    }
  }
  else if(TMCLCommandState==TCS_UART_ERROR)  //letztes Kommando �ber UART hatte falsche Pr�fsumme
  {
    ActualReply.Opcode=0;
    ActualReply.Status=REPLY_CHKERR;
    ActualReply.Value.Int32=0;

    Checksum=SERIAL_HOST_ADDRESS+SERIAL_MODULE_ADDRESS+
             ActualReply.Status+ActualReply.Opcode+
             ActualReply.Value.Byte[3]+
             ActualReply.Value.Byte[2]+
             ActualReply.Value.Byte[1]+
             ActualReply.Value.Byte[0];

    WriteUART(SERIAL_HOST_ADDRESS);
    WriteUART(SERIAL_MODULE_ADDRESS);
    WriteUART(ActualReply.Status);
    WriteUART(ActualReply.Opcode);
    WriteUART(ActualReply.Value.Byte[3]);
    WriteUART(ActualReply.Value.Byte[2]);
    WriteUART(ActualReply.Value.Byte[1]);
    WriteUART(ActualReply.Value.Byte[0]);
    WriteUART(Checksum);
  }
  else if(TMCLCommandState==TCS_USB)  //Antwort �ber USB
  {
    ShortDelay();
    if(TMCLReplyFormat==RF_STANDARD)
    {
      Checksum=SERIAL_HOST_ADDRESS+SERIAL_MODULE_ADDRESS+
               ActualReply.Status+ActualReply.Opcode+
               ActualReply.Value.Byte[3]+
               ActualReply.Value.Byte[2]+
               ActualReply.Value.Byte[1]+
               ActualReply.Value.Byte[0];

      USBReply[0]=SERIAL_HOST_ADDRESS;
      USBReply[1]=SERIAL_MODULE_ADDRESS;
      USBReply[2]=ActualReply.Status;
      USBReply[3]=ActualReply.Opcode;
      USBReply[4]=ActualReply.Value.Byte[3];
      USBReply[5]=ActualReply.Value.Byte[2];
      USBReply[6]=ActualReply.Value.Byte[1];
      USBReply[7]=ActualReply.Value.Byte[0];
      USBReply[8]=Checksum;
    }
    else if(TMCLReplyFormat==RF_SPECIAL)
    {
      for(i=0; i<9; i++)
      {
        USBReply[i]=SpecialReply[i];
      }
    }

    SendUSBReply(USBReply);
  }
  else if(TMCLCommandState==TCS_USB_ERROR)  //letztes Kommando �ber USB hatte falsche Pr�fsumme
  {
    ActualReply.Opcode=0;
    ActualReply.Status=REPLY_CHKERR;
    ActualReply.Value.Int32=0;

    Checksum=SERIAL_HOST_ADDRESS+SERIAL_MODULE_ADDRESS+
             ActualReply.Status+ActualReply.Opcode+
             ActualReply.Value.Byte[3]+
             ActualReply.Value.Byte[2]+
             ActualReply.Value.Byte[1]+
             ActualReply.Value.Byte[0];

    USBReply[0]=SERIAL_HOST_ADDRESS;
    USBReply[1]=SERIAL_MODULE_ADDRESS;
    USBReply[2]=ActualReply.Status;
    USBReply[3]=ActualReply.Opcode;
    USBReply[4]=ActualReply.Value.Byte[3];
    USBReply[5]=ActualReply.Value.Byte[2];
    USBReply[6]=ActualReply.Value.Byte[1];
    USBReply[7]=ActualReply.Value.Byte[0];
    USBReply[8]=Checksum;

    SendUSBReply(USBReply);
  }

  //Zustand zur�cksetzen (Antwort ist nun gesendet)
  TMCLCommandState=TCS_IDLE;
  TMCLReplyFormat=RF_STANDARD;


  //Letzter Befehl war Reset-Befehl => Reset
  if(ResetRequested) ResetCPU(TRUE);


  //**Befehl holen (Priorit�ten: UART, USB, Speicher)**
  if(ReadUART(&Byte))  //Befehl von RS232/RS485?
  {
    if(CheckUARTTimeout()) UARTCount=0;  //bei Timeout alles bisherige verwerfen
    UARTCmd[UARTCount++]=Byte;

    if(UARTCount==9)  //Neun Bytes wurden empfangen
    {
      UARTCount=0;

      if(UARTCmd[0]==SERIAL_MODULE_ADDRESS)  //Stimmt die Adresse?
      {
        Checksum=0;
        for(i=0; i<8; i++) Checksum+=UARTCmd[i];

        if(Checksum==UARTCmd[8])  //Stimmt die Pr�fsumme?
        {
          ActualCommand.Opcode=UARTCmd[1];
          ActualCommand.Type=UARTCmd[2];
          ActualCommand.Motor=UARTCmd[3];
          ActualCommand.Value.Byte[3]=UARTCmd[4];
          ActualCommand.Value.Byte[2]=UARTCmd[5];
          ActualCommand.Value.Byte[1]=UARTCmd[6];
          ActualCommand.Value.Byte[0]=UARTCmd[7];

          TMCLCommandState=TCS_UART;

          UARTCount=0;
        }
        else TMCLCommandState=TCS_UART_ERROR;  //Pr�fsumme war falsch
      }
    }
  }
  else if(GetUSBCmd(USBCmd))  //Befehl von USB?
  {
    if(USBCmd[0]==SERIAL_MODULE_ADDRESS)  //Stimmt die Adresse?
    {
      Checksum=0;
      for(i=0; i<8; i++) Checksum+=USBCmd[i];

      if(Checksum==USBCmd[8])  //Stimmt die Pr�fsumme?
      {
        ActualCommand.Opcode=USBCmd[1];
        ActualCommand.Type=USBCmd[2];
        ActualCommand.Motor=USBCmd[3];
        ActualCommand.Value.Byte[3]=USBCmd[4];
        ActualCommand.Value.Byte[2]=USBCmd[5];
        ActualCommand.Value.Byte[1]=USBCmd[6];
        ActualCommand.Value.Byte[0]=USBCmd[7];

        TMCLCommandState=TCS_USB;
      } else TMCLCommandState=TCS_USB_ERROR;  //Pr�fsumme war falsch
    }
  }

  //Befehl ausf�hren, wenn erfolgreich ein Befehl geholt wurde.
  if(TMCLCommandState!=TCS_IDLE && TMCLCommandState!=TCS_UART_ERROR &&
     TMCLCommandState!=TCS_USB_ERROR) ExecuteActualCommand();
}



//**************************** Funktionen f�r die einzelnen TMCL-Befehle *****************
// F�r alle diese Funktionen gilt:
//   -die Parameter stehen in der globalen Variablen ActualCommand
//   -ein eventueller R�ckgabewert wird in der globalen Variablen ActualReply abgelegt.
//****************************************************************************************

/*********************************
   Funktion: RotateRight()

   Zweck: TMCL-Befehl ROR
 *********************************/
static void RotateRight(void)
{
  if(ActualCommand.Motor==0)
  {
    if(ActualCommand.Type==0)
    {
      ActivateStepDir();
      RampMode=RM_VELOCITY;
      TargetVelocity=ActualCommand.Value.Int32;
    }
    else ActualReply.Status=REPLY_WRONG_TYPE;
  }
  else ActualReply.Status=REPLY_INVALID_VALUE;
}


/*********************************
   Funktion: RotateRight()

   Zweck: TMCL-Befehl ROL
 *********************************/
static void RotateLeft(void)
{
  if(ActualCommand.Motor==0)
  {
    if(ActualCommand.Type==0)
    {
      ActivateStepDir();
      RampMode=RM_VELOCITY;
      TargetVelocity=-ActualCommand.Value.Int32;
    }
    else ActualReply.Status=REPLY_WRONG_TYPE;
  }
  else ActualReply.Status=REPLY_INVALID_VALUE;
}


/*********************************
   Funktion: MotorStop()

   Zweck: TMCL-Befehl MST
 *********************************/
static void MotorStop(void)
{
  if(ActualCommand.Motor==0)
  {
    if(ActualCommand.Type==0)
    {
      RampMode=RM_VELOCITY;
      TargetVelocity=0;
    }
    else ActualReply.Status=REPLY_WRONG_TYPE;
  }
  else ActualReply.Status=REPLY_INVALID_VALUE;
}


/*********************************
   Funktion: SetAxisParameter()

   Zweck: TMCL-Befehl MVP
 *********************************/
static void MoveToPosition(void)
{
  if(ActualCommand.Motor==0)
  {
    switch(ActualCommand.Type)
    {
      case MVP_ABS:
        ActivateStepDir();
        TargetPosition=ActualCommand.Value.Int32;
        RampMode=RM_POSITION;
        break;

      case MVP_REL:
        ActivateStepDir();
        TargetPosition=ActualPosition+ActualCommand.Value.Int32;
        RampMode=RM_POSITION;
        break;

      default:
        ActualReply.Status=REPLY_WRONG_TYPE;
        break;
    }
  }
  else ActualReply.Status=REPLY_INVALID_VALUE;
}


/*********************************
   Funktion: SetAxisParameter()

   Zweck: TMCL-Befehl SAP
 *********************************/
static void SetAxisParameter(void)
{
  if(ActualCommand.Motor==0)
  {
    switch(ActualCommand.Type)
    {
      case 0:
        ActivateStepDir();
        TargetPosition=ActualCommand.Value.Int32;
        break;

      case 1:
        ActivateStepDir();
        ActualPosition=ActualCommand.Value.Int32;
        break;

      case 2:
        ActivateStepDir();
        TargetVelocity=ActualCommand.Value.Int32;
        break;

      case 3:
        ActivateStepDir();
        ActualVelocity=ActualCommand.Value.Int32;
        break;

      case 4:
        MaxPositioningSpeed=abs(ActualCommand.Value.Int32);
        break;

      case 5:
        ActualAcceleration=ActualCommand.Value.Int32;
        break;

      case 6:
        Set262StallGuardCurrentScale(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 140:
        Set262StepDirMStepRes(WHICH_262(ActualCommand.Motor), 8-ActualCommand.Value.Int32);  //Wert wird umgedreht wegen TMCL-Kompatibilit�t
        break;

      case 160:
        Set262StepDirInterpolation(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 161:
        Set262StepDirDoubleEdge(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 162:
        Set262ChopperBlankTime(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 163:
        Set262ChopperMode(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 164:
        Set262ChopperHysteresisDecay(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 165:
        Set262ChopperHysteresisEnd(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 166:
        Set262ChopperHysteresisStart(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 167:
        Set262ChopperTOff(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 168:
        Set262SmartEnergyIMin(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 169:
        Set262SmartEnergyDownStep(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 170:
        Set262SmartEnergyStallLevelMax(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 171:
        Set262SmartEnergyUpStep(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 172:
        Set262SmartEnergyStallLevelMin(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 173:
        Set262StallGuardFilter(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 174:
        Set262StallGuardThreshold(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 175:
        Set262DriverSlopeHighSide(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 176:
        Set262DriverSlopeLowSide(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 177:
        Set262DriverDisableProtection(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 178:
        Set262DriverProtectionTimer(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 179:
        Set262DriverVSenseScale(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 183:
        Set262DriverStepDirectionOff(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 184:
        Set262ChopperRandomTOff(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      case 185:
        Set262DriverTestMode(WHICH_262(ActualCommand.Motor), ActualCommand.Value.Int32);
        break;

      default:
        ActualReply.Status=REPLY_WRONG_TYPE;
        break;
    }
  }
  else ActualReply.Status=REPLY_INVALID_VALUE;
}


/*********************************
   Funktion: GetAxisParameter()

   Zweck: TMCL-Befehl GAP
 *********************************/
static void GetAxisParameter(void)
{
  UINT StallGuard;

  if(ActualCommand.Motor==0)
  {
    switch(ActualCommand.Type)
    {
      case 0:
        ActualReply.Value.Int32=TargetPosition;
        break;

      case 1:
        ActualReply.Value.Int32=ActualPosition;
        break;

      case 2:
        ActualReply.Value.Int32=TargetVelocity;
        break;

      case 3:
        ActualReply.Value.Int32=ActualVelocity;
        break;

      case 4:
        ActualReply.Value.Int32=MaxPositioningSpeed;
        break;

      case 5:
        ActualReply.Value.Int32=ActualAcceleration;
        break;

      case 6:
        ActualReply.Value.Int32=Get262StallGuardCurrentScale(WHICH_262(ActualCommand.Motor));
        break;

      case 8:
        ActualReply.Value.Int32=TargetReachedFlag;
        break;

      case 140:
        ActualReply.Value.Int32=8-Get262StepDirMStepRes(WHICH_262(ActualCommand.Motor));  //Wert wird umgedreht wegen TMCL-Kompatibilit�t
        break;

      case 160:
        ActualReply.Value.Int32=Get262StepDirInterpolation(WHICH_262(ActualCommand.Motor));
        break;

      case 161:
        ActualReply.Value.Int32=Get262StepDirDoubleEdge(WHICH_262(ActualCommand.Motor));
        break;

      case 162:
        ActualReply.Value.Int32=Get262ChopperBlankTime(WHICH_262(ActualCommand.Motor));
        break;

      case 163:
        ActualReply.Value.Int32=Get262ChopperMode(WHICH_262(ActualCommand.Motor));
        break;

      case 164:
        ActualReply.Value.Int32=Get262ChopperHysteresisDecay(WHICH_262(ActualCommand.Motor));
        break;

      case 165:
        ActualReply.Value.Int32=Get262ChopperHysteresisEnd(WHICH_262(ActualCommand.Motor));
        break;

      case 166:
        ActualReply.Value.Int32=Get262ChopperHysteresisStart(WHICH_262(ActualCommand.Motor));
        break;

      case 167:
        ActualReply.Value.Int32=Get262ChopperTOff(WHICH_262(ActualCommand.Motor));
        break;

      case 168:
        ActualReply.Value.Int32=Get262SmartEnergyIMin(WHICH_262(ActualCommand.Motor));
        break;

      case 169:
        ActualReply.Value.Int32=Get262SmartEnergyDownStep(WHICH_262(ActualCommand.Motor));
        break;

      case 170:
        ActualReply.Value.Int32=Get262SmartEnergyStallLevelMax(WHICH_262(ActualCommand.Motor));
        break;

      case 171:
        ActualReply.Value.Int32=Get262SmartEnergyUpStep(WHICH_262(ActualCommand.Motor));
        break;

      case 172:
        ActualReply.Value.Int32=Get262SmartEnergyStallLevelMin(WHICH_262(ActualCommand.Motor));
        break;

      case 173:
        ActualReply.Value.Int32=Get262StallGuardFilter(WHICH_262(ActualCommand.Motor));
        break;

      case 174:
        ActualReply.Value.Int32=Get262StallGuardThreshold(WHICH_262(ActualCommand.Motor));
        break;

      case 175:
        ActualReply.Value.Int32=Get262DriverSlopeHighSide(WHICH_262(ActualCommand.Motor));
        break;

      case 176:
        ActualReply.Value.Int32=Get262DriverSlopeLowSide(WHICH_262(ActualCommand.Motor));
        break;

      case 177:
        ActualReply.Value.Int32=Get262DriverDisableProtection(WHICH_262(ActualCommand.Motor));
        break;

      case 178:
        ActualReply.Value.Int32=Get262DriverProtectionTimer(WHICH_262(ActualCommand.Motor));
        break;

      case 179:
        ActualReply.Value.Int32=Get262DriverVSenseScale(WHICH_262(ActualCommand.Motor));
        break;

      case 180:
        if(Get262DriverReadSelect(WHICH_262(ActualCommand.Motor))!=TMC262_RB_SMART_ENERGY)
          Set262DriverReadSelect(WHICH_262(ActualCommand.Motor), TMC262_RB_SMART_ENERGY);
        ActualReply.Value.Int32=0;
        Read262State(WHICH_262(ActualCommand.Motor), NULL, NULL, NULL, &ActualReply.Value.Byte[0], NULL);
        break;

      case 182:
        if(Get262DriverReadSelect(WHICH_262(ActualCommand.Motor))!=TMC262_RB_MSTEP)
          Set262DriverReadSelect(WHICH_262(ActualCommand.Motor), TMC262_RB_MSTEP);
        ActualReply.Value.Int32=0;
        Read262State(WHICH_262(ActualCommand.Motor), &ActualReply.Value.Byte[1], &ActualReply.Value.Byte[0], NULL, NULL, NULL);
        break;

      case 183:
        ActualReply.Value.Int32=Get262DriverStepDirectionOff(WHICH_262(ActualCommand.Motor));
        break;

      case 184:
        ActualReply.Value.Int32=Get262ChopperRandomTOff(WHICH_262(ActualCommand.Motor));
        break;

      case 185:
        ActualReply.Value.Int32=Get262DriverTestMode(WHICH_262(ActualCommand.Motor));
        break;

      case 206:
        if(Get262DriverReadSelect(WHICH_262(ActualCommand.Motor))!=TMC262_RB_STALL_GUARD)
          Set262DriverReadSelect(WHICH_262(ActualCommand.Motor), TMC262_RB_STALL_GUARD);
        ActualReply.Value.Int32=0;
        Read262State(WHICH_262(ActualCommand.Motor), NULL, NULL, &StallGuard, NULL, NULL);
        ActualReply.Value.Int32=StallGuard;
        break;

      case 207:
        if(AT91C_BASE_PIOA->PIO_PDSR & BIT10)
          ActualReply.Value.Int32=1;
        else
          ActualReply.Value.Int32=0;
        break;

      case 208:
        ActualReply.Value.Int32=0;
        Read262State(WHICH_262(ActualCommand.Motor), NULL, NULL, NULL, NULL, &ActualReply.Value.Byte[0]);
        break;

      default:
        ActualReply.Status=REPLY_WRONG_TYPE;
        break;
    }
  }
  else ActualReply.Status=REPLY_INVALID_VALUE;
}


/*********************************
   Funktion: UserFunc0()

   Zweck: TMCL-Befehl UF0
   Hier verwendet zum Schalten der
   ENABLE-Leitung.
 *********************************/
static void UserFunc0(void)
{
  if(ActualCommand.Value.Int32==0)
    DISABLE_DRIVERS();
  else
    ENABLE_DRIVERS();
}


/*********************************
   Funktion: UserFunc1()

   Zweck: TMCL-Befehl UF1
   Hier verwendet zum Setzen der
   Taktfrequenz.
 *********************************/
static void UserFunc1(void)
{
  switch(ActualCommand.Value.Int32)
  {
    case 0:
      AT91C_BASE_PMC->PMC_PCKR[2]=AT91C_PMC_PRES_CLK|AT91C_PMC_CSS_MAIN_CLK;   //16Mhz an PCK2 (PB22)
      break;

    case 1:
      AT91C_BASE_PMC->PMC_PCKR[2]=AT91C_PMC_PRES_CLK_2|AT91C_PMC_CSS_MAIN_CLK;   //8Mhz an PCK2 (PB22)
      break;

    case 2:
      AT91C_BASE_PMC->PMC_PCKR[2]=AT91C_PMC_PRES_CLK_4|AT91C_PMC_CSS_MAIN_CLK;   //4Mhz an PCK2 (PB22)
      break;

    case 3:
      AT91C_BASE_PMC->PMC_PCKR[2]=AT91C_PMC_PRES_CLK_8|AT91C_PMC_CSS_MAIN_CLK;   //2Mhz an PCK2 (PB22)
      break;

    case 4:
      AT91C_BASE_PMC->PMC_PCKR[2]=AT91C_PMC_PRES_CLK_16|AT91C_PMC_CSS_MAIN_CLK;   //1Mhz an PCK2 (PB22)
      break;

    case 5:
      AT91C_BASE_PMC->PMC_PCKR[2]=AT91C_PMC_PRES_CLK_32|AT91C_PMC_CSS_MAIN_CLK;   //500kHz an PCK2 (PB22)
      break;

    case 6:
      AT91C_BASE_PMC->PMC_PCKR[2]=AT91C_PMC_PRES_CLK_64|AT91C_PMC_CSS_MAIN_CLK;   //250kHz an PCK2 (PB22)
      break;

    default:
      ActualReply.Status=REPLY_INVALID_VALUE;
      break;
  }
}


/*********************************
   Funktion: UserFunc7()

   Zweck: TMCL-Befehl UF7
   Hier verwendet f�r direkten
   SPI-Zugriff auf den Chip.
 *********************************/
static void UserFunc7(void)
{
  switch(ActualCommand.Type)
  {
    case 0:
      ActualReply.Value.Byte[3]=ReadWriteSPI(SPI_DEV_TMC26x, ActualCommand.Value.Byte[3], FALSE);
      ActualReply.Value.Byte[2]=ReadWriteSPI(SPI_DEV_TMC26x, ActualCommand.Value.Byte[2], FALSE);
      ActualReply.Value.Byte[1]=ReadWriteSPI(SPI_DEV_TMC26x, ActualCommand.Value.Byte[1], FALSE);
      ActualReply.Value.Byte[0]=ReadWriteSPI(SPI_DEV_TMC26x, ActualCommand.Value.Byte[0], TRUE);
      break;

    case 1:
      ActualReply.Value.Int32=0;
      ActualReply.Value.Byte[1]=ReadWriteSPI(SPI_DEV_TMC26x, 0x20|(ActualCommand.Motor & 0x1f), FALSE);
      ActualReply.Value.Byte[0]=ReadWriteSPI(SPI_DEV_TMC26x, ActualCommand.Value.Byte[0], TRUE);
      break;

    case 2:
      ActualReply.Value.Int32=ReadWriteSPI(SPI_DEV_TMC26x, 0x40|(ActualCommand.Motor & 0x1f), TRUE);
      break;

    case 3:
      ActualReply.Value.Int32=ReadWriteSPI(SPI_DEV_TMC26x, 0x60|(ActualCommand.Motor & 0x1f), TRUE);
      break;

    case 4:
      ActualReply.Value.Int32=ReadWriteSPI(SPI_DEV_TMC26x, 0x80|(ActualCommand.Motor & 0x1f), TRUE);
      break;

    default:
      ActualReply.Status=REPLY_WRONG_TYPE;
      break;
  }
}


/*********************************
   Funktion: GetVersion

   Zweck: TMCL-Versionsabfrage
 *********************************/
static void GetVersion(void)
{
  UINT i;

  if(ActualCommand.Type==0)
  {
    TMCLReplyFormat=RF_SPECIAL;
    SpecialReply[0]=SERIAL_HOST_ADDRESS;
    for(i=0; i<8; i++)
      SpecialReply[i+1]=VersionString[i];
  }
  else if(ActualCommand.Type==1)
  {
    ActualReply.Value.Byte[3]=SW_TYPE_HIGH;
    ActualReply.Value.Byte[2]=SW_TYPE_LOW;
    ActualReply.Value.Byte[1]=SW_VERSION_HIGH;
    ActualReply.Value.Byte[0]=SW_VERSION_LOW;
  }
}


/*********************************
   Funktion: SoftwareReset()

   Zweck: TMCL-Reset-Befehl
 *********************************/
static void SoftwareReset(void)
{
  if(ActualCommand.Value.Int32==1234) ResetRequested=TRUE;
}
