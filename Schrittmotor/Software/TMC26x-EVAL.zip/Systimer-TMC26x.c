/****************************************************
  Projekt: TMC26x

  Modul:   Systimer-TMC26x.c
           System-Timer (1ms-Takt).

  Datum:   29.3.2007 OK
*****************************************************/


#include "at91sam7x256.h"
#include "bits.h"

#include "TMC26x.h"

static volatile UINT Dummy;
static volatile UINT TickCounter;
extern volatile UINT UARTTxDelayTimer;
extern volatile UINT UARTTxDelayTimer1;


/*******************************************************************
  Interrupt Handler f�r Timer 2
  Wird durch den AIC aufgerufen, wenn ein Timer-Interrupt auftritt.
********************************************************************/
static void FASTRUN Timer2Interrupt(void)
{
  //Interrupt zur�cksetzen
  Dummy=AT91C_BASE_TC2->TC_SR;

  //1ms-Z�hler hochz�hlen
  TickCounter++;

  //UART-Sendeverz�gerung herunterz�hlen
  if(UARTTxDelayTimer>0) UARTTxDelayTimer--;
  if(UARTTxDelayTimer1>0) UARTTxDelayTimer1--;
}


/*******************************************************************
   Funktion: GetSysTimer()
   Parameter: ---

   R�ckgabewert: Stand des 1ms-Z�hlers

   Zweck: Abfrage des 1ms-Z�hlers
********************************************************************/
UINT GetSysTimer(void)
{
  return TickCounter;
}


/*******************************************************************
   Funktion: InitSysTimer()
   Parameter: ---

   Zweck: Initialisierung des 1ms-Timers (Timer 2 wird hierf�r benutzt)
********************************************************************/
void InitSysTimer(void)
{
  //Clock f�r Timer 2 einschalten
  AT91C_BASE_PMC->PMC_PCER=1 << AT91C_ID_TC2;

  //Timer inititialisieren
  AT91C_BASE_TC2->TC_CCR=AT91C_TC_CLKDIS;   //Clock aus
  AT91C_BASE_TC2->TC_IDR=0xffffffff;        //Interrupts erst einmal aus
  Dummy=AT91C_BASE_TC2->TC_SR;              //Statusregister zur�cksetzen

  AT91C_BASE_TC2->TC_CMR=AT91C_TC_WAVE|AT91C_TC_WAVESEL_UP_AUTO|AT91C_TC_EEVT_XC0|
                         AT91C_TC_CLKS_TIMER_DIV1_CLOCK;  //Waveform generation mode on TI2A+TI2B, Clk/2
  AT91C_BASE_TC2->TC_CCR=AT91C_TC_CLKEN;   //Clock einschalten

  AT91C_BASE_TC2->TC_RC=2399;     //Compare Match Interrupt bei 2399 => 10KHz-Interrupt

   //Interruptfunktion f�r den Timer setzen (im AIC)
  AT91C_BASE_AIC->AIC_IDCR=1<<AT91C_ID_TC2;
  AT91C_BASE_AIC->AIC_SVR[AT91C_ID_TC2]=(unsigned int) Timer2Interrupt;
  AT91C_BASE_AIC->AIC_SMR[AT91C_ID_TC2]=TIMER_INTERRUPT_PRIORITY|AT91C_AIC_SRCTYPE_INT_HIGH_LEVEL;
  AT91C_BASE_AIC->AIC_ICCR=1<<AT91C_ID_TC2;

  //Interrupt bei Compare Match mit RC  (das ergibt also einen 1kHz-Interrupt)
  AT91C_BASE_TC2->TC_IER = AT91C_TC_CPCS;

  //Interrupt f�r Timer 2 im AIC freischalten
  AT91C_BASE_AIC->AIC_IECR = 1<<AT91C_ID_TC2;

 //*************Timer starten (sehr wichtig!!!!!) ****************
  AT91C_BASE_TC2->TC_CCR = AT91C_TC_SWTRG;
}
