/****************************************************
  Projekt: TMC26x

  Modul:   StepDirIrq-TMC26x.c
           Erzeugen eines Step/Dir-Signals f�r den
           TMC262 (interruptgesteuert).

  Datum:   18.11.2009 OK
*****************************************************/

//Includes
#include <stdlib.h>
#include "at91sam7x256.h"
#include "bits.h"

#include "TMC26x.h"
#include "TMC262-ARM.h"


//Typdefinitionen
typedef enum {RAMP_IDLE, RAMP_ACCELERATE, RAMP_DRIVING, RAMP_DECELERATE} TRampState;


//Variablen
static volatile UINT Dummy;
static volatile int PosAccumulator;  //Akkumulator zum genauen Erzeugen der Geschwindigkeit
volatile int PosAdd;
static volatile int VelAccumulator;  //Akkumulator zum genauen Erzeugen der Beschleunigung
static volatile int VelAdd;
static volatile TRampState RampState;
static volatile int AccelerationSteps;

volatile int ActualVelocity;
volatile int ActualAcceleration;
volatile int ActualPosition;
volatile int TargetVelocity;
volatile int TargetPosition;
volatile int MaxPositioningSpeed;
volatile UCHAR TargetReachedFlag;
volatile UCHAR RampMode;


//Funktionen
/*******************************************************************
   Funktion: Timer0Interrupt
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Interruptbehandlungsroutine f�r Timer 0. Diese dient zum
          Erzeugen der Schrittimpulse.
          Diese Funktion darf niemals direkt aufgerufen werden!
********************************************************************/
static void FASTRUN Timer0Interrupt(void)
{
  //Interrupt zur�cksetzen
  Dummy=AT91C_BASE_TC0->TC_SR;

  //Step-Ausgang zur�cksetzen (fallende Flanke des letzten Step-Impulses)
  AT91C_BASE_PIOA->PIO_CODR=BIT23;

  //Beschleunigung/Verz�gerung
  if(ActualVelocity!=TargetVelocity)
  {
    VelAccumulator+=ActualAcceleration;    //Aufl�sung der Beschleunigung 32 Bit: 1=alle 2^17 Interrupts �ndert sich die Geschwindigkeit um 1
    VelAdd = VelAccumulator >> 17;   //Aufl�sung der Beschleunigung 32 Bit: 1=alle 2^17 Interrupts �ndert sich die Geschwindigkeit um 1
    VelAccumulator-=VelAdd << 17;

    //ActualVelocity in Richtung TargetVelocity ver�ndern (aber nicht dar�ber hinaus)
    if(ActualVelocity<TargetVelocity)
    {
      ActualVelocity=MIN(ActualVelocity+VelAdd, TargetVelocity);
    }
    else if(ActualVelocity>TargetVelocity)
    {
      ActualVelocity=MAX(ActualVelocity-VelAdd, TargetVelocity);
    }
  }
  else
  {
    VelAccumulator=0;
    VelAdd=0;
  }

  //Positionieren
  if(RampMode==RM_POSITION)
  {
    switch(RampState)
    {
      case RAMP_IDLE:  //Warten bis TargetPosition<>ActualPosition (z.B. durch �ndern von TargetPosition)
        if(ActualPosition<TargetPosition)  //Fahrt in positive Richtung notwendig
        {
          TargetVelocity=MaxPositioningSpeed;
          RampState=RAMP_ACCELERATE;
          AccelerationSteps=ActualPosition;
        }
        else if(ActualPosition>TargetPosition)  //Fahrt in negative Richtung notwendig
        {
          TargetVelocity=-MaxPositioningSpeed;
          RampState=RAMP_ACCELERATE;
          AccelerationSteps=ActualPosition;
        }
        break;

      case RAMP_ACCELERATE:   //Beschleunigungsphase
        if(abs(ActualVelocity)==MaxPositioningSpeed)
        {     //Ermitteln der Anzahl der f�r die Beschleunigungsphase ben�tigten Schritte
          AccelerationSteps=abs(ActualPosition-AccelerationSteps)+1;
          RampState=RAMP_DRIVING;
        }
        else if(abs(ActualPosition-AccelerationSteps)>=abs(TargetPosition-ActualPosition))
        {   //Schon den halben Weg gefahren und noch in der Beschleunigungsphase => sofort wieder abbremsen
          TargetVelocity=0;
          RampState=RAMP_DECELERATE;
        }
        break;

      case RAMP_DRIVING:  //Fahrt mit MaxPositioningSpeed
        if((abs(TargetPosition-ActualPosition)<=AccelerationSteps) ||
           (TargetVelocity<0 && ActualPosition<TargetPosition) ||
           (TargetVelocity>0 && ActualPosition>TargetPosition))
        {   //Nur noch so viele Schritte �brig, wie zum Bremsen notwendig?
          TargetVelocity=0;
          RampState=RAMP_DECELERATE;
        }
        break;

      case RAMP_DECELERATE:  //Abbremsphase
        if(ActualPosition==TargetPosition)
        {   //Ziel schon erreicht => sofort anhalten
          TargetVelocity=ActualVelocity=0;
          RampState=RAMP_IDLE;
        }

        if(ActualVelocity==0)  //Motor steht => pr�fen ob Ziel erreicht und in den Grundzustand �bergehen
        {
          RampState=RAMP_IDLE;
          if(ActualPosition==TargetPosition) TargetReachedFlag=TRUE;
        }
        break;
    }
  }

  //Geschwindigkeit
  PosAccumulator += ActualVelocity;   //Geschwindigkeitsaufl�sung 32 Bit: 1=alle 2^17 Interrupts ein Mikroschritt
  PosAdd = PosAccumulator >> 17;      //Geschwindigkeitsaufl�sung 32 Bit: 1=alle 2^17 Interrupts ein Mikroschritt
  PosAccumulator -= PosAdd << 17;

  if(PosAdd==0) return;  //keine Positions�nderung bei diesem Durchlauf: sofort abbrechen

  if(PosAdd>=1)
  {
    PosAdd=1;
    AT91C_BASE_PIOA->PIO_CODR=BIT24;
  }
  else if(PosAdd<=-1)
  {
    PosAdd=-1;
    AT91C_BASE_PIOA->PIO_SODR=BIT24;
  }

  ActualPosition+=PosAdd;

  //Step-Impuls erzeugen (steigende Flanke, fallende Flanke beim n�chsten Interrupt)
  AT91C_BASE_PIOA->PIO_SODR=BIT23;
}


/*******************************************************************
   Funktion: InitStepDirIrq
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Initialisierung des Timer-Interrupts zum Erzeugen der
          Schrittimpulse.
********************************************************************/
void InitStepDirIrq(void)
{
  //Ein paar Initialwerte
  ActualAcceleration=51200;
  MaxPositioningSpeed=51200;

  //Timer 0 konfigurieren (zum Erzeugen von Geschwindigkeiten)
  AT91C_BASE_PMC->PMC_PCER=1 << AT91C_ID_TC0;  //Clock f�r Timer 0 einschalten
  AT91C_BASE_TC0->TC_CCR=AT91C_TC_CLKDIS;   //Timer stoppen
  AT91C_BASE_TC0->TC_IDR=0xffffffff;        //Interrupts aus
  Dummy=AT91C_BASE_TC0->TC_SR;              //Statusregister zur�cksetzen

  AT91C_BASE_TC0->TC_CMR=AT91C_TC_WAVE|AT91C_TC_WAVESEL_UP_AUTO|AT91C_TC_EEVT_XC0|
                         AT91C_TC_CLKS_TIMER_DIV1_CLOCK;  //Clk/2

  AT91C_BASE_TC0->TC_CCR=AT91C_TC_CLKEN;

  AT91C_BASE_TC0->TC_RA=0;
  AT91C_BASE_TC0->TC_RB=0;
  AT91C_BASE_TC0->TC_RC=183; //366;  //ca. 66KHz (so, da� Geschwindigkeiten in Mikroschritten/Sekunde angeben werden k�nnen)
  AT91C_BASE_TC0->TC_CCR=AT91C_TC_SWTRG;
  AT91C_BASE_TC0->TC_IER=AT91C_TC_CPCS;

  //Interrupt f�r Timer 0 im AIC eintragen
  AT91C_BASE_AIC->AIC_IDCR=1<<AT91C_ID_TC0;
  AT91C_BASE_AIC->AIC_SVR[AT91C_ID_TC0]=(unsigned int) Timer0Interrupt;
  AT91C_BASE_AIC->AIC_SMR[AT91C_ID_TC0]=AT91C_AIC_PRIOR_HIGHEST|AT91C_AIC_SRCTYPE_INT_HIGH_LEVEL;
//  AT91C_BASE_AIC->AIC_FFER=1<<AT91C_ID_TC0;  //dieser Interrupt soll auch FIQ sein
  AT91C_BASE_AIC->AIC_IECR=1<<AT91C_ID_TC0;
}


/*******************************************************************
   Funktion: ActivateStepDir
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Aktivieren der Step/Direction-Pins. Diese sind zun�chst
          hochohmig geschaltet, um das Einspeisen eines externen
          Step/Dir-Signals zu erm�glichen.
********************************************************************/
void ActivateStepDir(void)
{
  if((AT91C_BASE_PIOA->PIO_OSR & (BIT24|BIT23)) != (BIT24|BIT23))
  {
    AT91C_BASE_PIOA->PIO_OER=BIT24|BIT23;
  }
}
