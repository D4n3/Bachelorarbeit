/****************************************************
  Projekt: TMC26x

  Modul:   UART-TMC26x.c
           UART Interrupt Handler

  Datum:   23.3.2007 OK
*****************************************************/

#include "at91sam7x256.h"
#include "bits.h"
#include "TMC26x.h"
#include "UART-TMC26x.h"


//Puffer f�r Senden und Empfangen
volatile UCHAR UARTRxBuffer[UART_BUFFER_SIZE];
volatile UCHAR UARTTxBuffer[UART_BUFFER_SIZE];
volatile UINT UARTRxReadPtr, UARTRxWritePtr, UARTTxReadPtr, UARTTxWritePtr;
volatile UCHAR UARTTimeoutFlag;
volatile UINT UARTTxDelay;
volatile UINT UARTTxDelayTimer;

volatile UCHAR UARTRxBuffer1[UART_BUFFER_SIZE];
volatile UCHAR UARTTxBuffer1[UART_BUFFER_SIZE];
volatile UINT UARTRxReadPtr1, UARTRxWritePtr1, UARTTxReadPtr1, UARTTxWritePtr1;
volatile UCHAR UARTTimeoutFlag1;
volatile UINT UARTTxDelay1;
volatile UINT UARTTxDelayTimer1;


/*******************************************************************
  UART-Interrupthandler
  Wird durch den AIC aufgerufen, wenn ein UART-Interrupt auftritt.
  Dies paasiert, wenn ein Zeichen angekommen ist oder die
  ein Zeichen gesendet werden kann.
********************************************************************/
void FASTRUN UARTInterruptHandler(void)
{
  UINT CSR;
  UINT i;

  //Status der UART merken (dies setzt auch den Interrupt zur�ck)
  CSR=AT91C_BASE_US0->US_CSR;

  //Ist ein Zeichen angekommen?
  if(CSR & AT91C_US_RXRDY)
  {
    //Sendeverz�gerung neu starten
    UARTTxDelayTimer=UARTTxDelay;

    //Zeichen in den Empfangspuffer kopieren
    i=UARTRxWritePtr+1;
    if(i==UART_BUFFER_SIZE) i=0;

    if(i!=UARTRxReadPtr)
    {
      UARTRxBuffer[UARTRxWritePtr]=AT91C_BASE_US0->US_RHR;
      UARTRxWritePtr=i;
    }
  }

  //Kann das n�chste Zeichen gesendet werden (Senderegister frei und Verz�gerung abgelaufen)?
  if((CSR & AT91C_US_TXRDY) && UARTTxDelayTimer==0)
  {
    if(UARTTxWritePtr!=UARTTxReadPtr)
    {
      AT91C_BASE_US0->US_THR=UARTTxBuffer[UARTTxReadPtr++];
      if(UARTTxReadPtr==UART_BUFFER_SIZE) UARTTxReadPtr=0;
    }
    else
    {
      //Sendeinterrupt deaktivieren, wenn kein Zeichen im Sendepuffer ist
      AT91C_BASE_US0->US_IDR=AT91C_US_TXRDY;
    }
  }

  //Ist ein Timeout aufgetreten?
  if(CSR & AT91C_US_TIMEOUT)
  {
    UARTTimeoutFlag=TRUE;
    AT91C_BASE_US0->US_CR=AT91C_US_STTTO;  //Receiver-Timeout zur�cksetzen, beginnt automatisch wieder wenn das n�chste Byte kommt.
  }
}


/*******************************************************************
  UART-Interrupthandler f�r UART 1
  Wird durch den AIC aufgerufen, wenn ein UART-Interrupt auftritt.
  Dies paasiert, wenn ein Zeichen angekommen ist oder die
  ein Zeichen gesendet werden kann.
********************************************************************/
void FASTRUN UARTInterruptHandler1(void)
{
  UINT CSR;
  UINT i;

  //Status der UART merken (dies setzt auch den Interrupt zur�ck)
  CSR=AT91C_BASE_US1->US_CSR;

  //Ist ein Zeichen angekommen?
  if(CSR & AT91C_US_RXRDY)
  {
    //Sendeverz�gerung neu starten
    UARTTxDelayTimer=UARTTxDelay;

    //Zeichen in den Empfangspuffer kopieren
    i=UARTRxWritePtr1+1;
    if(i==UART_BUFFER_SIZE) i=0;

    if(i!=UARTRxReadPtr1)
    {
      UARTRxBuffer1[UARTRxWritePtr1]=AT91C_BASE_US1->US_RHR;
      UARTRxWritePtr1=i;
    }
  }

  //Kann das n�chste Zeichen gesendet werden?
  if((CSR & AT91C_US_TXRDY) && UARTTxDelayTimer1==0)
  {
    if(UARTTxWritePtr1!=UARTTxReadPtr1)
    {
      AT91C_BASE_US1->US_THR=UARTTxBuffer1[UARTTxReadPtr1++];
      if(UARTTxReadPtr1==UART_BUFFER_SIZE) UARTTxReadPtr1=0;
    }
    else
    {
      //Sendeinterrupt deaktivieren, wenn kein Zeichen im Sendepuffer ist
      AT91C_BASE_US1->US_IDR=AT91C_US_TXRDY;
    }
  }

  //Ist ein Timeout aufgetreten?
  if(CSR & AT91C_US_TIMEOUT)
  {
    UARTTimeoutFlag1=TRUE;
    AT91C_BASE_US1->US_CR=AT91C_US_STTTO;  //Receiver-Timeout zur�cksetzen, beginnt automatisch wieder wenn das n�chste Byte kommt.
  }
}
