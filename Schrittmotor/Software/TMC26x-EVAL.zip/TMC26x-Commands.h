/****************************************************
  Projekt: TMC26x

  Modul:   TMC26x-Commands.h
           Kommandointerpreter

  Datum:   23.4.2009 OK
*****************************************************/

#ifndef __TMC26x_COMMANDS_H
#define __TMC26x_COMMANDS_H

/*#define TM_IDLE 0
#define TM_RUN 1
#define TM_STEP 2
#define TM_RESET 3   //nicht verwendet
#define TM_DOWNLOAD 4
#define TM_DEBUG 5  //wie TM_IDLE, es wird jedoch der Akku nicht modifiziert bei GAP etc.
*/
#define TCS_IDLE  0
//#define TCS_CAN7  1
//#define TCS_CAN8  2
#define TCS_UART  3
#define TCS_UART_ERROR 4
//#define TCS_UART_II 5
//#define TCS_UART_II_ERROR 6
#define TCS_USB   7
#define TCS_USB_ERROR 8
//#define TCS_MEM   9


//TMCL-Befehle
#define TMCL_ROR 1
#define TMCL_ROL 2
#define TMCL_MST 3
#define TMCL_MVP 4
#define TMCL_SAP 5
#define TMCL_GAP 6
#define TMCL_UF0 64
#define TMCL_UF1 65
#define TMCL_UF2 66
#define TMCL_UF3 67
#define TMCL_UF4 68
#define TMCL_UF5 69
#define TMCL_UF6 70
#define TMCL_UF7 71

#define TMCL_GetVersion 136

#define TMCL_SoftwareReset 0xff


#define MVP_ABS 0
#define MVP_REL 1



//Statuscodes
#define REPLY_OK 100
#define REPLY_CHKERR 1
#define REPLY_INVALID_CMD 2
#define REPLY_WRONG_TYPE 3
#define REPLY_INVALID_VALUE 4

//Format der Antwort
#define RF_STANDARD 0
#define RF_SPECIAL 1


//Typedefinitionen

//TMCL-Befehl
typedef struct
{
  UCHAR Opcode;
  UCHAR Type;
  UCHAR Motor;
  union
  {
    int Int32;
    UCHAR Byte[4];
  } Value;
} TTMCLCommand;

//TMCL-Antwort
typedef struct
{
  UCHAR Status;
  UCHAR Opcode;
  union
  {
    int Int32;
    UCHAR Byte[4];
  } Value;
} TTMCLReply;


//Exportierte Funktionen
void ProcessCommands(void);

#endif
