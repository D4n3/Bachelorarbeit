/****************************************************
  Projekt: TMCM-STM

  Modul:   SPI-STM.c
           SPI-Funktionen

  Datum:   26.5.2009 OK (updated by ed)
*****************************************************/

#include "SPI-STM.h"

static UCHAR LastSPIDevice;    //zuletzt verwendetes SPI-Ger�t (in InitSPI mit 0xFF initialisieren)

/* initialize SPI */
void spi_stm_init()
{
	SPI_InitTypeDef SPIInit;
	GPIO_InitTypeDef GPIO_InitStructure;

	// enable clock for SPI1
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

	// use pins PA5..PA7 for SPI1
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	//SPI-Pins auf PA4..PA7 legen
	GPIO_PinRemapConfig(GPIO_Remap_SPI1, DISABLE);

	// initialize SPI1
	SPIInit.SPI_Direction=SPI_Direction_2Lines_FullDuplex;
	SPIInit.SPI_Mode=SPI_Mode_Master;
	SPIInit.SPI_DataSize=SPI_DataSize_8b;
	SPIInit.SPI_CPOL=SPI_CPOL_High;
	SPIInit.SPI_CPHA=SPI_CPHA_2Edge;
	SPIInit.SPI_NSS=SPI_NSS_Soft;
	SPIInit.SPI_BaudRatePrescaler=SPI_BaudRatePrescaler_16;
	SPIInit.SPI_FirstBit=SPI_FirstBit_MSB;
	SPIInit.SPI_CRCPolynomial=0;
	SPI_Init(SPI1, &SPIInit);

	SPI_Cmd(SPI1, ENABLE);

	LastSPIDevice=0xFF;  //noch kein zuletzt verwendetes SPI-Ger�t
}

/* reconfigure SPI */
static void ConfigSPI(UCHAR DeviceNumber)
{
	 SPI_InitTypeDef SPIInit;
	 SPI_TypeDef *spiChannel = SPI1;

	 SPI_Cmd(spiChannel, DISABLE);

	 // configure SPI
	 SPIInit.SPI_Direction=SPI_Direction_2Lines_FullDuplex;
	 SPIInit.SPI_Mode=SPI_Mode_Master;
	 SPIInit.SPI_DataSize=SPI_DataSize_8b;
	 SPIInit.SPI_CPOL=SPI_CPOL_High;
	 SPIInit.SPI_CPHA=SPI_CPHA_2Edge;
	 SPIInit.SPI_NSS=SPI_NSS_Soft;
	 SPIInit.SPI_FirstBit=SPI_FirstBit_MSB;
	 SPIInit.SPI_CRCPolynomial=0;

	 switch(DeviceNumber)
	 {
	 	 case SPI_DEV_EEPROM:
	 		 SPIInit.SPI_BaudRatePrescaler=SPI_BaudRatePrescaler_8;
	 		 break;
	 	 default:
	 		 SPIInit.SPI_BaudRatePrescaler=SPI_BaudRatePrescaler_16;
	 		 break;
	 }

	 SPI_Init(spiChannel, &SPIInit);
	 SPI_Cmd(spiChannel, ENABLE);
}

/*******************************************************************
   Funktion: ReadWriteSPI
   Parameter: DeviceNumber: Ger�tenummer (noch nicht verwendet)
              Data: zu sendendes Datenbyte
              LastTransfer: TRUE: nach diesem Byte wird CS wieder
                                  auf High gesetzt
                            FALSE: CS bleibt low (weiteres Byte folgt).

   R�ckgabewert: empfangenes Datenbyte

   Zweck: SPI-Daten�bertragung durchf�hren.
********************************************************************/
UCHAR spi_stm_readWrite(UCHAR DeviceNumber, UCHAR Data, UCHAR LastTransfer)
{
	//Baudrate ausw�hlen (nur wenn zuletzt ein anderes Ger�t verwendet wurde)
	if(LastSPIDevice != DeviceNumber)
	{
		ConfigSPI(DeviceNumber);
		LastSPIDevice = DeviceNumber;
	}
	//CS-Signal low setzen
	switch(DeviceNumber)
	{
    	case SPI_DEV_EEPROM:
    		DISABLE_CS_MEM();
    		break;
    	case SPI_DEV_IO:
    		ENABLE_CS_IO();
    		break;
    	default:
    		return 0;
	}

	 SPI_TypeDef *spiChannel = SPI1;

	while(SPI_I2S_GetFlagStatus(spiChannel, SPI_I2S_FLAG_TXE)==RESET);

	SPI_I2S_SendData(spiChannel, Data);

	while(SPI_I2S_GetFlagStatus(spiChannel, SPI_I2S_FLAG_RXNE)==RESET);

	//CS-Signal high setzen wenn dies der letzte Transfer war
	if(LastTransfer)
	{
		//CS-Signal low setzen
		switch(DeviceNumber)
		{
			case SPI_DEV_EEPROM:
				ENABLE_CS_MEM();
				break;
	    	case SPI_DEV_IO:
	    		DISABLE_CS_IO();
	    		break;
			default:
				return 0;
				break;
		}
	}
	return SPI_I2S_ReceiveData(spiChannel);
}
