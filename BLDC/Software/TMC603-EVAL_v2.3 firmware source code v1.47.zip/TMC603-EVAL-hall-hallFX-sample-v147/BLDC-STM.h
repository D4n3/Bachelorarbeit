/****************************************************
  Projekt: TMCM-STM

  Modul:   BLDC-STM.h
           Steuerung des BLDC-Motors

  Datum:   25.5.2009 OK / ed
*****************************************************/

#ifndef BLDC_STM_H_
#define BLDC_STM_H_

	#include <stdlib.h>
	#include "TMCM-STM.h"
	#include "Functions.h"
	#include "BLDC_Regulator.h"
	#include "PWM.h"
	#include "Timer.h"
	#include "ADC.h"

	#include "SysTick.h"
	#include "Globals-STM.h"
	#include "IO.h"
	#include "Eeprom.h"
	#include "Debug.h"

	void bldc_stm_init();
	void bldc_stm_processBLDC();

	// velocity informations
	void bldc_stm_setTargetVelocity(int newVelocity);
	int bldc_stm_getActualSpeed();
	int bldc_stm_getTargetVelocity();
	int bldc_stm_getRampGenSpeed();

	// position informations
	void bldc_stm_moveToAbsolutePosition(int position);
	void bldc_stm_moveToRelativePosition(int position);
	int bldc_stm_getTargetMotorPosition();
	int bldc_stm_getActualMotorPosition();
	void bldc_stm_setActualMotorPosition(int position);

	// pwm informations
	int bldc_stm_getActualPWMDutyCycle();
	int bldc_stm_getTargetPWM();
	void bldc_stm_setTargetPWM(int pwm);

	// current informations
	int bldc_stm_getTargetMotorCurrent();
	void bldc_stm_setTargetMotorCurrent(int current);
	int bldc_stm_getActualMotorCurrent();

	// flags
	void bldc_stm_setStatusFlag(UINT flag);
	void bldc_stm_clearStatusFlag(UINT flag);
	UCHAR bldc_stm_isStatusFlagSet(UINT flag);
	UINT bldc_stm_getAllStatusFlags();

	// get some PID values
	int bldc_stm_getPositionPIDError();
	int bldc_stm_getPositionPIDErrorSum();
	int bldc_stm_getVelocityPIDError();
	int bldc_stm_getVelocityPIDErrorSum();
	int bldc_stm_getCurrentPIDError();
	int bldc_stm_getCurrentPIDErrorSum();

	void bldc_stm_checkTMC603();

#endif
