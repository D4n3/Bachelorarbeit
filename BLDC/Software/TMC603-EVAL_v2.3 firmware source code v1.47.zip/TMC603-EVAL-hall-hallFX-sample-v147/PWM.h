/*
 * PWM.h
 *
 *  Created on: 20.06.2011
 *      Author: ed
 */

#ifndef PWM_H_
#define PWM_H_

	#include "TMCM-STM.h"
	#include "ADC.h"

	#define PWM_PHASE_A TIM_Channel_1
	#define PWM_PHASE_B TIM_Channel_2
	#define PWM_PHASE_C TIM_Channel_3

	UCHAR pwm_getActualUsedPhase();

	void pwm_scheme_block(UCHAR chopperMode, UCHAR hardStopFlag, int actualPWM, UCHAR actualMotorDirection,  UCHAR hallState, UCHAR motorHaltedFlag);
	void pwm_scheme_HPwmLOn(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag);
	void pwm_scheme_HOffLOn(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag);
	void pwm_scheme_HOnLPwm(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag);
	void pwm_scheme_HPwmLPwm(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag);
	void pwm_scheme_HallFX(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag);

	void pwm_scheme_HOffLOff();
	void pwm_scheme_FullBrake();

	void pwm_set_____hi(USHORT phase);
	void pwm_set_____lo(USHORT phase);
	void pwm_set_pwm_hi(USHORT phase);
	void pwm_set_pwm_lo(USHORT phase);
	void pwm_set____off(USHORT phase);

#endif /* PWM_H_ */
