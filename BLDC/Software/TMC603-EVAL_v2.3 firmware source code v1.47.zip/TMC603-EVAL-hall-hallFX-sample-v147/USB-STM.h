/****************************************************
  Projekt: TMCM-STM

  Modul:   USB-STM.h
           USB-Funktionen

  Datum:   29.4.2010 OK
*****************************************************/

#ifndef USB_STM_H_
#define USB_STM_H_

	#include "TMCM-STM.h"
	#include "SPI-STM.h"

	void usb_stm_initUSB();
	void usb_stm_detachUSB();
	UINT usb_stm_getData(UCHAR *buffer);
	void usb_stm_sendData(UCHAR *buffer, UINT size);
	UCHAR usb_stm_getUSBCmd(UCHAR *cmd);
	void usb_stm_ISTR();

#endif
