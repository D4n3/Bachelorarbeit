/*
 * TMCM-603eval.h
 *
 *  Created on: 14.04.2011
 *      Author: ed (based on work of ok)
 */

#ifndef TMCM_603EVAL_H_
#define TMCM_603EVAL_H_

	#include "SelectModule.h"
	#include "stm32f10x_gpio.h"
	#include "stm32f10x_rcc.h"
	#include "../Bits.h"
	#include "../Definitions.h"
	#include "../ADC.h"

#if DEVICE==TMC603EVAL

	/* device configuration for TMCM-603eval */

	// adc value order
	#define ADC_CH_RANK1  ADC_Channel_11  // current phase A (TMC603)
	#define ADC_CH_RANK2  ADC_Channel_12  // current phase B (TMC603)
	#define ADC_CH_RANK3  ADC_Channel_13  // current phase C (TMC603)
	#define ADC_CH_RANK4  ADC_Channel_10  // voltage
	#define ADC_CH_RANK5  ADC_Channel_14  // motor temperature
	#define ADC_CH_RANK6  ADC_Channel_15  // analog input
	#define ADC_CH_RANK7  ADC_Channel_9   // not used

	#define ADC_PHASE_A    0
	#define ADC_PHASE_B    1
	#define ADC_PHASE_C    2
	#define ADC_VOLTAGE    3
	#define ADC_MOT_TEMP   4
	#define ADC_IN0        5

	// invalid values
	#define ADC_PHASE_U    ADC_INVALID_VALUE
	#define ADC_PHASE_W    ADC_INVALID_VALUE

	#define MIN_LOWSIDE_ONTIME     518	// minimum low side on time for current measurement (518 <-> 7,2�s for PWM=3600)

	// RS242/RS485 configuration
	#define UART_INTERFACE
	#define SET_RS485_SEND_MODE()
	#define SET_RS485_RECEIVE_MODE()
	#define IS_RS485_SENDING() (FALSE)

	// USB interface available
	#define USB_INTERFACE
	#define USB_ENABLE()
	#define USB_DISABLE()

	// SPI devices
	#define SPI_DEV_EEPROM 0
	#define SPI_DEV_IO 3

	// modul number in HEX (603)
	#define SW_TYPE_HIGH 0x02
	#define SW_TYPE_LOW  0x5B

	// used timer IRQ handler
	#define HALL_IRQ_HANDLER      TIM4_IRQ_HANDLER
	#define HALLFX_IRQ_HANDLER    TIM2_IRQ_HANDLER
	#define ENCODER_IRQ_HANDLER   TIM4_IRQ_HANDLER
	#define SCCLK_IRQ_HANDLER     TIM4_IRQ_HANDLER

	// enable (TMC603)
	#define ENABLE_DRIVER()       GPIOC->BSRR=BIT13
	#define DISABLE_DRIVER()      GPIOC->BRR=BIT13
	#define READ_DRIVER_STATE()   (GPIOC->IDR & BIT13)

	// error (TMC603)
	#define ENABLE_CLEAR_ERROR()  GPIOC->BSRR=BIT11
	#define DISABLE_CLEAR_ERROR() GPIOC->BRR=BIT11

	// break before make (TMC603)
	#define ENABLE_BBM()          GPIOC->BSRR=BIT12
	#define DISABLE_BBM()         GPIOC->BRR=BIT12

	// sample (TMC603)
	#define ENABLE_SAMPLE()       GPIOC->BSRR=BIT14
	#define DISABLE_SAMPLE()      GPIOC->BRR=BIT14
	#define TOGGLE_SAMPLE()       (GPIOC->IDR & BIT14) ? (GPIOC->BRR=BIT14) : (GPIOC->BSRR=BIT14)

	// INV_BL (TMC603)
	#define ENABLE_INV_BL()       GPIOC->BSRR=BIT8
	#define DISABLE_INV_BL()      GPIOC->BRR=BIT8

	// SENSE_HI (TMC603), set the current gain
	#define ENABLE_HIGH_SENSE()   GPIOC->BSRR=BIT9
	#define ENABLE_LOW_SENSE()    GPIOC->BRR=BIT9

	// RS_EN (TMC603), enable or disable current
	// measurement via extern sense resistors
	#define DISABLE_EXT_SENSE()    GPIOD->BSRR=BIT2
	#define ENABLE_EXT_SENSE()     GPIOD->BRR=BIT2

	// error (TMC603)
	#define READ_ERROR_STATE()    (GPIOC->IDR & BIT10)

	// Hall sensor inputs
	#define READ_HALL_STATE()     ((GPIOB->IDR >>6) & 0x0007)

	// HallFX inputs
	#define READ_HALLFX_STATE()   (GPIOA->IDR & 0x0007)

	//Low Side outputs
	#define READ_LOWSIDE_STATE()  ((GPIOB->IDR >>13) & 0x0007)

	#define ENABLE_CS_IO()			// not used for the module
	#define DISABLE_CS_IO()			// not used for the module

	// LEDs
	#define SET_LED1()            GPIOB->BSRR=BIT12
	#define RESET_LED1()          GPIOB->BRR=BIT12
	#define TOGGLE_LED1()         (GPIOB->IDR & BIT12) ? (GPIOB->BRR=BIT12) : (GPIOB->BSRR=BIT12)
	#define SET_LED2()            GPIOB->BSRR=BIT5
	#define RESET_LED2()          GPIOB->BRR=BIT5
	#define TOGGLE_LED2()         (GPIOB->IDR & BIT5) ? (GPIOB->BRR=BIT5) : (GPIOB->BSRR=BIT5)
	#define SET_LED3()            GPIOB->BSRR=BIT2
	#define RESET_LED3()          GPIOB->BRR=BIT2
	#define TOGGLE_LED3()         (GPIOB->IDR & BIT2) ? (GPIOB->BRR=BIT2) : (GPIOB->BSRR=BIT2)

	// standard LEDs
	#define LED_TEMP_ON()         SET_LED3()
	#define LED_TEMP_OFF()        RESET_LED3()
	#define LED_TEMP_TOGGLE()     TOGGLE_LED3()
	#define LED_OVC_ON()          SET_LED2()
	#define LED_OVC_OFF()         RESET_LED2()
	#define LED_OVC_TOGGLE()      TOGGLE_LED2()

	#define ENABLE_CS_MEM() 	GPIOA->BSRR=BIT4;
	#define DISABLE_CS_MEM()	GPIOA->BRR=BIT4;

	// max. PWM value (3600 => 100%)
	#define MAX_PWM_VALUE 3600

	// max. sine amplifier (1800 => 100%)
	#define MAX_SINE_PWM  1800

	// digital filter for hall sensor inputs (11 <-> 1333 nsec) =(16*6)/72MHz
	#define HALL_INPUT_FILTER     0x0B

	// digital filter for encoder inputs (2 <-> 55 nsec) =(1*4)/72MHz
	#define ENCODER_INPUT_FILTER  0x02

	// current gain factors (A*100)
	#define CURRENT_GAIN_LOW      482   //A=4.82
	#define CURRENT_GAIN_HIGH     2080  //A=20.8

	// reciprocal value of the sense resistors
	#define CURRENT_SENSE_EXT     100   //R=0.01
	#define CURRENT_SENSE_INT     62    //R=0.00625+0.01 (ACHTUNG: R_sense muss auf den RDSon addiert werden, da sich der R_sense im Fusspunkt befindet)

	// max. temperature (voltage divider 10kOhm/2.2kOhm an 3.3V)
	#define MIN_CRITICAL_TEMP     2385  //100�C
	#define MIN_SWITCHON_TEMP     2572  //110�C
	#define MAX_CRITICAL_TEMP     2740  //120�C

	// max. supply voltage
	#define MAX_SUPPLY_VOLTAGE    3554  //54V (voltage divider 100kOhm/5.6kOhm)

	// min. supply voltage
	#define MIN_SUPPLY_VOLTAGE    790   //12V (voltage divider 100kOhm/5.6kOhm)

	// voltage scaling factor
	#define VOLTAGE_SCALING_FACTOR 66   //Factor=(4096*5.6k)/(3.3V*(100k+5.6k))
                                      	//(100k und 5.6k sind Widerst�nde des Spannungsteilers)

	// default values for global TMCL parameter
	#define DEFAULT_MAX_POSITIONING_SPEED			4000
	#define DEFAULT_HALLFX_SPEED_THRESHOLD			2000
	#define DEFAULT_PWM_LIMIT						3599
	#define DEFAULT_MAXIMUM_CURRENT					4000
	#define DEFAULT_MVP_TARGET_REACHED_VELOCITY		500
	#define DEFAULT_MIN_VEL_PID_SPEED              	0	// vel PID speed threshold
	#define DEFAULT_MVP_TARGET_REACHED_DISTANCE		5
	#define DEFAULT_MOTOR_HALTED_VELOCITY			5
	#define DEFAULT_ACCELERATION                    2000
	#define DEFAULT_MIN_POS_PID_SPEED				0	// pos PID speed threshold
	#define DEFAULT_PID_POS_PPARAM                	500
	#define DEFAULT_PID_POS_IPARAM                 	0
	#define DEFAULT_PID_POS_DPARAM                 	0
	#define DEFAULT_PID_POS_ICLIPPING             	500
	#define DEFAULT_PID_REGULATION_DELAY			1
	#define DEFAULT_CURRENT_REGULATION_DELAY		1
	#define DEFAULT_PWM_HYSTERESIS					0
	#define DEFAULT_PID_VEL_PPARAM					200
	#define DEFAULT_PID_VEL_IPARAM					200
	#define DEFAULT_PID_VEL_DPARAM					0
	#define DEFAULT_PID_VEL_ICLIPPING				500
	#define DEFAULT_VELOCITY_PID_CONTROL			1
	#define DEFAULT_COMMUTATION_MODE				0
	#define DEFAULT_STOP_SWITCH_ENABLE				0
	#define DEFAULT_STOP_SWITCH_POLARITY			0
	#define DEFAULT_HALL_INVERT_FLAG				0
	#define DEFAULT_MOTOR_POLES						8
	#define DEFAULT_HARD_STOP_FLAG					0
	#define DEFAULT_INIT_SINE_SPEED					200
	#define DEFAULT_COMMUTATION_OFFSET_CCW			0
	#define DEFAULT_COMMUTATION_OFFSET_CW			0
	#define DEFAULT_INIT_SINE_DELAY					1000
	#define DEFAULT_MASS_INERTIA_CONST				0
	#define DEFAULT_RDS_ON							0
	#define DEFAULT_INIT_SINE_MODE					0
	#define DEFAULT_OVERVOLTAGE_PROTECTION			1
	#define DEFAULT_ENCODER_DIRECTION				0
	#define DEFAULT_BLOCK_PWM_SCHEME				0
	#define DEFAULT_PID_SLOW_CUR_PPARAM				50
	#define DEFAULT_PID_SLOW_CUR_IPARAM				50
	#define DEFAULT_PID_SLOW_CUR_DPARAM				0
	#define DEFAULT_PID_SLOW_CUR_ICLIPPING         	500
	#define DEFAULT_PID_FAST_CUR_PPARAM				60
	#define DEFAULT_PID_FAST_CUR_IPARAM				80
	#define DEFAULT_PID_FAST_CUR_DPARAM				0
	#define DEFAULT_PID_FAST_CUR_ICLIPPING			1000
	#define DEFAULT_PID_CUR_VTHRESHOLD				0  // current PID speed threshold
	#define DEFAULT_START_CURRENT                 	1500
	#define DEFAULT_ENCODER_STEPS					4000
	#define DEFAULT_ENCODER_COMMUTATION_OFFSET		0
	#define DEFAULT_ENCODER_FLAGS					0
	#define DEFAULT_BEMF_CONST						0
	#define DEFAULT_MOTOR_COIL_RESISTANCE			720
	#define DEFAULT_PID_POS_HIGH_PPARAM           	4000
	#define DEFAULT_PID_POS_HIGH_IPARAM				0
	#define DEFAULT_PID_POS_HIGH_DPARAM				0
	#define DEFAULT_PID_POS_HIGH_ICLIPPING    		1000
	#define DEFAULT_PID_VEL_HIGH_PPARAM				800
	#define DEFAULT_PID_VEL_HIGH_IPARAM				800
	#define DEFAULT_PID_VEL_HIGH_DPARAM				0
	#define DEFAULT_PID_VEL_HIGH_ICLIPPING			1000
	#define DEFAULT_SINE_COMPENSATION_FACTOR		1
	#define DEFAULT_EXTERNAL_SHUNT					1
	#define DEFAULT_POSITIONING_FLAGS				0

	#define DEFAULT_EthercatTimeout					500

	#define DEFAULT_IIT_LIMIT						211200		// 4A*4A �ber 13200ms
	#define DEFAULT_IIT_EXCEED_COUNTER				0
	#define DEFAULT_THERMAL_WINDING_TIME_CONSTANT	13200		// ms

	#define N_O_MOTORS 1

	#define RESET_WATCHDOG()

	// functions needed by libTMC
	void tmcm_initModuleSpecificADC();
	unsigned char tmcm_initModuleSpecificIO();
	void tmcm_clearModuleSpecificIOPin(unsigned char pin);
	void tmcm_setModuleSpecificIOPin(unsigned char pin);
	unsigned char tmcm_getModuleSpecificIOPin(unsigned char pin);
	unsigned char tmcm_getModuleSpecificIOPinStatus(unsigned char pin);
	unsigned int tmcm_getModuleSpecificADCValue(unsigned char pin);

#endif /* DEVICE==TMC603EVAL */

#endif /* TMCM_603EVAL_H_ */
