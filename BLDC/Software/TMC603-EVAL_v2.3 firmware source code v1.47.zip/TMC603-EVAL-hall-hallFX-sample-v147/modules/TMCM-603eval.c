/*
 * TMCM-603eval.c
 *
 *  Created on: 22.06.2011
 *      Author: ed
 */
#include "TMCM-603eval.h"

#if DEVICE==TMC603EVAL

const char *VersionString="603V1.47";

/* expected by the libTMC library for the adc_stm_initADC() function */
void tmcm_initModuleSpecificADC()
{
	GPIO_InitTypeDef GPIOInit;

	GPIOInit.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIOInit.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOC, &GPIOInit);
}

/* expected by the libTMC library for IO_init()*/
unsigned char tmcm_initModuleSpecificIO()
{
	// port A
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	// outputs port A
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIOA->BSRR=BIT4;

	// port B
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	// outputs port B
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_10|GPIO_Pin_9|GPIO_Pin_5|GPIO_Pin_4|GPIO_Pin_3|GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIOB->BSRR=BIT9;

	// inputs port B
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_1|GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// port C
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

	// outputs port C
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14|GPIO_Pin_13|GPIO_Pin_12|GPIO_Pin_11|GPIO_Pin_9|GPIO_Pin_8|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIOC->BSRR=BIT14|BIT12;

	// inputs port C without pull up
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10|GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	// analog inputs port C
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_4|GPIO_Pin_3|GPIO_Pin_2|GPIO_Pin_1|GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	// port D
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);

	// outputs port D
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	// check if pin RxD and TxD are connected -> then set the module back to factory default
	unsigned int Count1 = 0, Count2 = 0, i, t;

	for(i=0; i<10; i++)
	{
		GPIOB->BRR=BIT10;
	    for(t=0; t<1000; t++);
	    if(!(GPIOB->IDR & BIT11))
	    	Count1++;

	    GPIOB->BSRR=BIT10;
	    for(t=0; t<1000; t++);
	    if((GPIOB->IDR & BIT11))
	    	Count2++;
	}
	if(Count1==10 && Count2==10)
		return TRUE;
	else
	    return FALSE;
}

void tmcm_clearModuleSpecificIOPin(unsigned char pin)
{
	pin = 0; // to prevent compiler warning
}

void tmcm_setModuleSpecificIOPin(unsigned char pin)
{
	pin = 0; // to prevent compiler warning
}

unsigned char tmcm_getModuleSpecificIOPin(unsigned char pin)
{
	switch (pin)
	{
		case 0:
			return (GPIOB->IDR & BIT0) ? 1:0;
			break;
		case 1:
			return (GPIOB->IDR & BIT1) ? 1:0;
			break;
		default:
			return 0;
	}
}

unsigned char tmcm_getModuleSpecificIOPinStatus(unsigned char pin)
{
	pin = 0; // to prevent compiler warning
	return 0;
}

unsigned int tmcm_getModuleSpecificADCValue(unsigned char pin)
{
	switch(pin)
	{
		case 0: // rotary regulator
			return adc_getADCValue(ADC_IN0);
			break;
		default:
			return 0;
	}
}

#endif
