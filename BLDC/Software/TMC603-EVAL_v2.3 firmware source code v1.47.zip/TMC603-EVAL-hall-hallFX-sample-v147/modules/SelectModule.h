/*
 * SelectModule.h
 *
 *  Created on: 22.06.2011
 *      Author: ed
 */

#ifndef SELECTMODULE_H_
#define SELECTMODULE_H_

	// define module type
	#define TMC603EVAL      	1
	#define TMCM603EVAL_V2_3	11

	// select the actual module
//	#define DEVICE TMC603EVAL
	#define DEVICE TMCM603EVAL_V2_3

#endif /* SELECTMODULE_H_ */
