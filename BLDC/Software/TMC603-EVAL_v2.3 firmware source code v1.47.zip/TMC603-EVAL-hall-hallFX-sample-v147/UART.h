/****************************************************
  Projekt: TMCM-STM

  Modul:   UART.h
           UART-Funktionen (Bytes Senden/Empfangen)

  Datum:   6.3.2009 OK (reworked by ed)
*****************************************************/

#ifndef UART_H_
#define UART_H_

	#include "TMCM-STM.h"

	void uart_init(int baudRate);
	void uart_write(char ch);
	char uart_read(char *ch);
	void uart_printDebug(char *message);

	void uart_setTransmitDelay(UINT Delay);
	UINT uart_checkTimeout();

#endif
