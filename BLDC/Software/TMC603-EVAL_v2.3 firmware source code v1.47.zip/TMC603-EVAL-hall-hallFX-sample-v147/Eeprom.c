/****************************************************
  Projekt: TMCM-STM

  Modul:   Eeprom.c
           Zugriff auf das externe EEPROM (AT25128)

  Datum:   30.3.2007 OK (reworked by ed)
*****************************************************/

#include "Eeprom.h"

/* initialize the eeprom and read the default parameters from eeprom */
void eeprom_init()
{
	// initialize the eeprom
	if (eeprom_readConfigByte(ADDR_EEPROM_MAGIC) != EEPROM_MAGIC || ResetToFactoryDefaultRequested)
	{
		eeprom_writeConfigByte(ADDR_EEPROM_MAGIC, 0);

		// overwrite module specific values (0..63)
		eeprom_writeConfigBlock(ADDR_MODULE_CONFIG, (UCHAR *)&ModuleConfig, SIZE_MODULE_CONFIG);
		// overwrite first motor configuration (64..319)
		eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+0*SIZE_MOTOR_CONFIG, (UCHAR *)&MotorConfig[0], SIZE_MOTOR_CONFIG);
		// overwrite second motor configuration (320..575)
		eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+1*SIZE_MOTOR_CONFIG, (UCHAR *)&MotorConfig[0], SIZE_MOTOR_CONFIG);
		// update magic byte
		eeprom_writeConfigByte(ADDR_EEPROM_MAGIC, EEPROM_MAGIC);
	}

	// read the default module configuration from EEPROM
	eeprom_readConfigBlock(ADDR_MODULE_CONFIG, (UCHAR *)&ModuleConfig, SIZE_MODULE_CONFIG);

	// read the default motor configurations from EEPROM
	UINT i;
	for (i = 0; i < N_O_MOTORS; i++)
		eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+i*SIZE_MOTOR_CONFIG, (UCHAR *)&MotorConfig[0], SIZE_MOTOR_CONFIG);
}

/* write a byte into the configuration eeprom (address: 0..2047) */
void eeprom_writeConfigByte(UINT address, UCHAR value)
{
	// enable writing
	spi_stm_readWrite(SPI_DEV_EEPROM, 0x06, TRUE);  // command "Write Enable"
	do
	{
		spi_stm_readWrite(SPI_DEV_EEPROM, 0x05, FALSE);  // command "Get Status"
	} while((spi_stm_readWrite(SPI_DEV_EEPROM, 0x00, TRUE) & 0x02)==0x00);  // wait until "Write Enable"-Bit is set

	// write
	spi_stm_readWrite(SPI_DEV_EEPROM, 0x02, FALSE); // command "Write"
	spi_stm_readWrite(SPI_DEV_EEPROM, address >> 8, FALSE);
	spi_stm_readWrite(SPI_DEV_EEPROM, address & 0xff, FALSE);
	spi_stm_readWrite(SPI_DEV_EEPROM, value, TRUE);

	// wait until write is finished
	do
	{
		spi_stm_readWrite(SPI_DEV_EEPROM, 0x05, FALSE);  // command "Get Status"
	} while(spi_stm_readWrite(SPI_DEV_EEPROM, 0x00, TRUE) & 0x01);
}

/* read a byte from the configuration eeprom (address: 0..2047) */
UCHAR eeprom_readConfigByte(UINT address)
{
	spi_stm_readWrite(SPI_DEV_EEPROM, 0x03, FALSE);  //Befehl "Read"
	spi_stm_readWrite(SPI_DEV_EEPROM, address >> 8, FALSE);
	spi_stm_readWrite(SPI_DEV_EEPROM, address & 0xff, FALSE);
	return spi_stm_readWrite(SPI_DEV_EEPROM, 0, TRUE);
}

/* write a block into the configuration eeprom (using eeprom 25128),
 * (address: (0..2047) (block: start address of the block) */
void eeprom_writeConfigBlock(UINT address, UCHAR *block, UINT size)
{
	// enable reading
	spi_stm_readWrite(SPI_DEV_EEPROM, 0x06, TRUE);  // command "Write Enable"
	do
	{
		spi_stm_readWrite(SPI_DEV_EEPROM, 0x05, FALSE);  // command "Get Status"
	} while((spi_stm_readWrite(SPI_DEV_EEPROM, 0x00, TRUE) & 0x02)==0x00);  // wait until "Write Enable"-Bit is set

	// write (Startadresse)
	spi_stm_readWrite(SPI_DEV_EEPROM, 0x02, FALSE); //Befehl "Write"
	spi_stm_readWrite(SPI_DEV_EEPROM, address >> 8, FALSE);
	spi_stm_readWrite(SPI_DEV_EEPROM, address & 0xff, FALSE);

	// write data
	UINT i;
	for(i=0; i<size; i++)
	{
		//Adresse mitz�hlen und bei �berlauf der untersten sechs Bits das EEPROM deselektieren
		//und neuen Write-Befehl senden (bzw. beim letzten Datenbyte einfach nur EEPROM
		//deselektieren).
		//Dies ist erforderlich, da beim Beschreiben im 25128 nur die untersten sechs Bits der
		//Adresse hochgez�hlt werden (anders als beim Lesen).
		address++;
		spi_stm_readWrite(SPI_DEV_EEPROM, *(block+i), (address & 0x0000003f)==0 || i==size-1);
		if((address & 0x0000003f)==0 && i<size-1)  //Adressbits �bergelaufen, aber noch Bytes zu schreiben?
		{
			//Warte bis Schreibvorgang beendet
			do
			{
				spi_stm_readWrite(SPI_DEV_EEPROM, 0x05, FALSE);  //Befehl "Get Status"
			} while(spi_stm_readWrite(SPI_DEV_EEPROM, 0x00, TRUE) & 0x01);

			//Neuer "Write Enable"-Befehl
			spi_stm_readWrite(SPI_DEV_EEPROM, 0x06, TRUE);  //Befehl "Write Enable"
			do
			{
				spi_stm_readWrite(SPI_DEV_EEPROM, 0x05, FALSE);  //Befehl "Get Status"
			} while((spi_stm_readWrite(SPI_DEV_EEPROM, 0x00, TRUE) & 0x02)==0x00);  //Warte bis "Write Enable"-Bit gesetzt

			// new "Write" command (mit der n�chsten Adresse)
			spi_stm_readWrite(SPI_DEV_EEPROM, 0x02, FALSE); // command "Write"
			spi_stm_readWrite(SPI_DEV_EEPROM, address >> 8, FALSE);
			spi_stm_readWrite(SPI_DEV_EEPROM, address & 0xff, FALSE);
		}
	}

	// wait until write finished
	do
	{
		spi_stm_readWrite(SPI_DEV_EEPROM, 0x05, FALSE);  // command "Get Status"
	} while(spi_stm_readWrite(SPI_DEV_EEPROM, 0x00, TRUE) & 0x01);
}

/* read a block from configuration eeprom
 * (address: (0..2047) (block: start address) (size: max. 64)) */
void eeprom_readConfigBlock(UINT address, UCHAR *block, UINT size)
{
	spi_stm_readWrite(SPI_DEV_EEPROM, 0x03, FALSE);  // command "Read"
	spi_stm_readWrite(SPI_DEV_EEPROM, address >> 8, FALSE);
	spi_stm_readWrite(SPI_DEV_EEPROM, address & 0xff, FALSE);

	UINT i;
	for(i=0; i<size; i++)
		*(block+i) = spi_stm_readWrite(SPI_DEV_EEPROM, 0, i==size-1);  //beim letzten Byte EEPROM deselektieren
}
