/*
 * Debug.c
 *
 *  Created on: 14.07.2011
 *      Author: ed
 */

#include "Debug.h"

// test/debug variables
int gTestVar0, gTestVar1, gTestVar2, gTestVar3, gTestVar4, gTestVar5, gTestVar6, gTestVar7;

int debug_getTestVar0()
{
	return gTestVar0;
}

int debug_getTestVar1()
{
	return gTestVar1;
}

int debug_getTestVar2()
{
	return gTestVar2;
}

int debug_getTestVar3()
{
	return gTestVar3;
}

int debug_getTestVar4()
{
	return gTestVar4;
}

int debug_getTestVar5()
{
	return gTestVar5;
}

int debug_getTestVar6()
{
	return gTestVar6;
}

int debug_getTestVar7()
{
	return gTestVar7;
}

void debug_setTestVar0(int value)
{
	gTestVar0 = value;
}

void debug_setTestVar1(int value)
{
	gTestVar1 = value;
}

void debug_setTestVar2(int value)
{
	gTestVar2 = value;
}

void debug_setTestVar3(int value)
{
	gTestVar3 = value;
}

void debug_setTestVar4(int value)
{
	gTestVar4 = value;
}

void debug_setTestVar5(int value)
{
	gTestVar5 = value;
}

void debug_setTestVar6(int value)
{
	gTestVar6 = value;
}

void debug_setTestVar7(int value)
{
	gTestVar7 = value;
}
