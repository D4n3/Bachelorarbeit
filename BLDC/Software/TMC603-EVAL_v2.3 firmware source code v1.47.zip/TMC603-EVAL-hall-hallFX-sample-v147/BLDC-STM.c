/****************************************************
  Projekt: TMCM-STM

  Modul:   BLDC-STM.c
           Steuerung des BLDC-Motors

  Datum:   25.5.2009 OK / ed
*****************************************************/

#include "BLDC-STM.h"

	// local variables
	volatile UCHAR 	gActualMotorDirection;	 		// right == 0, left == 1
	volatile float 	gTargetSpeed; 			 		// target speed
	volatile int   	gActualPWMDutyCycle;			// actual set PWM
	int				gPWMDutyCycle;                 	// computed desired PWM
	volatile int   	gTargetMotorCurrent;			// desired motor current
	volatile int   	gActualMotorSpeed;				// actual computed motor speed
	int				gDesiredMotorSpeed;				// requested motor speed
	float 		   	gRampTargetSpeed;				// targetSpeed of the velocity ramp
	volatile int   	gTargetPWM;						// desired pwm
	volatile int   	gActualMotorCurrent;     		// last scaled motor current [mA]
	volatile int   	gMeasuredMotorCurrent;			// last measured motor current (0...8838)
	float 			gStartPWMSum;					// the actual PWM (used to reach the desired start current in controlled mode)
	volatile int   	gControlledEncoderStep; 		// encoder step used for controlled sine initialization
	volatile int 	gTargetMotorPosition=0;    		// desired motor position
	volatile int 	gActualMotorPosition; 			// actual motor position
	volatile int 	gEncoderCounter;				// actual encoder value
	int 			gOldEncoderCounter = 0;			// old encoder counter
	int 			gEncoderSpeed;					// actual encoder speed
	UINT			gSineWaveCount;					// used for encoder based sine initialization
	volatile UCHAR 	gHallStateDetectedFlag = 0;		// TRUE if sinus commutation offset ins sine mode 1 has been set
	volatile int 	gSineHallInitPositionCounter;	// hall position counter for sine initialization in mode 1
	volatile UCHAR	gHallState;          			// actual hall sensor state
	volatile UCHAR	gPreviousHallState;  			// previous hall sensor state
	int				gActualSetRegulationMode;		// actual regulation mode
	int 			gWrongFxDirectionCounter;		// counter for hallFxDirection != targetDirection
	int 			gHallFXDirection;				// actual measured hallFX direction
	int 			gTempEncoderDiff;

	// private functions
	void bldc_stm_updateActualSpeed(UCHAR resetCounter);
	void bldc_stm_checkSupplyVoltage();
	void bldc_stm_checkMotorTemperature();
	void bldc_stm_initCurrentMeasurement();
	void bldc_stm_switchToRegulationMode(int mode);

	UINT bldc_stm_getErrorFlags();
	void bldc_stm_resetErrorFlags();

	#define TIM1_PWM_FREQ (72000000/MAX_SINE_PWM/2)  	//PWM-Frequenz bei Up/Down PWM f�r Sinuskommutierung
	#define HALL_TIM_CLK   36000000          			//Taktfrequenz des Hall-Timers in Hz
	#define CURRENT_REFRESH_DELAY     1      			//Delay zur Aktualisierung der Strommessung

	volatile UCHAR motorHaltedFlag;						// TRUE if motor is halted
	static int NewRpmValue;                  			//Drehzahl*1000 f�r gesteuerte Blockkommutierung
	static int NewSpeedScaled;               			//skalierte Drehzahl f�r gesteuerte Blockkommutierung

	//Flags
	static volatile UCHAR isCurrentMeasurementOnceInitialized;  // TRUE if current measurement has been initialized after power on
	static volatile UCHAR InitStartCurrentFlag;
	static volatile UCHAR HallFXFlag;             				//TRUE wenn Kommutierungsmodus HallFX aktiv ist
	static volatile UINT gStatusFlags;							// error and status flags (Overvoltage, Overcurrent,...)
	static volatile UCHAR HallFXState;        					//Zustand f�r die State Machine im HallFX-Betrieb

	//Time Tick
	volatile UINT pidRegulationTickTimer=0;     	// time tick for revolution regulation
	volatile UINT currentRegulationTickTimer=0; 	//Time Tick f�r Stromregelung
	volatile UINT currentRefreshTickTime=0;     	//Time Tick f�r Aktualisierung der Strommessung
	volatile UINT ChangeCommModeDelay=0;        	//Delay Time f�r Wechsel zwischen zwei Kommutierungsmodi

	TPIDControl PositionPID;                    //Variablen f�r Positionsregler
	TPIDControl VelocityPID;                    //Variablen f�r Drehzahlregler
	TPIDControl CurrentPID;						//Variablen f�r Stromregler

	UCHAR HallPattFor[]   = {  000,  015,  023,  031,  046,  054,  062,  000};  //vergangener Hall-Wert, aktueller Hall-Wert
	UCHAR HallPattRev[]   = {  000,  013,  026,  032,  045,  051,  064,  000};  //vergangener Hall-Wert, aktueller Hall-Wert

	UCHAR HallPattSeq[]   = { 0x00, 0x11, 0x13, 0x12, 0x15, 0x10, 0x14, 0x00};  //Hallsensor Sequenz zur Bestimmung der Drehrichtung
	UCHAR HallFXPattSeq[] = { 0x00, 0x14, 0x10, 0x15, 0x12, 0x13, 0x11, 0x00};  //HallFX Sequenz

	static char HallPattSeqOld;

/*******************************************************************
   Funktion: CheckTMC603
   Zweck: �berwachen und Wiedereinschalten des TMC603.
          Aufruf aus der Hauptschleife heraus.
********************************************************************/
void bldc_stm_checkTMC603()
{
	static UCHAR TMC603ErrorCount=0;
	static UINT lastTMC603Check;

	if(abs(systick_stm_getTimer() - lastTMC603Check) > 1000)
	{
		if(!(READ_ERROR_STATE()))  //Short to Ground?
		{
			//Overcurrent Flag setzen
			//(nicht setzen wenn TMC603 Driver per Software deaktiviert wurde)
			if(READ_DRIVER_STATE()!=FALSE)
			{
				bldc_stm_setStatusFlag(OVERCURRENT);
				if(TMC603ErrorCount <= 10)
					TMC603ErrorCount++;
			}

			//Alles ausschalten
			gTargetSpeed = 0;
			gDesiredMotorSpeed = 0;
			gPWMDutyCycle = 0;

			//Fehlerzustand im TMC603 zur�cksetzen
			//(nicht zur�cksetzen wenn TMC603 Driver per Software deaktiviert wurde)
			if(READ_DRIVER_STATE() != FALSE)
			{
				//Wenn Fehler l�nger als 10ms anh�lt, dann nicht mehr zur�cksetzen
				if(TMC603ErrorCount <= 10)
				{
					ENABLE_CLEAR_ERROR();
					DISABLE_CLEAR_ERROR();
				}
			}
		} else {                     //no error
			TMC603ErrorCount=0;
		}
		lastTMC603Check = systick_stm_getTimer();
	}
}

/* zur �berwachung und zum Ausschalten des TMC603 bei �berspannung */
void bldc_stm_checkSupplyVoltage()
{
	static UINT lastCheckTime;

	if(abs(systick_stm_getTimer()-lastCheckTime) > 1000)
	{
		if(MotorConfig[0].OvervoltageProtection==TRUE)
		{
			if(adc_getADCValue(ADC_VOLTAGE) >= MAX_SUPPLY_VOLTAGE)
			{
				DISABLE_DRIVER();
				bldc_stm_setStatusFlag(OVERVOLTAGE);
			}
		}
		//Wenn nach dem Power On eine Unterspannung detektiert wird,
		//ist der TMC603 deaktiviert und es kann die Initialisierung
		//der Strommessung nicht durchgef�hrt werden. Das Untervoltage
		//Flag bleibt aktiv, bis keine Unterspannung mehr besteht und
		//die Initialisierung der Strommessung erfolgreich war.
		if((adc_getADCValue(ADC_VOLTAGE) <= MIN_SUPPLY_VOLTAGE) || !isCurrentMeasurementOnceInitialized)
			bldc_stm_setStatusFlag(UNDERVOLTAGE);

		if(adc_getADCValue((ADC_VOLTAGE)>((MIN_SUPPLY_VOLTAGE*19)/20)) || isCurrentMeasurementOnceInitialized)
			bldc_stm_clearStatusFlag(UNDERVOLTAGE);

		lastCheckTime = systick_stm_getTimer();
	}
}

/* monitor the motor temperature and turn off the motor on over temperature */
void bldc_stm_checkMotorTemperature()
{
	static UINT lastCheckTime;

	if(abs(systick_stm_getTimer()-lastCheckTime) > 250)
	{
		UINT adcMotorTemp = adc_getADCValue(ADC_MOT_TEMP);
		if(!bldc_stm_isStatusFlagSet(OVERTEMPERATURE))
		{
			if(adcMotorTemp >= MAX_CRITICAL_TEMP)
			{
				bldc_stm_setStatusFlag(OVERTEMPERATURE);
				LED_TEMP_ON();
				DISABLE_DRIVER();
			}else if(adcMotorTemp >= MIN_CRITICAL_TEMP){
				bldc_stm_clearStatusFlag(OVERTEMPERATURE);
				LED_TEMP_TOGGLE();
				if(!READ_DRIVER_STATE() && !bldc_stm_getErrorFlags() && !bldc_stm_isStatusFlagSet(FREERUNNING))
					ENABLE_DRIVER();
			}else{
				bldc_stm_clearStatusFlag(OVERTEMPERATURE);
				LED_TEMP_OFF();
				if(!READ_DRIVER_STATE() && !bldc_stm_getErrorFlags() && !bldc_stm_isStatusFlagSet(FREERUNNING))
					ENABLE_DRIVER();
			}
		}else{
			if(adcMotorTemp < MIN_SWITCHON_TEMP)
			{
				bldc_stm_clearStatusFlag(OVERTEMPERATURE);
				LED_TEMP_TOGGLE();
				if(!READ_DRIVER_STATE() && !bldc_stm_getErrorFlags() && !bldc_stm_isStatusFlagSet(FREERUNNING))
					ENABLE_DRIVER();
			}
		}
    	lastCheckTime = systick_stm_getTimer();
	}
}

/* init current measurement (set Zero-offset for current measurement) */
void bldc_stm_initCurrentMeasurement()
{
	// simple current initialization
	adc_setOffset(ADC_PHASE_A, 2048);
	adc_setOffset(ADC_PHASE_B, 2048);
	adc_setOffset(ADC_PHASE_C, 2048);
}

void bldc_stm_init()
{
	ENABLE_HIGH_SENSE();    									// enable high_sense of the TMC603
	adc_setTMC603GainFlag(TRUE);

	timer_initPWMTimer(MotorConfig[0].CommutationMode);			// configure TIM1 for motor pwm
	timer_initHallTimer(MotorConfig[0].CommutationMode);    	// configure TIM2 or TIM4 for hall signals
	timer_initHallFXTimer(MotorConfig[0].CommutationMode);		// configure TIM2 or TIM4 for hallFX signals
	timer_initSCClockTimer(MotorConfig[0].CommutationMode);		// configure TIM2 or TIM4 for SCCLK-beat

	bldc_stm_setStatusFlag(MODULE_INITIALIZED);

	DISABLE_INV_BL();     										//INV_BL TMC603 ausschalten
    if(MotorConfig[0].ExternalShunt)
    {
    	ENABLE_EXT_SENSE();    									//Strommessung �ber externe Rsense einschalten
    	adc_setExtSenseFlag(TRUE);
    }else{
    	DISABLE_EXT_SENSE();  									//Strommessung �ber externe Rsense ausschalten
    	adc_setExtSenseFlag(FALSE);
    }

    ENABLE_BBM();           //Break Before Make TMC603 einschalten
    ENABLE_SAMPLE();        //Sample TMC603 einschalten

    if(!READ_DRIVER_STATE() && !bldc_stm_getErrorFlags() && !bldc_stm_isStatusFlagSet(FREERUNNING))
    	ENABLE_DRIVER();

    // set Zero-offset for current measurement
    bldc_stm_initCurrentMeasurement();
}

/* update/change the actual commutation mode */
void bldc_stm_updateCommutationMode()
{
	static UCHAR lastCommMode;

	//Zum Verlassen des HallFX-Betriebs
	if ((HallFXFlag == TRUE) &&
		(HallFXState == HALLFX_STATE_STOP) &&
		(lastCommMode == COMM_MODE_BLOCK_HALLFX))
	{
		if(MotorConfig[0].CommutationMode!=COMM_MODE_BLOCK_HALLFX)
		{
			HallFXFlag=FALSE;
			MotorConfig[0].BlockPwmScheme=CHOP_MODE_HIGH_SIDE;

			//Variablen der PID-Regler zur�cksetzen
			gPWMDutyCycle=0;
  			pid_resetPIDControl(&VelocityPID);
  			pid_resetPIDControl(&PositionPID);
  			pid_resetPIDControl(&CurrentPID);
		}
	}

	//Nur neu konfigurieren, wenn HallFX-Betrieb nicht aktiv ist
	if(HallFXFlag != TRUE)
	{
		//Wenn Kommutierungsmodus ge�ndert, dann neu konfigurieren.
		if(lastCommMode != MotorConfig[0].CommutationMode)
		{
			if(MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_CONTROLLED)
			{
				NewRpmValue=1000;
				NewSpeedScaled=U16_MAX;
			}
			bldc_stm_init();
		}
	}

	lastCommMode = MotorConfig[0].CommutationMode;
}

/* check hall state on validity */
void bldc_stm_checkHallsensor()
{
	if (MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALL)
	{
		if((READ_HALL_STATE() == 0) || (READ_HALL_STATE() == 7))
			bldc_stm_setStatusFlag(HALLERROR);
	}
}

/* state machine for hallFX using controlled block/sine */
static void StateMachineHallFX()
{
	static float tCurrent = 0;
	static UINT lastClearTime;
	// reset HallFX state machine on motor stop
	if(gDesiredMotorSpeed == 0)
	{
		// switch to PWM mode to prevent high current on commutation mode change
		// (keep regulation combined with wrong position/velocity signals during switch over in mind)
		bldc_stm_setTargetPWM(0);
		MotorConfig[0].CommutationMode = COMM_MODE_BLOCK_HALLFX;
		MotorConfig[0].BlockPwmScheme = CHOP_MODE_HALLFX;
		bldc_stm_init();

		HallFXState = HALLFX_STATE_STOP;
	}

	switch(HallFXState)
	{
		case HALLFX_STATE_STOP:
			gTargetSpeed = 0;
			tCurrent = 0;
			InitStartCurrentFlag = FALSE;

			// reset current regulator to clear it's errorSum
			pid_resetPIDControl(&CurrentPID);

			// set target current to zero
			bldc_stm_setTargetMotorCurrent(tCurrent);

			if(gDesiredMotorSpeed != 0)
				HallFXState = HALLFX_STATE_INITSTART;
			break;
		case HALLFX_STATE_INITSTART:
			// initialize in controlled block mode
			MotorConfig[0].BlockPwmScheme = CHOP_MODE_HIGH_SIDE;
			MotorConfig[0].CommutationMode = COMM_MODE_BLOCK_CONTROLLED;
			bldc_stm_init();
			ChangeCommModeDelay = 0;
			HallFXState = HALLFX_STATE_WAIT_FOR_CURRENT;
			break;
		case HALLFX_STATE_WAIT_FOR_CURRENT:
			if (ChangeCommModeDelay >= 100) // 1000 //200
				HallFXState = HALLFX_STATE_SETCURRENT;
			break;
		case HALLFX_STATE_SETCURRENT:
			// increase the target current slowly before ramp up
			if (abs(tCurrent) < (int)MotorConfig[0].StartCurrent)
			{
				if (gDesiredMotorSpeed >= 0)
					tCurrent += 0.05; // 0.01
				else if (gDesiredMotorSpeed < 0)
					tCurrent -= 0.05; // 0.01
			}

			bldc_stm_setTargetMotorCurrent(tCurrent);

			// start in sine/block commutation if start current has been reached
			if (abs(tCurrent) >= (int)MotorConfig[0].StartCurrent)
			{
				InitStartCurrentFlag = READY;
				HallFXState = HALLFX_STATE_RAMP_BLOCK;
			}
			break;
		case HALLFX_STATE_RAMP_BLOCK:
			// switch to hallFX mode
			if (abs(gActualMotorSpeed) >= MotorConfig[0].hallFXSpeedThreshold)
			{
	  			// preset the error sum of the velocity regulator
				// (that would otherwise lead to a bad switch to velocity mode if desired
				// velocity had been switched from positive to negative or vice versa)
				pid_checkParamSet(&VelocityPID, MotorConfig[0].hallFXSpeedThreshold, MotorConfig[0].PIDVelSpeedThreshold,
						MotorConfig[0].PIDVelSet1_PParam, MotorConfig[0].PIDVelSet1_IParam, MotorConfig[0].PIDVelSet1_DParam, MotorConfig[0].PIDVelSet1_IClipping,
						MotorConfig[0].PIDVelSet2_PParam, MotorConfig[0].PIDVelSet2_IParam, MotorConfig[0].PIDVelSet2_DParam, MotorConfig[0].PIDVelSet2_IClipping);

				int iClipping = VelocityPID.iClipping;
				if (iClipping > 1000)
					iClipping = 1000;

				int iDivisor = 65536;
				int maxIPart = (MotorConfig[0].MaximumCurrent * iClipping)/1000;
				int maxErrorSum = (VelocityPID.iParam == 0) ? 0: (maxIPart * iDivisor) / VelocityPID.iParam;

				if (gDesiredMotorSpeed > 0)
					VelocityPID.errorSum = maxErrorSum/3;
				else if (gDesiredMotorSpeed < 0)
					VelocityPID.errorSum = -maxErrorSum/3;

				// configure timer: hall event leads to timer reset
#if HALLFX_IRQ_HANDLER==TIM2_IRQ_HANDLER
				TIM_SelectSlaveMode(TIM2,TIM_SlaveMode_Reset);
				TIM_ARRPreloadConfig(TIM2, DISABLE);
				TIM_SetAutoreload(TIM2, U16_MAX);
				TIM_ARRPreloadConfig(TIM2, ENABLE);
				TIM_SetCounter(TIM2, 0);
#elif HALLFX_IRQ_HANDLER==TIM4_IRQ_HANDLER
				TIM_SelectSlaveMode(TIM4,TIM_SlaveMode_Reset);
				TIM_ARRPreloadConfig(TIM4, DISABLE);
				TIM_SetAutoreload(TIM4, U16_MAX);
				TIM_ARRPreloadConfig(TIM4, ENABLE);
				TIM_SetCounter(TIM4, 0);
#endif

				MotorConfig[0].CommutationMode = COMM_MODE_BLOCK_HALLFX;
				MotorConfig[0].BlockPwmScheme = CHOP_MODE_HALLFX;
				pwm_scheme_block(MotorConfig[0].BlockPwmScheme, MotorConfig[0].HardStopFlag, gActualPWMDutyCycle, gActualMotorDirection, gHallState, motorHaltedFlag);
				TIM_GenerateEvent(TIM1, TIM_EventSource_COM);

				// switch to velocity mode
				bldc_stm_setTargetVelocity(gDesiredMotorSpeed);
				gWrongFxDirectionCounter = 0;
				lastClearTime = systick_stm_getTimer();
				HallFXState = HALLFX_STATE_RUN;
			}
			break;
		case HALLFX_STATE_RUN:
			// stop if to many direction errors occur
			if (gWrongFxDirectionCounter > 40) // tolerate 40% error rate
			{
				gTargetSpeed = 0;
				gDesiredMotorSpeed = 0;
			}

			// reset error counter every 100ms
			UINT actualClearTime = systick_stm_getTimer();
			if (abs(actualClearTime - lastClearTime) >= 100)
			{
				gWrongFxDirectionCounter = 0;
				lastClearTime = actualClearTime;
			}
			break;
	}
}

/* main regulation function */
void bldc_stm_processBLDC()
{
	// for timing debugging purposes only
	static UINT loopCounterCheckTime;
	static int mainLoopCounter = 0;
	static int currentLoopCounter = 0;
	static int velocityLoopCounter = 0;

	UINT newSystick = systick_stm_getTimer();
	if (abs(newSystick-loopCounterCheckTime) >= 1000)
	{
		// reset main loop counter
		debug_setTestVar0(mainLoopCounter);
		mainLoopCounter = 0;

		// reset current loop counter
		debug_setTestVar1(currentLoopCounter);
		currentLoopCounter = 0;

		// reset velocity loop counter
		debug_setTestVar2(velocityLoopCounter);
		velocityLoopCounter = 0;

		loopCounterCheckTime = newSystick;
	}
	mainLoopCounter++;

	// set status flags
	if(abs(gActualMotorSpeed) <= abs(MotorConfig[0].MotorHaltedVelocity))
		bldc_stm_setStatusFlag(MOTORHALTED);
	else
		bldc_stm_clearStatusFlag(MOTORHALTED);

	if(gTargetSpeed == 0)
	{
		if(MotorConfig[0].HardStopFlag  == STOP_FLAG_EMERGENCY_STOP)
		{
			bldc_stm_clearStatusFlag(FREERUNNING);
			bldc_stm_setStatusFlag(EMERGENCYSTOP);
		} else if(MotorConfig[0].HardStopFlag == STOP_FLAG_FREE_RUNNING) {
			bldc_stm_clearStatusFlag(EMERGENCYSTOP);
			bldc_stm_setStatusFlag(FREERUNNING);
		}
	} else {
		bldc_stm_clearStatusFlag(EMERGENCYSTOP);
		bldc_stm_clearStatusFlag(FREERUNNING);
	}

	// Umschalten zwischen externen Rsense und internen RDSon
	if(MotorConfig[0].ExternalShunt)
	{
		ENABLE_EXT_SENSE();    //Strommessung �ber externe Rsense
		adc_setExtSenseFlag(TRUE);
	}else{
		DISABLE_EXT_SENSE();   //Strommessung �ber interne RDSon
		adc_setExtSenseFlag(FALSE);
	}

	bldc_stm_updateCommutationMode();
	bldc_stm_checkSupplyVoltage();
	bldc_stm_checkMotorTemperature();
	bldc_stm_checkHallsensor();

	// call hallFX state machine, if hallFX is active
	if(HallFXFlag)
		StateMachineHallFX();

	// Pr�fen, ob Low Side zu lange eingeschaltet ist
	// (Aktualisierung der Strommessung nur m�glich, wenn Low Side
	// toggelt oder Sample-Eingang kurzzeitig auf Low geschaltet wird)
	if(currentRefreshTickTime >= CURRENT_REFRESH_DELAY)
	{
		currentRefreshTickTime = 0;
		if((gActualMotorSpeed == 0) || (gActualPWMDutyCycle == 0))
		{
			motorHaltedFlag=TRUE;
			DISABLE_SAMPLE();
			for(int i=0; i<10; i++)
				NOP();
			ENABLE_SAMPLE();
		}else{
			ENABLE_SAMPLE();
			motorHaltedFlag = FALSE;
		}
	}

	// do position and velocity regulation
	if(pidRegulationTickTimer >= MotorConfig[0].PIDRegulationDelay)
	{
		pidRegulationTickTimer = 0;
		velocityLoopCounter++;

		// update the actual velocity
		bldc_stm_updateActualSpeed(FALSE);

  		// position regulation
  		if ((bldc_stm_isStatusFlagSet(MODULE_INITIALIZED) == TRUE) &&
  			(bldc_stm_isStatusFlagSet(POSITION_MODE) == TRUE))
  		{
  			gDesiredMotorSpeed = bldc_regulator_getTargetSpeedFromPositionPIDRegulator(&MotorConfig[0], &PositionPID, gTargetMotorPosition, gActualMotorPosition, gActualMotorSpeed);

			// set POSITION_END flag if target position is reached
			if ((abs(gTargetMotorPosition-gActualMotorPosition) <= MotorConfig[0].MVPTargetReachedDistance) &&
				(abs(gActualMotorSpeed) <= MotorConfig[0].MVPTargetReachedVelocity))
			{
				bldc_stm_setStatusFlag(POSITION_END);
			}
  		}

  		// compute velocity ramps if selected
  		if ((bldc_stm_isStatusFlagSet(MODULE_INITIALIZED) == TRUE) &&
  			(MotorConfig[0].VelocityPIDControl == TRUE))
  		{
  			// ramp generator for position control
  			if (bldc_stm_isStatusFlagSet(POSITION_MODE) == TRUE)
  			{
  				int maxTargetSpeed = MotorConfig[0].MaxPositioningSpeed;
  				int dPosition = 0;

  				// == (v0*v0*pos_steps_per_rotation)/(2*60*acceleration)
  				if(MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALL)
  					dPosition = (gRampTargetSpeed*gRampTargetSpeed*6*(MotorConfig[0].MotorPoles/2))/(2*60*MotorConfig[0].Acceleration);

  				if (gTargetMotorPosition < gActualMotorPosition)
  					maxTargetSpeed = -maxTargetSpeed;

  				// difference between actual and target position is below needed slow down distance => time to speed down to v=0
  				if ((abs(gTargetMotorPosition-gActualMotorPosition) <= dPosition))
  					maxTargetSpeed = 0;

  				if (bldc_stm_isStatusFlagSet(POSITION_END) == TRUE)
  				{
  					// leave ramp because target is reached
  					gRampTargetSpeed = gDesiredMotorSpeed;
  				} else {
  					if (gRampTargetSpeed < maxTargetSpeed)
  					{
  						// accelerate to maxTargetSpeed
  						if (maxTargetSpeed == 0)
  						{
  							// allow faster ramp down to zero to prevent overshooting at target position
  							gRampTargetSpeed += (float)(MotorConfig[0].Acceleration*MotorConfig[0].PIDRegulationDelay)/(float)(1000);
  						} else {
  							gRampTargetSpeed += (float)(MotorConfig[0].Acceleration*MotorConfig[0].PIDRegulationDelay)/(float)1000;
  						}
  					}
  					else if (gRampTargetSpeed > maxTargetSpeed)
  					{
  						// slow down to maxTargetSpeed
  						if (maxTargetSpeed == 0)
  						{
  							// allow faster ramp down to zero to prevent overshooting at target position
  							gRampTargetSpeed -= (float)(MotorConfig[0].Acceleration*MotorConfig[0].PIDRegulationDelay)/(float)(1000);
  						} else {
  							gRampTargetSpeed -= (float)(MotorConfig[0].Acceleration*MotorConfig[0].PIDRegulationDelay)/(float)1000;
  						}
  					} else {
  						// do nothing
  					}
  				}
  				gTargetSpeed = gRampTargetSpeed;
  			}

  			// ramp generator for velocity control
  			if (bldc_stm_isStatusFlagSet(VELOCITY_MODE) == TRUE)
  			{
  				if(MotorConfig[0].Acceleration==0)
  				{
  					gTargetSpeed = gDesiredMotorSpeed;
  				}
  				else if(gTargetSpeed<(gDesiredMotorSpeed))		// accelerate motor
  				{
  					gTargetSpeed += (float)(MotorConfig[0].Acceleration*MotorConfig[0].PIDRegulationDelay)/(float)1000;
  					gTargetSpeed = MIN(gTargetSpeed, MotorConfig[0].MaxPositioningSpeed); // limit target speed to max allowed motor speed
  				}
  				else if(gTargetSpeed>(gDesiredMotorSpeed))  	// decelerate motor
  				{
  					gTargetSpeed -= (float)(MotorConfig[0].Acceleration*MotorConfig[0].PIDRegulationDelay)/(float)1000;
  					gTargetSpeed = MAX(gTargetSpeed, -MotorConfig[0].MaxPositioningSpeed);	// limit target speed to max allowed motor speed
  				}
  			}
  		} else {
  			// position and velocity control without velocity ramp
  			gTargetSpeed = gDesiredMotorSpeed;
  		}

  		// velocity regulation
  		if (((bldc_stm_isStatusFlagSet(MODULE_INITIALIZED) == TRUE) ||
  			((MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALLFX) && (HallFXState == HALLFX_STATE_RUN))) &&	// if module is initialized or in initialization mode
  			((bldc_stm_isStatusFlagSet(VELOCITY_MODE) == TRUE) ||
  			(bldc_stm_isStatusFlagSet(POSITION_MODE) == TRUE)) &&
  			(MotorConfig[0].CommutationMode != COMM_MODE_BLOCK_CONTROLLED) )
  		{
  			// compute target current using the velocity pid regulator
  			gTargetMotorCurrent = bldc_regulator_getTargetCurrentFromVelocityPIDRegulator(&MotorConfig[0], &VelocityPID, gTargetSpeed, gActualMotorSpeed);

			// check for wrong motor direction measured in hallFX mode
  			if (MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALLFX)
  			{
  				if (((gTargetSpeed > 0) && (gHallFXDirection == LEFT_MOTOR_DIRECTION)) ||
  					((gTargetSpeed < 0) && (gHallFXDirection == RIGHT_MOTOR_DIRECTION)))
  				{
					// motor turns in wrong direction!
  					gWrongFxDirectionCounter++;
  				}
  			}
  		}

  		// velocity regulation for controlled block commutation
  		if (((bldc_stm_isStatusFlagSet(TORQUE_MODE) == TRUE) ||
 			(HallFXState == HALLFX_STATE_RAMP_BLOCK)) &&
  			(MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_CONTROLLED))
  		{
  			// linear ramp drive
  	        if (InitStartCurrentFlag != READY)
  	        {
  	        	// do not accelerate until start current is not reached
  	        	NewRpmValue = 1000;
  	        	NewSpeedScaled = U16_MAX;
  	        } else if (InitStartCurrentFlag == READY) {
  	        	if (gDesiredMotorSpeed == 0)
  	        	{
  	        		NewRpmValue = 1000;
  	        		NewSpeedScaled = U16_MAX;
  	        	} else {
  	        		gActualMotorDirection = (gDesiredMotorSpeed > 0) ? RIGHT_MOTOR_DIRECTION : LEFT_MOTOR_DIRECTION;
  	        	}

  	        	if(gActualMotorSpeed < gDesiredMotorSpeed)
  	        	{
  	        		NewRpmValue += MotorConfig[0].Acceleration*MotorConfig[0].PIDRegulationDelay;
  	        		NewSpeedScaled = (((((((HALL_TIM_CLK*2)/HALL_MAX_RATIO)*60)/6)*100)/(MotorConfig[0].MotorPoles/2))/NewRpmValue)*10;
  	        		if(NewSpeedScaled > U16_MAX)
  	        			NewSpeedScaled = U16_MAX;
  	        	}
  	        	else if(gActualMotorSpeed > gDesiredMotorSpeed)
  	        	{
  	        		NewRpmValue -= MotorConfig[0].Acceleration*MotorConfig[0].PIDRegulationDelay;
  	        		NewSpeedScaled = (((((((HALL_TIM_CLK*2)/HALL_MAX_RATIO)*60)/6)*100)/(MotorConfig[0].MotorPoles/2))/NewRpmValue)*10;
  	        		if(NewSpeedScaled < -U16_MAX)
  	        			NewSpeedScaled = -U16_MAX;
  	        	}

  	        	// let the torque regulator set the motor direction
  	        	if (gActualMotorSpeed > 0)
  	        		gTargetMotorCurrent = abs(gTargetMotorCurrent);
  	        	else if (gActualMotorSpeed < 0)
  	        		gTargetMotorCurrent = -abs(gTargetMotorCurrent);

  	        	gRampTargetSpeed = gActualMotorSpeed;
  	        	gTargetSpeed = gActualMotorSpeed;
  	        }
  		}
	}

	// current regulation timer
  	if(currentRegulationTickTimer >= MotorConfig[0].CurrentRegulationDelay)
  	{
  		currentRegulationTickTimer = 0;
  		currentLoopCounter++;

  		// PWM regulation mode
  		if ((bldc_stm_isStatusFlagSet(MODULE_INITIALIZED) == TRUE) &&
  			(bldc_stm_isStatusFlagSet(PWM_MODE) == TRUE))
  		{
  			gPWMDutyCycle = abs(gTargetPWM);
  			if (gTargetPWM > 0)
  				gActualMotorDirection = RIGHT_MOTOR_DIRECTION;
  			else if (gTargetPWM < 0)
  				gActualMotorDirection = LEFT_MOTOR_DIRECTION;
  			//else
  				// do not change the direction
  		}

  		// torque regulation mode (current regulation)
		if ((bldc_stm_isStatusFlagSet(MODULE_INITIALIZED) == TRUE) &&  // wenn modul schon initialisiert ist
			((bldc_stm_isStatusFlagSet(POSITION_MODE) == TRUE) ||		// und einer der drei Moden aktiv ist
			(bldc_stm_isStatusFlagSet(VELOCITY_MODE) == TRUE) ||
			(bldc_stm_isStatusFlagSet(TORQUE_MODE) == TRUE)))
  	  	{
  	  		switch(MotorConfig[0].CommutationMode)
  	  		{
  				case COMM_MODE_BLOCK_HALL:
  				case COMM_MODE_BLOCK_CONTROLLED:
  				case COMM_MODE_BLOCK_HALLFX:

  					// get PWM from current regulator
  					gPWMDutyCycle = bldc_regulator_getPWMFromCurrentPIDRegulator(&MotorConfig[0], &CurrentPID, gTargetMotorCurrent, gActualMotorCurrent, gActualMotorSpeed/*, gActualMotorDirection*/);

  					// pwm limitation for hallFX mode
  		  			if ((MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALLFX) ||
  		  				(MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_CONTROLLED))
  		  			{
  		  				// do not allow a direction change in hallFX mode!!!
  		  				if (gDesiredMotorSpeed > 0)
  		  				{
  		  					gPWMDutyCycle = functions_limitIntBetweenMinAndMax(gPWMDutyCycle, 0, MotorConfig[0].PWMLimit);
  		  				}
  		  				else if (gDesiredMotorSpeed < 0)
  		  				{
  		  					gPWMDutyCycle = functions_limitIntBetweenMinAndMax(gPWMDutyCycle, -MotorConfig[0].PWMLimit, 0);
  		  				} else {
  		  					// motor turns in wrong direction!
  		  				}
  		  			}

  					// update motor direction
  					if (gPWMDutyCycle > 0)
  						gActualMotorDirection = RIGHT_MOTOR_DIRECTION;
  					else if (gPWMDutyCycle < 0)
  						gActualMotorDirection = LEFT_MOTOR_DIRECTION;
  					//else
  						// do not change the motor direction
  					break;
  			}
  	  	}

  		adc_checkTMC603Amplifier(gMeasuredMotorCurrent);

  	  	// set overcurrent flag and led if the actual current is higher then the max. allowed motor current
  		if (abs(gActualMotorCurrent) > (int)(MotorConfig[0].MaximumCurrent))
  		{
  			bldc_stm_setStatusFlag(OVERCURRENT);
  			LED_OVC_ON();
  		} else {
 			bldc_stm_clearStatusFlag(OVERCURRENT);
  			LED_OVC_OFF();
  		}
  	}

  	// set the new PWM value
  	switch(MotorConfig[0].CommutationMode)
  	{
  		case COMM_MODE_BLOCK_HALL:
  			gActualPWMDutyCycle = functions_limitIntBetweenMinAndMax(abs(gPWMDutyCycle), 0, MotorConfig[0].PWMLimit);

  			// set new PWM values
  			TIM_SetCompare1(TIM1, gActualPWMDutyCycle);
  			TIM_SetCompare2(TIM1, gActualPWMDutyCycle);
  			TIM_SetCompare3(TIM1, gActualPWMDutyCycle);
  			break;
  		case COMM_MODE_BLOCK_HALLFX:
  			// limit the PWM to 90% of the allowed PWM
  			gActualPWMDutyCycle = functions_limitIntBetweenMinAndMax(abs(gPWMDutyCycle), 0, (MotorConfig[0].PWMLimit*9)/10);

  			// set new PWM values
  			TIM_SetCompare1(TIM1, gActualPWMDutyCycle);
  			TIM_SetCompare2(TIM1, gActualPWMDutyCycle);
  			TIM_SetCompare3(TIM1, gActualPWMDutyCycle);
  			break;
  		case COMM_MODE_BLOCK_CONTROLLED:
  			gActualPWMDutyCycle = functions_limitIntBetweenMinAndMax(abs(gPWMDutyCycle), 0, MotorConfig[0].PWMLimit);

  			// set new PWM value
  			TIM_SetCompare1(TIM1, gActualPWMDutyCycle);
  			TIM_SetCompare2(TIM1, gActualPWMDutyCycle);
  			TIM_SetCompare3(TIM1, gActualPWMDutyCycle);

  			// set frequency for auto reload
#if HALLFX_IRQ_HANDLER==TIM2_IRQ_HANDLER
  			TIM_SetAutoreload(TIM2, abs(NewSpeedScaled));
#elif HALLFX_IRQ_HANDLER==TIM4_IRQ_HANDLER
  			TIM_SetAutoreload(TIM4, abs(NewSpeedScaled));
#endif
  			break;
  	}

  	// �berwachung der Endschalter
#if DEVICE==TMCM603EVAL_V2_3 || DEVICE==TMC603EVAL
  	if(MotorConfig[0].StopSwitchEnable & BIT0)  // left stop switch active
  	{
  		if(gActualMotorSpeed < 0)
  		{
  			if(((MotorConfig[0].StopSwitchPolarity & BIT0) && io_getPin(0)) ||   //Polarit�t konfigurierbar
  				(!(MotorConfig[0].StopSwitchPolarity & BIT0) && !io_getPin(0)))
  			{
  				gTargetSpeed = 0;
  				gDesiredMotorSpeed = 0;
  			}
  		}
  	}

  	if(MotorConfig[0].StopSwitchEnable & BIT1)  // right stop switch active
  	{
  		if(gActualMotorSpeed > 0)
  		{
  			if(((MotorConfig[0].StopSwitchPolarity & BIT1) && io_getPin(1)) ||   //Polarit�t konfigurierbar
  				(!(MotorConfig[0].StopSwitchPolarity & BIT1) && !io_getPin(1)))
  			{
  				gTargetSpeed = 0;
  				gDesiredMotorSpeed = 0;
  			}
  		}
  	}
#endif
}

void bldc_stm_switchToRegulationMode(int mode)
{
	switch (mode)
	{
		case POSITION_MODE:
			bldc_stm_setStatusFlag(POSITION_MODE);
			bldc_stm_clearStatusFlag(VELOCITY_MODE);
			bldc_stm_clearStatusFlag(TORQUE_MODE);
			bldc_stm_clearStatusFlag(PWM_MODE);
			bldc_stm_clearStatusFlag(POSITION_END);
			break;
		case VELOCITY_MODE:
			bldc_stm_setStatusFlag(VELOCITY_MODE);
			bldc_stm_clearStatusFlag(POSITION_MODE);
			bldc_stm_clearStatusFlag(TORQUE_MODE);
			bldc_stm_clearStatusFlag(PWM_MODE);
			bldc_stm_clearStatusFlag(POSITION_END);
			break;
		case TORQUE_MODE:
			bldc_stm_setStatusFlag(TORQUE_MODE);
			bldc_stm_clearStatusFlag(POSITION_MODE);
			bldc_stm_clearStatusFlag(VELOCITY_MODE);
			bldc_stm_clearStatusFlag(PWM_MODE);
			bldc_stm_clearStatusFlag(POSITION_END);
			break;
		case PWM_MODE:
			bldc_stm_setStatusFlag(PWM_MODE);
			bldc_stm_clearStatusFlag(VELOCITY_MODE);
			bldc_stm_clearStatusFlag(TORQUE_MODE);
			bldc_stm_clearStatusFlag(POSITION_MODE);
			bldc_stm_clearStatusFlag(POSITION_END);
			break;
	}
	gActualSetRegulationMode = mode;
}

/* set target velocity [rpm] (x{>0:CW | 0:Stop | <0: CCW} */
void bldc_stm_setTargetVelocity(int newMotorSpeed)
{
	gDesiredMotorSpeed = newMotorSpeed;

	int lastSetRegulationMode = gActualSetRegulationMode;
	bldc_stm_switchToRegulationMode(VELOCITY_MODE);

	// update/overwrite gTargetSpeed if regulation mode just switched from pwm or torque mode
	// (prevents a jump in the velocity ramp during switching)
	if ((lastSetRegulationMode == PWM_MODE) || (lastSetRegulationMode == TORQUE_MODE))
		gTargetSpeed = gActualMotorSpeed;

	if(!READ_DRIVER_STATE() && !bldc_stm_getErrorFlags())
		ENABLE_DRIVER();

	// if EMERGENCY_STOP or FREE_RUNNING is active,
	// target speed must be set to zero
	switch (MotorConfig[0].HardStopFlag)
	{
		case STOP_FLAG_FREE_RUNNING:
			DISABLE_DRIVER();
			gDesiredMotorSpeed = 0;
			break;
		case STOP_FLAG_EMERGENCY_STOP:
			gDesiredMotorSpeed = 0;
			break;
	}

	switch(MotorConfig[0].CommutationMode)
	{
		case COMM_MODE_BLOCK_HALLFX:
			if (HallFXFlag == FALSE)
				HallFXFlag = TRUE;
			break;
	}
}

/* move to absolute position */
void bldc_stm_moveToAbsolutePosition(int position)
{
	gTargetMotorPosition = position;

	int lastSetRegulationMode = gActualSetRegulationMode;
	bldc_stm_switchToRegulationMode(POSITION_MODE);
	bldc_stm_clearStatusFlag(POSITION_END);

	// update/overwrite gRampTargetSpeed if regulation mode just switched from velocity to position mode
	// (prevents a jump in the velocity ramp during switching)
	if (lastSetRegulationMode == VELOCITY_MODE)
		gRampTargetSpeed = gTargetSpeed;

	// update/overwrite gTargetSpeed if regulation mode just switched from pwm or torque mode to position mode
	// (prevents a jump in the velocity ramp during switching)
	if ((lastSetRegulationMode == PWM_MODE) || (lastSetRegulationMode == TORQUE_MODE))
		gRampTargetSpeed = gActualMotorSpeed;
}

/* move to relative Position */
void bldc_stm_moveToRelativePosition(int dPosition)
{
	bldc_stm_moveToAbsolutePosition(gActualMotorPosition + dPosition);
}

void bldc_stm_setTargetMotorCurrent(int current)
{
	gTargetMotorCurrent = current;
	bldc_stm_switchToRegulationMode(TORQUE_MODE);

	// set velocity ramps to zero
	gTargetSpeed = 0;
}

int bldc_stm_getTargetMotorCurrent()
{
	return gTargetMotorCurrent;
}

int bldc_stm_getTargetMotorPosition()
{
	return gTargetMotorPosition;
}

void bldc_stm_setTargetPWM(int pwm)
{
	gTargetPWM = pwm;
	bldc_stm_switchToRegulationMode(PWM_MODE);
	gTargetSpeed = 0; // set velocity ramps to zero
}

int bldc_stm_getTargetPWM()
{
	return gTargetPWM;
}

int bldc_stm_getRampGenSpeed()
{
	return (int)gTargetSpeed;
}

void bldc_stm_setActualMotorPosition(int position)
{
	// clear position end flag
	bldc_stm_clearStatusFlag(POSITION_END);

	gActualMotorPosition = position;
	// this is important for position regulation,
	// otherwise the position is adjusted accordingly the old target position
	gTargetMotorPosition = position;

	// also update the velocity and reset the intern used position counter
	// (otherwise the velocity regulator recognizes the "high position difference" as high actual speed)
	bldc_stm_updateActualSpeed(TRUE);
}

int bldc_stm_getActualMotorPosition()
{
	return gActualMotorPosition;
}

int bldc_stm_getTargetVelocity()
{
	return gDesiredMotorSpeed;
}

void bldc_stm_updateActualSpeed(UCHAR resetCounter)
{
	static int lastHallEncoderPosition;
	int newHallEncoderPosition, encoderDiff;
	static int lastSystick;
	int newSystick, systickDiff;

	switch (MotorConfig[0].CommutationMode)
	{
		case COMM_MODE_BLOCK_HALL:
		case COMM_MODE_BLOCK_HALLFX:
			// compute systick difference
			newSystick = systick_stm_getTimer();
			if (newSystick >= lastSystick)
				systickDiff = newSystick - lastSystick;
			else // handle timer overrun
				systickDiff = (0xffffffff-lastSystick) + newSystick;

			// compute hall encoder difference
			newHallEncoderPosition = gActualMotorPosition;

			// reset needed while switching between hall and encoder mode
			if (resetCounter == TRUE)
				lastHallEncoderPosition = newHallEncoderPosition;

			if (gActualMotorDirection == 0)
			{
				if (newHallEncoderPosition >= lastHallEncoderPosition)
					encoderDiff = newHallEncoderPosition-lastHallEncoderPosition;
				else // handle int overrun
					encoderDiff = (0xffffffff-lastHallEncoderPosition) + newHallEncoderPosition;
			} else {
				if (lastHallEncoderPosition >= newHallEncoderPosition)
					encoderDiff = lastHallEncoderPosition-newHallEncoderPosition;
				else // handle int overrun
					encoderDiff = (0xffffffff-newHallEncoderPosition) + lastHallEncoderPosition;
			}

			encoderDiff *= (gActualMotorDirection == 0) ? 1 : -1;
			encoderDiff *= 1000; // 72.000.000 cpu-ticks / (2*36.000) = 1000 ==> 1/1000 seconds per systick

			// compute actual motor speed
			// speed [rpm] = (60*encoderDiff)/(6*(Motorpoles/2))   *   (1000/timeDiff)
			gActualMotorSpeed = functions_getAverageInt(gActualMotorSpeed, (encoderDiff*10)/((MotorConfig[0].MotorPoles/2) * systickDiff), 64); // 8

			lastSystick = newSystick;
			lastHallEncoderPosition = newHallEncoderPosition;
			break;
		case COMM_MODE_BLOCK_CONTROLLED:
			gActualMotorSpeed=60*(72000000/HALL_MAX_RATIO)/NewSpeedScaled/6/(MotorConfig[0].MotorPoles/2);
		    //(274/(MotorConfig[0].MotorPoles/2)) ist die kleinstm�gliche Drehzahl,
		    //die berechnet werden kann. Alles was kleiner oder gleich ist, wird als Null angenommen.
		    if((abs(gActualMotorSpeed)*(MotorConfig[0].MotorPoles/2)) <= 274)
		    	gActualMotorSpeed=0;
		    break;
	}
}

/* actual motor speed in rpm */
int bldc_stm_getActualSpeed()
{
	return gActualMotorSpeed;
}

/* actual motor current in mA */
int bldc_stm_getActualMotorCurrent(void)
{
	return gActualMotorCurrent;
}

/* actual set PWM */
int bldc_stm_getActualPWMDutyCycle()
{
	if (gActualMotorDirection == RIGHT_MOTOR_DIRECTION)
		return abs(gActualPWMDutyCycle);
	else
		return -abs(gActualPWMDutyCycle);
}

/* set status flags */
void bldc_stm_setStatusFlag(UINT flag)
{
	gStatusFlags |= flag;
}

/* clear status flag */
void bldc_stm_clearStatusFlag(UINT flag)
{
	gStatusFlags &= ~flag;
}

/* check if status flag is set */
UCHAR bldc_stm_isStatusFlagSet(UINT flag)
{
	if(gStatusFlags & flag)
		return TRUE;
	else
		return FALSE;
}

void bldc_stm_setEncoderFlag(UCHAR flag)
{
	MotorConfig[0].EncoderFlags |= flag;
}

void bldc_stm_clearEncoderFlag(UCHAR flag)
{
	MotorConfig[0].EncoderFlags &= ~flag;
}

UCHAR bldc_stm_isEncoderFlagSet(UCHAR flag)
{
	if(MotorConfig[0].EncoderFlags & flag)
		return TRUE;
	else
		return FALSE;
}

void bldc_stm_setPositioningFlag(UCHAR flag)
{
	MotorConfig[0].PositioningFlags |= flag;
}

void bldc_stm_clearPositioningFlag(UCHAR flag)
{
	MotorConfig[0].PositioningFlags &= ~flag;
}

UCHAR bldc_stm_isPositioningFlagSet(UCHAR flag)
{
	if(MotorConfig[0].PositioningFlags & flag)
		return TRUE;
	else
		return FALSE;
}

/* reset error flags */
void bldc_stm_resetErrorFlags()
{
	bldc_stm_clearStatusFlag(OVERCURRENT|UNDERVOLTAGE|OVERVOLTAGE|OVERTEMPERATURE|HALLERROR);
}

/* get status flags and afterwards reset error flags */
UINT bldc_stm_getAllStatusFlags()
{
	UINT flags = gStatusFlags;
	// reset error flags
	bldc_stm_resetErrorFlags();
	return flags;
}

/* get and afterwards reset error flags */
UINT bldc_stm_getErrorFlags()
{
	UINT flags = gStatusFlags;
	UINT mask = OVERCURRENT|UNDERVOLTAGE|OVERVOLTAGE|OVERTEMPERATURE|HALLERROR;

	// return only error flags
	flags &= mask;
	// reset error flags
	bldc_stm_resetErrorFlags();
    return flags;
}

/* returns the error of the position PID */
int bldc_stm_getPositionPIDError()
{
	return PositionPID.error;
}

/* returns the error sum of the position PID*/
int bldc_stm_getPositionPIDErrorSum()
{
	return PositionPID.errorSum;
}

/* returns the error of the velocity PID */
int bldc_stm_getVelocityPIDError()
{
  return VelocityPID.error;
}

/*  returns the error sum of the velocity PID */
int bldc_stm_getVelocityPIDErrorSum()
{
	return VelocityPID.errorSum;
}

/* returns the error of the current PID */
int bldc_stm_getCurrentPIDError()
{
  return CurrentPID.error;
}

/*  returns the error sum of the current PID */
int bldc_stm_getCurrentPIDErrorSum()
{
	return CurrentPID.errorSum;
}

/* commutation interrupt, take over the new desired pwm */
void TIM1_TRG_COM_IRQHandler()
{
	// clear interrupt flag
	TIM_ClearITPendingBit(TIM1, TIM_IT_COM);
}

/*******************************************************************
   Funktion: TIM1_UP_IRQHandler
   Zweck: Interrupt Handler f�r den Kommutierungsinterrupt von TIM1.
********************************************************************/
void TIM1_UP_IRQHandler()
{
	// reset interrupt flag
	TIM_ClearITPendingBit(TIM1, TIM_IT_Update);

	currentRegulationTickTimer++;

	if((MotorConfig[0].CommutationMode==COMM_MODE_BLOCK_HALL) ||
	   (MotorConfig[0].CommutationMode==COMM_MODE_BLOCK_HALLFX) ||
	   (MotorConfig[0].CommutationMode==COMM_MODE_BLOCK_CONTROLLED))
	{
		//Motorstrom von bisher LOW geschalteter Spule �bernehmen
		if(pwm_getActualUsedPhase() != ADC_INVALID_VALUE)
		{
			if(!adc_isTMC603GainChanged())
			{
				// start current measurement for block mode
				ADC_SoftwareStartConvCmd(ADC1, ENABLE);

				gMeasuredMotorCurrent = adc_getTMC603MeasuredBlockMotorCurrent(pwm_getActualUsedPhase());
				int newMotorCurrent = adc_calcTMC603MotorCurrent(gMeasuredMotorCurrent, MotorConfig[0].RdsOn);
				if (gActualMotorDirection == LEFT_MOTOR_DIRECTION)
						newMotorCurrent = -newMotorCurrent;
				gActualMotorCurrent = functions_getAverageInt(gActualMotorCurrent, newMotorCurrent, 128/*32*/);

				//TOGGLE_LED1();
			}else{
				// Delay nach Messbereichsumschaltung bei Blockkommutierung:
				// Erst nach dieser Zeit ist wieder ein g�ltiger Strommesswert verf�gbar.
				static UINT gainChangeTimeTick;
				gainChangeTimeTick++;
				if(gainChangeTimeTick >= 1000)
				{
					gainChangeTimeTick = 0;
					adc_clearTMC603GainChanged();
				}
			}
		}
	}else{
		//Delay nach Messbereichsumschaltung
		if (adc_isTMC603GainChanged())
			adc_clearTMC603GainChanged();

		// start current measurement for sine mode
		ADC_SoftwareStartConvCmd(ADC1, ENABLE);
	}
}

int bldc_stm_getHallDiff(UCHAR previousHallState, UCHAR actualHallState)
{
	switch(previousHallState)
    {
		case 3:
			if(actualHallState==1)
				return 1;
			else if(actualHallState==2)
				return -1;
			break;
		case 1:
			if(actualHallState==5)
				return 1;
			else if(actualHallState==3)
				return -1;
			break;
		case 5:
			if(actualHallState==4)
				return 1;
    		else if(actualHallState==1)
    			return -1;
			break;
		case 4:
			if(actualHallState==6)
				return 1;
    		else if(actualHallState==5)
    			return -1;
			break;
		case 6:
			if(actualHallState==2)
				return 1;
    		else if(actualHallState==4)
    			return -1;
			break;
		case 2:
			if(actualHallState==3)
				return 1;
      	  else if(actualHallState==6)
      		  return -1;
			break;
    }
	return 0;
}

void bldc_stm_checkHallEventValidity(int hallPattSeqDiff)
{
	if ((hallPattSeqDiff == 1) || (hallPattSeqDiff == -5))
	{
		bldc_stm_clearStatusFlag(HALLERROR);
	} else if((hallPattSeqDiff == -1) || (hallPattSeqDiff == 5)) {
		bldc_stm_clearStatusFlag(HALLERROR);
	} else if(hallPattSeqDiff == 0) {
		// do nothing
	} else{
		bldc_stm_setStatusFlag(HALLERROR);
	}
}

/* read hall/hallFX state */
void bldc_stm_updateHallHallFXState()
{
	// read hall/hallFX state
	gPreviousHallState = gHallState;

	switch(MotorConfig[0].CommutationMode)
	{
		case COMM_MODE_BLOCK_HALL:
#if HALL_IRQ_HANDLER != NOT_USED
			gHallState = READ_HALL_STATE();
			if(MotorConfig[0].HallInvertFlag)
				gHallState^=0x07;
#endif
			break;
		case COMM_MODE_BLOCK_HALLFX:
#if HALLFX_IRQ_HANDLER != NOT_USED
			gHallState = READ_HALLFX_STATE();
#endif
			break;
	}
}

UCHAR bldc_stm_handleHallHallFXSensorChange()
{
	char HallPattSeqNew;
	int HallPattSeqDiff;
	UCHAR fxValid = FALSE;

	// check hall state on valid hall event
	switch(MotorConfig[0].CommutationMode)
	{
		case COMM_MODE_BLOCK_HALL:
			HallPattSeqNew = (char)HallPattSeq[gHallState];
			HallPattSeqDiff = HallPattSeqNew-HallPattSeqOld;
			HallPattSeqOld = (char)HallPattSeq[gHallState];

			bldc_stm_checkHallEventValidity(HallPattSeqDiff);
			fxValid = TRUE;
			break;

		case COMM_MODE_BLOCK_HALLFX:
			HallPattSeqNew = (char)HallFXPattSeq[gHallState];
			HallPattSeqDiff = HallPattSeqNew-HallPattSeqOld;

			int fxDiff = bldc_stm_getHallDiff(gPreviousHallState, gHallState);
			static int lastFxDiff = 0;

			fxValid = TRUE;

			if (fxDiff > 0)
			{
				gHallFXDirection = RIGHT_MOTOR_DIRECTION;

				// trigger fxDirection edges: left -> right
				static u32 lastLREdgeTick = 0;
				static u32 lastLRSysTick = 0;
				if (lastFxDiff < 0)
				{
					u32 actualTick = SysTick_GetCounter();
					u32 actualSysTick = systick_stm_getTimer();

					u32 tickDiff = (actualSysTick-lastLRSysTick) * 36000 + actualTick - lastLREdgeTick;

					// measure the time between two direction edges
					if (tickDiff < 7000000)
					{
						fxValid = FALSE;
					}
					lastLREdgeTick = actualTick;
					lastLRSysTick = actualSysTick;
				}
			} else if (fxDiff < 0) {
				gHallFXDirection = LEFT_MOTOR_DIRECTION;

				// trigger fxDirection edges: right -> left
				static u32 lastRLEdgeTick = 0;
				static u32 lastRLSysTick = 0;
				if (lastFxDiff > 0)
				{
					u32 actualTick = SysTick_GetCounter();
					u32 actualSysTick = systick_stm_getTimer();

					u32 tickDiff = (actualSysTick-lastRLSysTick) * 36000 + actualTick - lastRLEdgeTick;

					// measure the time between two direction edges
					if (tickDiff < 7000000)
					{
						fxValid = FALSE;
					}
					lastRLEdgeTick = actualTick;
					lastRLSysTick = actualSysTick;
				}
			} else {
				// do nothing
			}
			lastFxDiff = fxDiff;

			if (fxValid == TRUE)
				HallPattSeqOld = (char)HallFXPattSeq[gHallState];

			// update hall/hallFx status flag
			if (fxValid == TRUE)
				bldc_stm_clearStatusFlag(HALLERROR);
			else
				bldc_stm_setStatusFlag(HALLERROR);
			break;
	}
	return fxValid;
}

void bldc_stm_setHallHallFXCommutationStep()
{
	// set and trigger next commutation step (7�s runtime)
	if ((MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALL) || (MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALLFX))
	{
		pwm_scheme_block(MotorConfig[0].BlockPwmScheme, MotorConfig[0].HardStopFlag, gActualPWMDutyCycle, gActualMotorDirection, gHallState, motorHaltedFlag);
		TIM_GenerateEvent(TIM1, TIM_EventSource_COM);
	}
}

void bldc_stm_setControlledBlockCommutationStep()
{
	UCHAR Hall;
	char HallPattSeqNew;
	int HallPattSeqDiff;

	if (HallFXFlag == TRUE)
	{
		Hall = READ_HALLFX_STATE();
		HallPattSeqNew = (char)HallFXPattSeq[Hall];
		HallPattSeqDiff = HallPattSeqNew-HallPattSeqOld;

		bldc_stm_checkHallEventValidity(HallPattSeqDiff);

		if(!bldc_stm_isStatusFlagSet(HALLERROR))
			HallPattSeqOld = (char)HallFXPattSeq[gHallState];
	}
	if(InitStartCurrentFlag == READY)
	{
		motorHaltedFlag = FALSE;
		gPreviousHallState = gHallState;
	}else{
		motorHaltedFlag = TRUE;
		gPreviousHallState = 1;
	}

	// determine next commutation step
	switch(gActualMotorDirection)
	{
		case FALSE:
			if(MotorConfig[0].HallInvertFlag)
				gHallState = (HallPattRev[gPreviousHallState]&0x07);
			else
				gHallState = (HallPattFor[gPreviousHallState]&0x07);
			break;
		case TRUE:
			if(MotorConfig[0].HallInvertFlag)
				gHallState = (HallPattFor[gPreviousHallState]&0x07);
			else
				gHallState = (HallPattRev[gPreviousHallState]&0x07);
			break;
	}

	// set and trigger next commutation step
	pwm_scheme_block(MotorConfig[0].BlockPwmScheme, MotorConfig[0].HardStopFlag, gActualPWMDutyCycle, gActualMotorDirection, gHallState, motorHaltedFlag);
	TIM_GenerateEvent(TIM1, TIM_EventSource_COM);
}

void bldc_stm_setBlockCommutationStep()
{
	//Wenn Motor steht, dann ist die Kommutierungsfrequenz
	//sowie die Motordrehzahl gleich Null.
	motorHaltedFlag = TRUE;

	// read hall state
	gHallState = READ_HALL_STATE();
	if(MotorConfig[0].HallInvertFlag)
		gHallState ^= 0x07;

	// set and trigger next commutation step
	pwm_scheme_block(MotorConfig[0].BlockPwmScheme, MotorConfig[0].HardStopFlag, gActualPWMDutyCycle, gActualMotorDirection, gHallState, motorHaltedFlag);
	TIM_GenerateEvent(TIM1, TIM_EventSource_COM);
}

/* Interrupt handler for timer 2 (hall/hallFX) */
void TIM2_IRQHandler(void)
{
	// capture Event 1 => hall sensor change
	if (TIM_GetFlagStatus(TIM2, TIM_FLAG_CC1) == SET)
	{
		// clear interrupt flag
		TIM_ClearFlag(TIM2, TIM_FLAG_CC1);

		bldc_stm_updateHallHallFXState();

		// update motor position counter on basis of hall/hallfx sensors
		if (bldc_stm_handleHallHallFXSensorChange() == TRUE)
			gActualMotorPosition += bldc_stm_getHallDiff(gPreviousHallState, gHallState);

		bldc_stm_setHallHallFXCommutationStep();
	}

	// update event => counter overrun
	// used for controlled block commutation
	if(TIM_GetFlagStatus(TIM2, TIM_FLAG_Update) == SET)
	{
		TIM_ClearFlag(TIM2, TIM_FLAG_Update);

		// do block commutation
		if (MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_CONTROLLED)
			bldc_stm_setControlledBlockCommutationStep();

		if ((MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALL) || (MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALLFX))
			bldc_stm_setBlockCommutationStep();
	}
}

/* Interrupt handler for timer 3 */
void TIM3_IRQHandler(void){}

/* Interrupt handler for timer 4 (hall/hallFX)*/
void TIM4_IRQHandler(void)
{
	// capture Event 1 => hall sensor change
	if (TIM_GetFlagStatus(TIM4, TIM_FLAG_CC1) == SET)
	{
		// clear interrupt flag
		TIM_ClearFlag(TIM4, TIM_FLAG_CC1);

		bldc_stm_updateHallHallFXState();

		// update motor position counter on basis of hall/hallfx sensors
		if (bldc_stm_handleHallHallFXSensorChange() == TRUE)
			gActualMotorPosition += bldc_stm_getHallDiff(gPreviousHallState, gHallState);

		bldc_stm_setHallHallFXCommutationStep();
	}

	// update event => counter overrun
	// used for controlled block commutation
	if(TIM_GetFlagStatus(TIM4, TIM_FLAG_Update) == SET)
	{
		TIM_ClearFlag(TIM4, TIM_FLAG_Update);

		// do block commutation
		if (MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_CONTROLLED)
			bldc_stm_setControlledBlockCommutationStep();

		if ((MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALL) || (MotorConfig[0].CommutationMode == COMM_MODE_BLOCK_HALLFX))
			bldc_stm_setBlockCommutationStep();
	}
}
