/*
 * Functions.h
 *
 *  Created on: 25.03.2011
 *      Author: ed (based on work of OK)
 */

#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

	#include "stm32f10x_lib.h"
	#include "Definitions.h"

	int functions_sqrti(int x);
	int functions_limitIntBetweenMinAndMax(int value, int min, int max);
	float functions_limitFloatBetweenMinAndMax(float value, int min, int max);
	int functions_getAverageInt(int average, int newValue, u32 num);

#endif /* FUNCTIONS_H_ */
