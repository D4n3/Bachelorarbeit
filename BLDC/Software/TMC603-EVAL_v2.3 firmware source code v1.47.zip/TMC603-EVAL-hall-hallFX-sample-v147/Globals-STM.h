/****************************************************
  Projekt: TMCM-STM

  Modul:   Globals-STM.h
           Globale Variablen

  Datum:   26.5.2009 OK
*****************************************************/

#ifndef GLOBALS_STM_H_
#define GLOBALS_STM_H_

	#include "TMCM-STM.h"

	extern TModuleConfig ModuleConfig;
	extern TMotorConfig MotorConfig[N_O_MOTORS];
	extern UCHAR ExtClockFlag;
	extern UCHAR ResetToFactoryDefaultRequested;
	extern UCHAR USBInterface;
	extern PIrqFunction CanRx0UsbLpIrqVector;
	extern UINT SerialHeartbeatTimer;
	extern UCHAR SerialHeartbeatFlag;

#endif
