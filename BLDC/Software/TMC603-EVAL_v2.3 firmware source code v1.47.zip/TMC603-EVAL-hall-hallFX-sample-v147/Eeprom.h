/****************************************************
  Projekt: TMCM-STM

  Modul:   Eeprom.h
           Zugriff auf das externe EEPROM (AT25128)

  Datum:   30.3.2007 OK (reworked by ed)
*****************************************************/

#ifndef EEPROM_H_
#define EEPROM_H_

	#include "TMCM-STM.h"
	#include "TMCL-STM.h"
	#include "Globals-STM.h"
	#include "SPI-STM.h"

	void eeprom_init();

	void eeprom_writeConfigByte(UINT address, UCHAR Value);
	UCHAR eeprom_readConfigByte(UINT address);

	void eeprom_writeConfigBlock(UINT address, UCHAR *block, UINT size);
	void eeprom_readConfigBlock(UINT address, UCHAR *block, UINT size);

#endif
