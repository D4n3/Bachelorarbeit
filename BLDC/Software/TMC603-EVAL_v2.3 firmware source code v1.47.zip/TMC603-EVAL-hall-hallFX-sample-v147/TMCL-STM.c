/****************************************************
  Projekt: TMCM-STM

  Modul:   TMCL-STM.c
           TMCL-Interpreter f�r BLDC-Module mit dem
           STM32-Prozessor.

  Datum:   26.5.2009 OK
*****************************************************/

#include <stdlib.h>

#include "TMCL-STM.h"
#include "Globals-STM.h"
#include "IO.h"
#include "Eeprom.h"
#include "ADC.h"
#include "BLDC-STM.h"
#include "SysTick.h"
#include "UART.h"
#include "USB-STM.h"
#include "UserFunctions.h"

//Variablen
static UCHAR TMCLMode;
static UCHAR TMCLCommandState;
TTMCLCommand ActualCommand;
TTMCLReply ActualReply;
UCHAR TMCLSuppressReply;
UCHAR SpecialReply[9];
#if defined(UART_INTERFACE)
static UCHAR UARTCmd[9];
static UCHAR UARTCount;
#endif
static UCHAR ResetRequested;
static UCHAR ASCIIMode;

//Importierte Variablen
extern const char *VersionString;

//Prototypen
static void RotateLeft(void);
static void RotateRight(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void StoreAxisParameter(void);
static void RestoreAxisParameter(void);
static void SetGlobalParameter(void);
static void GetGlobalParameter(void);
static void StoreGlobalParameter(void);
static void RestoreGlobalParameter(void);
static void SetOutput(void);
static void GetInput(void);
static void GetVersion(void);
static void SecurityCode(void);
static void FactoryDefault(void);
static void Boot(void);
static void SoftwareReset(void);

/*******************************************************************
   Funktion: ExecuteActualCommand()
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Ausf�hren des Befehls, der in der globalen Variablen
          ActualCommand steht.
********************************************************************/
static void ExecuteActualCommand(void)
{
	//Antworttelegramm vorbelegen
	ActualReply.Opcode = ActualCommand.Opcode;
	ActualReply.Status = REPLY_OK;
	ActualReply.Value.Int32 = ActualCommand.Value.Int32;

	//Befehl ausf�hren
	switch(ActualCommand.Opcode)
	{
    	case TMCL_ROR:
    		RotateRight();
    		break;
    	case TMCL_ROL:
    		RotateLeft();
    		break;
    	case TMCL_MST:
    		MotorStop();
    		break;
    	case TMCL_MVP:
    		MoveToPosition();
    		break;
    	case TMCL_SAP:
    		SetAxisParameter();
    		break;
    	case TMCL_GAP:
    		GetAxisParameter();
    		break;
    	case TMCL_STAP:
    		StoreAxisParameter();
    		break;
    	case TMCL_RSAP:
    		RestoreAxisParameter();
    		break;
    	case TMCL_SGP:
    		SetGlobalParameter();
    		break;
    	case TMCL_GGP:
    		GetGlobalParameter();
    		break;
    	case TMCL_STGP:
    		StoreGlobalParameter();
    		break;
    	case TMCL_RSGP:
    		RestoreGlobalParameter();
    		break;
    	case TMCL_SIO:
    		SetOutput();
    		break;
    	case TMCL_GIO:
    		GetInput();
    		break;
    	case TMCL_UF0:
    		userfunctions_F0();
    		break;
    	case TMCL_UF1:
    		userfunctions_F1();
    		break;
    	case TMCL_UF2:
    		userfunctions_F2();
    		break;
    	case TMCL_UF3:
    		userfunctions_F3();
    		break;
    	case TMCL_UF4:
    		userfunctions_F4();
    		break;
    	case TMCL_UF5:
    		userfunctions_F5();
    		break;
    	case TMCL_UF6:
    		userfunctions_F6();
    		break;
    	case TMCL_UF7:
    		userfunctions_F7();
    		break;
    	case TMCL_GetVersion:
    		GetVersion();
    		break;
    	case TMCL_FactoryDefault:
    		FactoryDefault();
    		break;
    	case TMCL_SecurityCode:
    		SecurityCode();
    		break;
    	case TMCL_Boot:
    		Boot();
    		break;
    	case TMCL_SoftwareReset:
    		SoftwareReset();
    		break;
    	default:
    		ActualReply.Status=REPLY_INVALID_CMD;
    		break;
	}
}

/*******************************************************************
   Funktion: tmcl_stm_init()
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Initialisierung der TMCL-Maschine
********************************************************************/
void tmcl_stm_init()
{
	// set all user variables to zero
	UINT i;
	for(i = 0; i < TMCL_RAM_USER_VARS; i++)
		TMCLUserVariable[i] = 0;

	// load the first 16 user variables always, if password protection is enabled
	for (i = 0; i <=15; i++)
		eeprom_readConfigBlock(ADDR_TMCL_USER_VARS+i*4, (UCHAR *) &TMCLUserVariable[i], 4);

	// load user variables from EEPROM if desired
	if(!ModuleConfig.ZeroUserVariables)
	{
		for(i = 0; i < TMCL_EEPROM_USER_VARS; i++)
			eeprom_readConfigBlock(ADDR_TMCL_USER_VARS+i*4, (UCHAR *) &TMCLUserVariable[i], 4);
	}

	// do auto start if desired
	if(ModuleConfig.TMCLAutostartFlag)
		TMCLMode = TM_RUN;
	else
		TMCLMode = TM_IDLE;
}

/*******************************************************************
   Funktion: tmcl_stm_processCommand()
   Parameter: ---

   R�ckgabewert: ---

   Zweck: Holen und Ausf�hren von TMCL-Befehlen
          Diese Funktion mu� periodisch aus der Hauptschleife
          heraus aufgerufen werden.
********************************************************************/
void tmcl_stm_processCommand()
{
#if defined(UART_INTERFACE)
	UCHAR Byte;
#endif
	UCHAR Checksum;
	UINT i;
#ifdef USB_INTERFACE
	UCHAR USBCmd[9];
	UCHAR USBReply[9];
#endif

  //**Antwort auf letzten Direktmodus-Befehl senden (wenn vorhanden)**

  //Antwort verwerfen wenn unterdr�ckt (aber nicht bei GAP/GGP/GIO/GCO)
  if(TMCLSuppressReply && ActualCommand.Opcode!=TMCL_GAP && ActualCommand.Opcode!=TMCL_GGP
     && ActualCommand.Opcode!=TMCL_GIO && ActualCommand.Opcode!=TMCL_GCO) TMCLCommandState=TCS_IDLE;

#if defined(UART_INTERFACE)
  if(TMCLCommandState==TCS_UART)  //Antwort �ber UART
  {
    if(!ASCIIMode)
    {
      if(TMCLReplyFormat==RF_STANDARD)
      {
        Checksum=ModuleConfig.SerialHostAddress+ModuleConfig.SerialModuleAddress+
                 ActualReply.Status+ActualReply.Opcode+
                 ActualReply.Value.Byte[3]+
                 ActualReply.Value.Byte[2]+
                 ActualReply.Value.Byte[1]+
                 ActualReply.Value.Byte[0];

        uart_write(ModuleConfig.SerialHostAddress);
        uart_write(ModuleConfig.SerialModuleAddress);
        uart_write(ActualReply.Status);
        uart_write(ActualReply.Opcode);
        uart_write(ActualReply.Value.Byte[3]);
        uart_write(ActualReply.Value.Byte[2]);
        uart_write(ActualReply.Value.Byte[1]);
        uart_write(ActualReply.Value.Byte[0]);
        uart_write(Checksum);
      }
      else if(TMCLReplyFormat==RF_SPECIAL)
      {
        for(i=0; i<9; i++)
        {
          uart_write(SpecialReply[i]);
        }
      }
    }
    //else SendASCIIReply(&ActualReply);
  }
  else if(TMCLCommandState==TCS_UART_ERROR)  //letztes Kommando �ber UART hatte falsche Pr�fsumme
  {
    ActualReply.Opcode=0;
    ActualReply.Status=REPLY_CHKERR;
    ActualReply.Value.Int32=0;

    Checksum=ModuleConfig.SerialHostAddress+ModuleConfig.SerialModuleAddress+
             ActualReply.Status+ActualReply.Opcode+
             ActualReply.Value.Byte[3]+
             ActualReply.Value.Byte[2]+
             ActualReply.Value.Byte[1]+
             ActualReply.Value.Byte[0];

    uart_write(ModuleConfig.SerialHostAddress);
    uart_write(ModuleConfig.SerialModuleAddress);
    uart_write(ActualReply.Status);
    uart_write(ActualReply.Opcode);
    uart_write(ActualReply.Value.Byte[3]);
    uart_write(ActualReply.Value.Byte[2]);
    uart_write(ActualReply.Value.Byte[1]);
    uart_write(ActualReply.Value.Byte[0]);
    uart_write(Checksum);
  }
#endif

#if defined(USB_INTERFACE)
	#if defined(UART_INTERFACE)
  	  else
  	#endif

  if(TMCLCommandState==TCS_USB)
  {
    if(!ASCIIMode)
    {
      if(TMCLReplyFormat==RF_STANDARD)
      {
        Checksum=ModuleConfig.SerialHostAddress+ModuleConfig.SerialModuleAddress+
                 ActualReply.Status+ActualReply.Opcode+
                 ActualReply.Value.Byte[3]+
                 ActualReply.Value.Byte[2]+
                 ActualReply.Value.Byte[1]+
                 ActualReply.Value.Byte[0];

        USBReply[0]=ModuleConfig.SerialHostAddress;
        USBReply[1]=ModuleConfig.SerialModuleAddress;
        USBReply[2]=ActualReply.Status;
        USBReply[3]=ActualReply.Opcode;
        USBReply[4]=ActualReply.Value.Byte[3];
        USBReply[5]=ActualReply.Value.Byte[2];
        USBReply[6]=ActualReply.Value.Byte[1];
        USBReply[7]=ActualReply.Value.Byte[0];
        USBReply[8]=Checksum;
      }
      else if(TMCLReplyFormat==RF_SPECIAL)
      {
        for(i=0; i<9; i++)
        {
          USBReply[i]=SpecialReply[i];
        }
      }
      usb_stm_sendData(USBReply, 9);
    }
    //else SendASCIIReply(&ActualReply);
  }
  else if(TMCLCommandState==TCS_USB_ERROR)  //letztes Kommando �ber USB hatte falsche Pr�fsumme
  {
    ActualReply.Opcode=0;
    ActualReply.Status=REPLY_CHKERR;
    ActualReply.Value.Int32=0;

    Checksum=ModuleConfig.SerialHostAddress+ModuleConfig.SerialModuleAddress+
             ActualReply.Status+ActualReply.Opcode+
             ActualReply.Value.Byte[3]+
             ActualReply.Value.Byte[2]+
             ActualReply.Value.Byte[1]+
             ActualReply.Value.Byte[0];

    USBReply[0]=ModuleConfig.SerialHostAddress;
    USBReply[1]=ModuleConfig.SerialModuleAddress;
    USBReply[2]=ActualReply.Status;
    USBReply[3]=ActualReply.Opcode;
    USBReply[4]=ActualReply.Value.Byte[3];
    USBReply[5]=ActualReply.Value.Byte[2];
    USBReply[6]=ActualReply.Value.Byte[1];
    USBReply[7]=ActualReply.Value.Byte[0];
    USBReply[8]=Checksum;

    usb_stm_sendData(USBReply, 9);
  }
  #endif

  //Zustand zur�cksetzen (Antwort ist nun gesendet)
  TMCLCommandState=TCS_IDLE;
  TMCLReplyFormat=RF_STANDARD;

  //Letzter Befehl war Reset-Befehl => Reset
  if(ResetRequested)
	  io_resetCPU(TRUE);

  // Befehl holen (Priorit�ten: UART, USB)
  #if defined(UART_INTERFACE)
  if(!ASCIIMode && uart_read((char *) &Byte))  //Befehl von RS232/RS485?
  {
    if(uart_checkTimeout()) UARTCount=0;  //bei Timeout alles bisherige verwerfen
    UARTCmd[UARTCount++]=Byte;

    if(UARTCount==9)  //Neun Bytes wurden empfangen
    {
      UARTCount=0;

      if(UARTCmd[0]==ModuleConfig.SerialModuleAddress)  //Stimmt die Adresse?
      {
        Checksum=0;
        for(i=0; i<8; i++) Checksum+=UARTCmd[i];

        if(Checksum==UARTCmd[8])  //Stimmt die Pr�fsumme?
        {
          ActualCommand.Opcode=UARTCmd[1];
          ActualCommand.Type=UARTCmd[2];
          ActualCommand.Motor=UARTCmd[3];
          ActualCommand.Value.Byte[3]=UARTCmd[4];
          ActualCommand.Value.Byte[2]=UARTCmd[5];
          ActualCommand.Value.Byte[1]=UARTCmd[6];
          ActualCommand.Value.Byte[0]=UARTCmd[7];

          SerialHeartbeatTimer = systick_stm_getTimer();
          SerialHeartbeatFlag=FALSE;
          TMCLCommandState=TCS_UART;

          UARTCount=0;
        }
        else TMCLCommandState=TCS_UART_ERROR;  //Pr�fsumme war falsch
      }
    }
  }
#endif

#if defined(USB_INTERFACE)
	#if defined(UART_INTERFACE)
    	else
    #endif

  if(!ASCIIMode && usb_stm_getUSBCmd(USBCmd))
  {
    if(USBCmd[0]==ModuleConfig.SerialModuleAddress)  //Stimmt die Adresse?
    {
      Checksum=0;
      for(i=0; i<8; i++) Checksum+=USBCmd[i];

      if(Checksum==USBCmd[8])  //Stimmt die Pr�fsumme?
      {
        ActualCommand.Opcode=USBCmd[1];
        ActualCommand.Type=USBCmd[2];
        ActualCommand.Motor=USBCmd[3];
        ActualCommand.Value.Byte[3]=USBCmd[4];
        ActualCommand.Value.Byte[2]=USBCmd[5];
        ActualCommand.Value.Byte[1]=USBCmd[6];
        ActualCommand.Value.Byte[0]=USBCmd[7];

        SerialHeartbeatTimer = systick_stm_getTimer();
        SerialHeartbeatFlag=FALSE;
        TMCLCommandState=TCS_USB;
      } else TMCLCommandState=TCS_USB_ERROR;  //Pr�fsumme war falsch
    }
  }
  #endif

  ExecuteActualCommand();
}


//**************************** Funktionen f�r die einzelnen TMCL-Befehle *****************
// F�r alle diese Funktionen gilt:
//   -die Parameter stehen in der globalen Variablen ActualCommand
//   -ein eventueller R�ckgabewert wird in der globalen Variablen ActualReply abgelegt.
//****************************************************************************************

/******************************
   Funktion: RotateLeft()

   Zweck: TMCL-Befehl ROL
 *******************************/
static void RotateLeft(void)
{
	bldc_stm_setTargetVelocity(-ActualCommand.Value.Int32);
}

/******************************
   Funktion: RotateRight()

   Zweck: TMCL-Befehl ROR
 *******************************/
static void RotateRight(void)
{
	bldc_stm_setTargetVelocity(ActualCommand.Value.Int32);
}

/******************************
   Funktion: MotorStop()

   Zweck: TMCL-Befehl MST
 *******************************/
static void MotorStop(void)
{
	bldc_stm_setTargetVelocity(0);
}

/******************************
   Funktion: MoveToPosition()

   Zweck: TMCL-Befehl MVP
 *******************************/
static void MoveToPosition(void)
{
	if(ActualCommand.Motor<N_O_MOTORS)
	{
		switch(ActualCommand.Type)
		{
			case MVP_ABS:
				bldc_stm_moveToAbsolutePosition(ActualCommand.Value.Int32);
				break;
			case MVP_REL:
				bldc_stm_moveToRelativePosition(ActualCommand.Value.Int32);
				break;
			default:
				ActualReply.Status=REPLY_WRONG_TYPE;
				break;
		}
	} else ActualReply.Status=REPLY_INVALID_VALUE;
}

/******************************
   Funktion: SetAxisParameter()

   Zweck: TMCL-Befehl SAP
 *******************************/
static void SetAxisParameter(void)
{
	if(ActualCommand.Motor<N_O_MOTORS)
	{
		switch(ActualCommand.Type)
		{
			case 0:
				bldc_stm_moveToAbsolutePosition(ActualCommand.Value.Int32);
				break;
			case 1:
				bldc_stm_setActualMotorPosition(ActualCommand.Value.Int32);
				break;
			case 2:
				bldc_stm_setTargetVelocity(ActualCommand.Value.Int32);
				break;
			case 4:
				MotorConfig[ActualCommand.Motor].MaxPositioningSpeed=ActualCommand.Value.Int32;
				break;
			case 5:
				if(ActualCommand.Value.Int32<=MAX_PWM_VALUE)
					MotorConfig[ActualCommand.Motor].PWMLimit=ActualCommand.Value.Int32;
				else
					ActualReply.Status=REPLY_INVALID_VALUE;
				break;
			case 6:
				MotorConfig[ActualCommand.Motor].MaximumCurrent=ActualCommand.Value.Int32;
				break;
			case 7:
				MotorConfig[ActualCommand.Motor].MVPTargetReachedVelocity=ActualCommand.Value.Int32;
				break;
			case 8:
				MotorConfig[ActualCommand.Motor].PIDVelSpeedThreshold=ActualCommand.Value.Int32;
				break;
			case 9:
				MotorConfig[ActualCommand.Motor].MotorHaltedVelocity = ActualCommand.Value.Int32;
				break;
			case 10:
				MotorConfig[ActualCommand.Motor].MVPTargetReachedDistance=ActualCommand.Value.Int32;
				break;
			case 11:
				MotorConfig[ActualCommand.Motor].Acceleration=ActualCommand.Value.Int32;
				break;
			case 12:
				MotorConfig[ActualCommand.Motor].PIDPosSpeedThreshold=ActualCommand.Value.Int32;
				break;
			case 14:
				MotorConfig[ActualCommand.Motor].hallFXSpeedThreshold = ActualCommand.Value.Int32;
				break;
			case 25:
				MotorConfig[ActualCommand.Motor].thermalWindingTimeConstant = ActualCommand.Value.Int32;
				break;
			case 26:
				MotorConfig[ActualCommand.Motor].iitLimit = ActualCommand.Value.Int32;
				break;
			case 130:
				MotorConfig[ActualCommand.Motor].PIDPosSet1_PParam=ActualCommand.Value.Int32;
				break;
			case 131:
				MotorConfig[ActualCommand.Motor].PIDPosSet1_IParam=ActualCommand.Value.Int32;
				break;
			case 132:
				MotorConfig[ActualCommand.Motor].PIDPosSet1_DParam=ActualCommand.Value.Int32;
				break;
			case 133:
				MotorConfig[ActualCommand.Motor].PIDRegulationDelay=ActualCommand.Value.Int32;
				break;
			case 134:
				MotorConfig[ActualCommand.Motor].CurrentRegulationDelay=ActualCommand.Value.Int32;
				break;
			case 135:
				MotorConfig[ActualCommand.Motor].PIDPosSet1_IClipping=ActualCommand.Value.Int32;
				break;
			case 136:
				MotorConfig[ActualCommand.Motor].PWMHysteresis=ActualCommand.Value.Int32;
				break;
			case 140:
				MotorConfig[ActualCommand.Motor].PIDVelSet1_PParam=ActualCommand.Value.Int32;
				break;
			case 141:
				MotorConfig[ActualCommand.Motor].PIDVelSet1_IParam=ActualCommand.Value.Int32;
				break;
			case 142:
				MotorConfig[ActualCommand.Motor].PIDVelSet1_DParam=ActualCommand.Value.Int32;
				break;
			case 143:
				MotorConfig[ActualCommand.Motor].PIDVelSet1_IClipping=ActualCommand.Value.Int32;
				break;
			case 146:
				if(ActualCommand.Value.Int32==0 || ActualCommand.Value.Int32==1)
					MotorConfig[ActualCommand.Motor].VelocityPIDControl=ActualCommand.Value.Byte[0];
				else
					ActualReply.Status=REPLY_INVALID_VALUE;
				break;
			case 154:
				bldc_stm_setTargetPWM(ActualCommand.Value.Int32);
				break;
			case 155:
				bldc_stm_setTargetMotorCurrent(ActualCommand.Value.Int32);
				break;
			case 159:
				if(ActualCommand.Value.Int32>=0 && ActualCommand.Value.Int32<=1)
					MotorConfig[ActualCommand.Motor].CommutationMode=ActualCommand.Value.Byte[0];
				else
					ActualReply.Status=REPLY_INVALID_VALUE;
				break;
			case 161:
				if(ActualCommand.Value.Int32!=0)
					MotorConfig[ActualCommand.Motor].PositioningFlags |= POSITION_CLEAR_ON_NULL;
				else
					MotorConfig[ActualCommand.Motor].PositioningFlags &= ~POSITION_CLEAR_ON_NULL;
				break;
			case 162:
				if(ActualCommand.Value.Int32!=0)
					MotorConfig[ActualCommand.Motor].PositioningFlags |= POSITION_CLEAR_ON_SWITCH;
				else
					MotorConfig[ActualCommand.Motor].PositioningFlags &= ~POSITION_CLEAR_ON_SWITCH;
				break;
			case 163:
				if(ActualCommand.Value.Int32!=0)
					MotorConfig[ActualCommand.Motor].PositioningFlags |= POSITION_CLEAR_ONLY_ONCE;
				else
					MotorConfig[ActualCommand.Motor].PositioningFlags &= ~POSITION_CLEAR_ONLY_ONCE;
				break;
			case 164:
				if(ActualCommand.Value.Int32>=0 && ActualCommand.Value.Int32<=3)
					MotorConfig[ActualCommand.Motor].StopSwitchEnable=ActualCommand.Value.Byte[0];
				else
					ActualReply.Status=REPLY_INVALID_VALUE;
				break;
			case 165:
				MotorConfig[ActualCommand.Motor].EncoderCommutationOffset=ActualCommand.Value.Int32;
				break;
			case 166:
				if(ActualCommand.Value.Int32>=0 && ActualCommand.Value.Int32<=3)
					MotorConfig[ActualCommand.Motor].StopSwitchPolarity=ActualCommand.Value.Byte[0];
				else
					ActualReply.Status=REPLY_INVALID_VALUE;
				break;
			case 167:
				if(ActualCommand.Value.Int32>=0 && ActualCommand.Value.Int32<3)
					MotorConfig[ActualCommand.Motor].BlockPwmScheme=ActualCommand.Value.Byte[0];
				else
					ActualReply.Status=REPLY_INVALID_VALUE;
				break;
			case 168:
				MotorConfig[ActualCommand.Motor].PIDCurSet1_PParam=ActualCommand.Value.Int32;
				break;
			case 169:
				MotorConfig[ActualCommand.Motor].PIDCurSet1_IParam=ActualCommand.Value.Int32;
				break;
			case 170:
				MotorConfig[ActualCommand.Motor].PIDCurSet1_DParam=ActualCommand.Value.Int32;
				break;
			case 171:
				MotorConfig[ActualCommand.Motor].PIDCurSet1_IClipping=ActualCommand.Value.Int32;
				break;
			case 172:
				MotorConfig[ActualCommand.Motor].PIDCurSet2_PParam=ActualCommand.Value.Int32;
				break;
			case 173:
				MotorConfig[ActualCommand.Motor].PIDCurSet2_IParam=ActualCommand.Value.Int32;
				break;
			case 174:
				MotorConfig[ActualCommand.Motor].PIDCurSet2_DParam=ActualCommand.Value.Int32;
				break;
			case 175:
				MotorConfig[ActualCommand.Motor].PIDCurSet2_IClipping=ActualCommand.Value.Int32;
				break;
			case 176:
				MotorConfig[ActualCommand.Motor].PIDCurSpeedThreshold=ActualCommand.Value.Int32;
				break;
			case 177:
				MotorConfig[ActualCommand.Motor].StartCurrent=ActualCommand.Value.Int32;
				break;
			case 230:
				MotorConfig[ActualCommand.Motor].PIDPosSet2_PParam=ActualCommand.Value.Int32;
				break;
			case 231:
				MotorConfig[ActualCommand.Motor].PIDPosSet2_IParam=ActualCommand.Value.Int32;
				break;
			case 232:
				MotorConfig[ActualCommand.Motor].PIDPosSet2_DParam=ActualCommand.Value.Int32;
				break;
			case 233:
				MotorConfig[ActualCommand.Motor].PIDPosSet2_IClipping=ActualCommand.Value.Int32;
				break;
			case 234:
				MotorConfig[ActualCommand.Motor].PIDVelSet2_PParam=ActualCommand.Value.Int32;
				break;
			case 235:
				MotorConfig[ActualCommand.Motor].PIDVelSet2_IParam=ActualCommand.Value.Int32;
				break;
			case 236:
				MotorConfig[ActualCommand.Motor].PIDVelSet2_DParam=ActualCommand.Value.Int32;
				break;
			case 237:
				MotorConfig[ActualCommand.Motor].PIDVelSet2_IClipping=ActualCommand.Value.Int32;
				break;
			case 238:
				MotorConfig[ActualCommand.Motor].MassInertiaConst=ActualCommand.Value.Int32;
				break;
			case 239:
				MotorConfig[ActualCommand.Motor].BEMFConst=ActualCommand.Value.Int32;
				break;
			case 240:
				MotorConfig[ActualCommand.Motor].MotorCoilResistance=ActualCommand.Value.Int32;
				break;
			case 241:
				MotorConfig[ActualCommand.Motor].InitSineSpeed=ActualCommand.Value.Int32;
				break;
			case 242:
				MotorConfig[ActualCommand.Motor].CommutationOffsetCW=ActualCommand.Value.Int32;
				break;
			case 243:
				MotorConfig[ActualCommand.Motor].CommutationOffsetCCW=ActualCommand.Value.Int32;
				break;
			case 244:
				MotorConfig[ActualCommand.Motor].InitSineDelay=ActualCommand.Value.Int32;
				break;
			case 245:
				MotorConfig[ActualCommand.Motor].OvervoltageProtection=(ActualCommand.Value.Int32!=0) ? TRUE:FALSE;
				break;
			case 247:
				MotorConfig[ActualCommand.Motor].SineCompensationFactor=ActualCommand.Value.Int32;
				break;
			case 249:
				MotorConfig[ActualCommand.Motor].InitSineMode=ActualCommand.Value.Int32;
				break;
			case 250:
				MotorConfig[ActualCommand.Motor].EncoderSteps=ActualCommand.Value.Int32;
				break;
			case 251:
				MotorConfig[ActualCommand.Motor].EncoderDirection=(ActualCommand.Value.Int32!=0) ? TRUE:FALSE;
				break;
			case 253:
				MotorConfig[ActualCommand.Motor].MotorPoles=ActualCommand.Value.Int32;
				break;
			case 254:
				MotorConfig[ActualCommand.Motor].HallInvertFlag=(ActualCommand.Value.Int32!=0) ? TRUE:FALSE;
				break;
			default:
				ActualReply.Status=REPLY_WRONG_TYPE;
				break;
		}
	} else ActualReply.Status=REPLY_INVALID_VALUE;
}

/******************************
   Funktion: GetAxisParameter()

   Zweck: TMCL-Befehl GAP
 *******************************/
static void GetAxisParameter(void)
{
	if(ActualCommand.Motor<N_O_MOTORS)
	{
		switch(ActualCommand.Type)
		{
			case 0:
				ActualReply.Value.Int32 = bldc_stm_getTargetMotorPosition();
				break;
			case 1:
				ActualReply.Value.Int32 = bldc_stm_getActualMotorPosition();
				break;
			case 2:
				ActualReply.Value.Int32 = bldc_stm_getTargetVelocity();
				break;
			case 3:
				ActualReply.Value.Int32 = bldc_stm_getActualSpeed();
				break;
			case 4:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].MaxPositioningSpeed;
				break;
			case 5:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].PWMLimit;
				break;
			case 6:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].MaximumCurrent;
				break;
			case 7:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].MVPTargetReachedVelocity;
				break;
			case 8:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].PIDVelSpeedThreshold;
				break;
			case 9:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].MotorHaltedVelocity;
				break;
			case 10:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].MVPTargetReachedDistance;
				break;
			case 11:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].Acceleration;
				break;
			case 12:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].PIDPosSpeedThreshold;
				break;
			case 13:
				ActualReply.Value.Int32 = bldc_stm_getRampGenSpeed();
				break;
			case 14:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].hallFXSpeedThreshold;
				break;
			case 20: // isLeftStopSwitchActive: status of left switch
				if((((MotorConfig[0].StopSwitchPolarity & BIT0) == 0) && (io_getPin(0) == 0)) ||
				   (((MotorConfig[0].StopSwitchPolarity & BIT0) == 1) && (io_getPin(0) == 1)))
					ActualReply.Value.Int32 = 1;
				else
					ActualReply.Value.Int32 = 0;
				break;
			case 21: // isRightStopSwitchActive: status of right stop switch
				if((((MotorConfig[0].StopSwitchPolarity & BIT1) == 0) && (io_getPin(1) == 0)) ||
				   (((MotorConfig[0].StopSwitchPolarity & BIT1) == 2) && (io_getPin(1) == 1)))
					ActualReply.Value.Int32 = 1;
				else
					ActualReply.Value.Int32 = 0;
				break;
			case 22:
				ActualReply.Value.Int32 = tmcm_getModuleSpecificADCValue(0);
				break;
			case 23:
				ActualReply.Value.Int32 = tmcm_getModuleSpecificADCValue(1);
				break;
			case 25:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].thermalWindingTimeConstant;
				break;
			case 26:
				ActualReply.Value.Int32 = MotorConfig[ActualCommand.Motor].iitLimit;
				break;
			case 130:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDPosSet1_PParam;
				break;
			case 131:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDPosSet1_IParam;
				break;
			case 132:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDPosSet1_DParam;
				break;
			case 133:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDRegulationDelay;
				break;
			case 134:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].CurrentRegulationDelay;
				break;
			case 135:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDPosSet1_IClipping;
				break;
			case 136:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PWMHysteresis;
				break;
			case 140:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDVelSet1_PParam;
				break;
			case 141:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDVelSet1_IParam;
				break;
			case 142:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDVelSet1_DParam;
				break;
			case 143:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDVelSet1_IClipping;
				break;
			case 146:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].VelocityPIDControl ? 1:0;
				break;
			case 150:
				ActualReply.Value.Int32=bldc_stm_getActualMotorCurrent();
				break;
			case 151:
				ActualReply.Value.Int32=adc_getADCValue(ADC_VOLTAGE);
				break;
			case 152:
				ActualReply.Value.Int32=adc_getADCValue(ADC_MOT_TEMP);
				break;
			case 153:
				ActualReply.Value.Int32 = bldc_stm_getActualPWMDutyCycle();
				break;
			case 154:
				ActualReply.Value.Int32=bldc_stm_getTargetPWM();
				break;
			case 155:
				ActualReply.Value.Int32=bldc_stm_getTargetMotorCurrent();
				break;
			case 156:
				ActualReply.Value.Int32 = bldc_stm_getAllStatusFlags();
				break;
			case 159:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].CommutationMode;
				break;
			case 161:
				ActualReply.Value.Int32=(MotorConfig[ActualCommand.Motor].PositioningFlags & POSITION_CLEAR_ON_NULL) ? 1:0;
				break;
			case 162:
				ActualReply.Value.Int32=(MotorConfig[ActualCommand.Motor].PositioningFlags & POSITION_CLEAR_ON_SWITCH) ? 1:0;
				break;
			case 163:
				ActualReply.Value.Int32=(MotorConfig[ActualCommand.Motor].PositioningFlags & POSITION_CLEAR_ONLY_ONCE) ? 1:0;
				break;
			case 164:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].StopSwitchEnable;
				break;
			case 165:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].EncoderCommutationOffset;
				break;
			case 166:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].StopSwitchPolarity;
				break;
			case 167:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].BlockPwmScheme;
				break;
			case 168:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDCurSet1_PParam;
				break;
			case 169:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDCurSet1_IParam;
				break;
			case 170:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDCurSet1_DParam;
				break;
			case 171:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDCurSet1_IClipping;
				break;
			case 172:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDCurSet2_PParam;
				break;
			case 173:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDCurSet2_IParam;
				break;
			case 174:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDCurSet2_DParam;
				break;
			case 175:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDCurSet2_IClipping;
				break;
			case 176:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDCurSpeedThreshold;
				break;
			case 177:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].StartCurrent;
				break;
			case 190:
				ActualReply.Value.Int32 = debug_getTestVar0();
				break;
			case 191:
				ActualReply.Value.Int32 = debug_getTestVar1();
				break;
			case 192:
				ActualReply.Value.Int32 = debug_getTestVar2();
				break;
			case 193:
				ActualReply.Value.Int32 = debug_getTestVar3();
				break;
			case 194:
				ActualReply.Value.Int32 = debug_getTestVar4();
				break;
			case 195:
				ActualReply.Value.Int32 = debug_getTestVar5();
				break;
			case 196:
				ActualReply.Value.Int32 = debug_getTestVar6();
				break;
			case 197:
				ActualReply.Value.Int32 = debug_getTestVar7();
				break;
			case 200:
				ActualReply.Value.Int32= bldc_stm_getCurrentPIDError();
				break;
			case 201:
				ActualReply.Value.Int32 = bldc_stm_getCurrentPIDErrorSum();
				break;
			case 226:
				ActualReply.Value.Int32 = bldc_stm_getPositionPIDError();
				break;
			case 227:
				ActualReply.Value.Int32 = bldc_stm_getPositionPIDErrorSum();
				break;
			case 228:
				ActualReply.Value.Int32 = bldc_stm_getVelocityPIDError();
				break;
			case 229:
				ActualReply.Value.Int32 = bldc_stm_getVelocityPIDErrorSum();
				break;
			case 230:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDPosSet2_PParam;
				break;
			case 231:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDPosSet2_IParam;
				break;
			case 232:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDPosSet2_DParam;
				break;
			case 233:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDPosSet2_IClipping;
				break;
			case 234:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDVelSet2_PParam;
				break;
			case 235:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDVelSet2_IParam;
				break;
			case 236:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDVelSet2_DParam;
				break;
			case 237:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].PIDVelSet2_IClipping;
				break;
			case 238:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].MassInertiaConst;
				break;
			case 239:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].BEMFConst;
				break;
			case 240:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].MotorCoilResistance;
				break;
			case 241:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].InitSineSpeed;
				break;
			case 242:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].CommutationOffsetCW;
				break;
			case 243:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].CommutationOffsetCCW;
				break;
			case 244:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].InitSineDelay;
				break;
			case 245:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].OvervoltageProtection ? 1:0;
				break;
			case 247:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].SineCompensationFactor;
				break;
			case 249:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].InitSineMode;
				break;
			case 250:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].EncoderSteps;
				break;
			case 251:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].EncoderDirection ? 1:0;
				break;
			case 253:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].MotorPoles;
				break;
			case 254:
				ActualReply.Value.Int32=MotorConfig[ActualCommand.Motor].HallInvertFlag ? 1:0;
				break;
			default:
				ActualReply.Status=REPLY_WRONG_TYPE;
				break;
		}
  } else ActualReply.Status=REPLY_INVALID_VALUE;
}

/******************************
   Funktion: StoreAxisParameter()

   Zweck: TMCL-Befehl STAP
 *******************************/
static void StoreAxisParameter(void)
{
  if(ActualCommand.Motor<N_O_MOTORS)
  {
    switch(ActualCommand.Type)
    {
      case 4:
        eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].MaxPositioningSpeed-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].MaxPositioningSpeed, sizeof(MotorConfig[0].MaxPositioningSpeed));
        break;

      case 5:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PWMLimit-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PWMLimit, sizeof(MotorConfig[0].PWMLimit));
        break;

      case 6:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].MaximumCurrent-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].MaximumCurrent, sizeof(MotorConfig[0].MaximumCurrent));
        break;

      case 7:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].MVPTargetReachedVelocity-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].MVPTargetReachedVelocity, sizeof(MotorConfig[0].MVPTargetReachedVelocity));
        break;

      case 8:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSpeedThreshold-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSpeedThreshold, sizeof(MotorConfig[0].PIDVelSpeedThreshold));
        break;

      case 9:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].MotorHaltedVelocity-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].MotorHaltedVelocity, sizeof(MotorConfig[0].MotorHaltedVelocity));
        break;

      case 10:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].MVPTargetReachedDistance-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].MVPTargetReachedDistance, sizeof(MotorConfig[0].MVPTargetReachedDistance));
        break;

      case 11:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].Acceleration-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].Acceleration, sizeof(MotorConfig[0].Acceleration));
        break;

      case 12:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSpeedThreshold-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSpeedThreshold, sizeof(MotorConfig[0].PIDPosSpeedThreshold));
        break;
      case 14:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].hallFXSpeedThreshold-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].hallFXSpeedThreshold, sizeof(MotorConfig[0].hallFXSpeedThreshold));
        break;

      case 25:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                                 (UINT) &MotorConfig[ActualCommand.Motor].thermalWindingTimeConstant-(UINT) &MotorConfig[ActualCommand.Motor],
                                 (UCHAR *) &MotorConfig[ActualCommand.Motor].thermalWindingTimeConstant, sizeof(MotorConfig[0].thermalWindingTimeConstant));
    	  break;
      case 26:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                                 (UINT) &MotorConfig[ActualCommand.Motor].iitLimit-(UINT) &MotorConfig[ActualCommand.Motor],
                                 (UCHAR *) &MotorConfig[ActualCommand.Motor].iitLimit, sizeof(MotorConfig[0].iitLimit));
    	  break;
      case 130:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet1_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet1_PParam, sizeof(MotorConfig[0].PIDPosSet1_PParam));
        break;

      case 131:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet1_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet1_IParam, sizeof(MotorConfig[0].PIDPosSet1_IParam));
        break;

      case 132:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet1_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet1_DParam, sizeof(MotorConfig[0].PIDPosSet1_DParam));
        break;

      case 133:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDRegulationDelay-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDRegulationDelay, sizeof(MotorConfig[0].PIDRegulationDelay));
        break;

      case 134:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].CurrentRegulationDelay-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].CurrentRegulationDelay, sizeof(MotorConfig[0].CurrentRegulationDelay));
        break;

      case 135:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet1_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet1_IClipping, sizeof(MotorConfig[0].PIDPosSet1_IClipping));
        break;

      case 136:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PWMHysteresis-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PWMHysteresis, sizeof(MotorConfig[0].PWMHysteresis));
        break;

      case 140:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet1_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet1_PParam, sizeof(MotorConfig[0].PIDVelSet1_PParam));
        break;

      case 141:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet1_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet1_IParam, sizeof(MotorConfig[0].PIDVelSet1_IParam));
        break;

      case 142:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet1_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet1_DParam, sizeof(MotorConfig[0].PIDVelSet1_DParam));
        break;

      case 143:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet1_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet1_IClipping, sizeof(MotorConfig[0].PIDVelSet1_IClipping));
        break;

      case 146:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].VelocityPIDControl-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].VelocityPIDControl, sizeof(MotorConfig[0].VelocityPIDControl));
        break;

      case 159:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].CommutationMode-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].CommutationMode, sizeof(MotorConfig[0].CommutationMode));
        break;
      case 161:
      case 162:
      case 163:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PositioningFlags-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PositioningFlags, sizeof(MotorConfig[0].PositioningFlags));
        break;

      case 164:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].StopSwitchEnable-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].StopSwitchEnable, sizeof(MotorConfig[0].StopSwitchEnable));
        break;

      case 165:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].EncoderCommutationOffset-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].EncoderCommutationOffset, sizeof(MotorConfig[0].EncoderCommutationOffset));
        break;

      case 166:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].StopSwitchPolarity-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].StopSwitchPolarity, sizeof(MotorConfig[0].StopSwitchPolarity));
        break;

      case 167:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].BlockPwmScheme-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].BlockPwmScheme, sizeof(MotorConfig[0].BlockPwmScheme));
        break;

      case 168:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet1_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet1_PParam, sizeof(MotorConfig[0].PIDCurSet1_PParam));
        break;

      case 169:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet1_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet1_IParam, sizeof(MotorConfig[0].PIDCurSet1_IParam));
        break;

      case 170:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet1_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet1_DParam, sizeof(MotorConfig[0].PIDCurSet1_DParam));
        break;

      case 171:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet1_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet1_IClipping, sizeof(MotorConfig[0].PIDCurSet1_IClipping));
        break;

      case 172:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet2_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet2_PParam, sizeof(MotorConfig[0].PIDCurSet2_PParam));
        break;

      case 173:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet2_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet2_IParam, sizeof(MotorConfig[0].PIDCurSet2_IParam));
        break;

      case 174:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet2_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet2_DParam, sizeof(MotorConfig[0].PIDCurSet2_DParam));
        break;

      case 175:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet2_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet2_IClipping, sizeof(MotorConfig[0].PIDCurSet2_IClipping));
        break;

      case 176:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSpeedThreshold-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSpeedThreshold, sizeof(MotorConfig[0].PIDCurSpeedThreshold));
        break;

      case 177:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].StartCurrent-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].StartCurrent, sizeof(MotorConfig[0].StartCurrent));
        break;

      case 230:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet2_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet2_PParam, sizeof(MotorConfig[0].PIDPosSet2_PParam));
        break;

      case 231:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet2_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet2_IParam, sizeof(MotorConfig[0].PIDPosSet2_IParam));
        break;

      case 232:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet2_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet2_DParam, sizeof(MotorConfig[0].PIDPosSet2_DParam));
        break;

      case 233:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet2_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet2_IClipping, sizeof(MotorConfig[0].PIDPosSet2_IClipping));
        break;

      case 234:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet2_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet2_PParam, sizeof(MotorConfig[0].PIDVelSet2_PParam));
        break;

      case 235:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet2_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet2_IParam, sizeof(MotorConfig[0].PIDVelSet2_IParam));
        break;

      case 236:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet2_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet2_DParam, sizeof(MotorConfig[0].PIDVelSet2_DParam));
        break;

      case 237:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet2_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet2_IClipping, sizeof(MotorConfig[0].PIDVelSet2_IClipping));
        break;

      case 238:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].MassInertiaConst-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].MassInertiaConst, sizeof(MotorConfig[0].MassInertiaConst));
        break;

      case 239:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].BEMFConst-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].BEMFConst, sizeof(MotorConfig[0].BEMFConst));
        break;

      case 240:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].MotorCoilResistance-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].MotorCoilResistance, sizeof(MotorConfig[0].MotorCoilResistance));
        break;

      case 241:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].InitSineSpeed-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].InitSineSpeed, sizeof(MotorConfig[0].InitSineSpeed));
        break;

      case 242:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].CommutationOffsetCW-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].CommutationOffsetCW, sizeof(MotorConfig[0].CommutationOffsetCW));
        break;

      case 243:
    	  eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].CommutationOffsetCCW-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].CommutationOffsetCCW, sizeof(MotorConfig[0].CommutationOffsetCCW));
        break;

      case 244:
        eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].InitSineDelay-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].InitSineDelay, sizeof(MotorConfig[0].InitSineDelay));
        break;

      case 245:
        eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].OvervoltageProtection-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].OvervoltageProtection, sizeof(MotorConfig[0].OvervoltageProtection));
        break;
      case 247:
        eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].SineCompensationFactor-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].SineCompensationFactor, sizeof(MotorConfig[0].SineCompensationFactor));
        break;

      case 249:
        eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].InitSineMode-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].InitSineMode, sizeof(MotorConfig[0].InitSineMode));
        break;

      case 250:
        eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].EncoderSteps-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].EncoderSteps, sizeof(MotorConfig[0].EncoderSteps));
        break;

      case 251:
        eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].EncoderDirection-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].EncoderDirection, sizeof(MotorConfig[0].EncoderDirection));
        break;
      case 253:
        eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].MotorPoles-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].MotorPoles, sizeof(MotorConfig[0].MotorPoles));
        break;

      case 254:
        eeprom_writeConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].HallInvertFlag-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].HallInvertFlag, sizeof(MotorConfig[0].HallInvertFlag));
        break;

      default:
        ActualReply.Status=REPLY_WRONG_TYPE;
        break;
    }
  }
  else ActualReply.Status=REPLY_INVALID_VALUE;
}


/******************************
   Funktion: RestoreAxisParameter()

   Zweck: TMCL-Befehl GGP
 *******************************/
static void RestoreAxisParameter(void)
{
  if(ActualCommand.Motor<N_O_MOTORS)
  {
    switch(ActualCommand.Type)
    {
      case 4:
        eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].MaxPositioningSpeed-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].MaxPositioningSpeed, sizeof(MotorConfig[0].MaxPositioningSpeed));
        break;

      case 5:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].PWMLimit-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].PWMLimit, sizeof(MotorConfig[0].PWMLimit));
        break;

      case 6:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].MaximumCurrent-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].MaximumCurrent, sizeof(MotorConfig[0].MaximumCurrent));
        break;

      case 7:
    		  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].MVPTargetReachedVelocity-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].MVPTargetReachedVelocity, sizeof(MotorConfig[0].MVPTargetReachedVelocity));
    	  break;

      case 8:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSpeedThreshold-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSpeedThreshold, sizeof(MotorConfig[0].PIDVelSpeedThreshold));
        break;
      case 9:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].MotorHaltedVelocity-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].MotorHaltedVelocity, sizeof(MotorConfig[0].MotorHaltedVelocity));
        break;
      case 10:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].MVPTargetReachedDistance-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].MVPTargetReachedDistance, sizeof(MotorConfig[0].MVPTargetReachedDistance));
        break;

      case 11:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].Acceleration-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].Acceleration, sizeof(MotorConfig[0].Acceleration));
        break;

      case 12:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSpeedThreshold-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSpeedThreshold, sizeof(MotorConfig[0].PIDPosSpeedThreshold));
        break;
      case 14:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].hallFXSpeedThreshold-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].hallFXSpeedThreshold, sizeof(MotorConfig[0].hallFXSpeedThreshold));
        break;
      case 25:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].thermalWindingTimeConstant-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].thermalWindingTimeConstant, sizeof(MotorConfig[0].thermalWindingTimeConstant));
    	  break;
      case 26:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].iitLimit-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].iitLimit, sizeof(MotorConfig[0].iitLimit));
    	  break;
      case 130:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet1_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet1_PParam, sizeof(MotorConfig[0].PIDPosSet1_PParam));
        break;
      case 131:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet1_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet1_IParam, sizeof(MotorConfig[0].PIDPosSet1_IParam));
        break;

      case 132:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet1_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet1_DParam, sizeof(MotorConfig[0].PIDPosSet1_DParam));
        break;

      case 133:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].PIDRegulationDelay-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDRegulationDelay, sizeof(MotorConfig[0].PIDRegulationDelay));
        break;

      case 134:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].CurrentRegulationDelay-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].CurrentRegulationDelay, sizeof(MotorConfig[0].CurrentRegulationDelay));
        break;

      case 135:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet1_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet1_IClipping, sizeof(MotorConfig[0].PIDPosSet1_IClipping));
        break;

      case 136:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].PWMHysteresis-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].PWMHysteresis, sizeof(MotorConfig[0].PWMHysteresis));
        break;

      case 140:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet1_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet1_PParam, sizeof(MotorConfig[0].PIDVelSet1_PParam));
        break;

      case 141:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet1_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet1_IParam, sizeof(MotorConfig[0].PIDVelSet1_IParam));
        break;

      case 142:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet1_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet1_DParam, sizeof(MotorConfig[0].PIDVelSet1_DParam));
        break;

      case 143:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet1_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet1_IClipping, sizeof(MotorConfig[0].PIDVelSet1_IClipping));
        break;

      case 146:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                              (UINT) &MotorConfig[ActualCommand.Motor].VelocityPIDControl-(UINT) &MotorConfig[ActualCommand.Motor],
                              (UCHAR *) &MotorConfig[ActualCommand.Motor].VelocityPIDControl, sizeof(MotorConfig[0].VelocityPIDControl));
        break;

      case 159:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].CommutationMode-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].CommutationMode, sizeof(MotorConfig[0].CommutationMode));
        break;

      case 161:
      case 162:
      case 163:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].PositioningFlags-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].PositioningFlags, sizeof(MotorConfig[0].PositioningFlags));
        break;
      case 164:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].StopSwitchEnable-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].StopSwitchEnable, sizeof(MotorConfig[0].StopSwitchEnable));
        break;

      case 165:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].EncoderCommutationOffset-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].EncoderCommutationOffset, sizeof(MotorConfig[0].EncoderCommutationOffset));
        break;

      case 166:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].StopSwitchPolarity-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].StopSwitchPolarity, sizeof(MotorConfig[0].StopSwitchPolarity));
        break;

      case 167:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].BlockPwmScheme-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].BlockPwmScheme, sizeof(MotorConfig[0].BlockPwmScheme));
        break;

      case 168:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet1_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet1_PParam, sizeof(MotorConfig[0].PIDCurSet1_PParam));
        break;

      case 169:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet1_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet1_IParam, sizeof(MotorConfig[0].PIDCurSet1_IParam));
        break;

      case 170:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet1_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet1_DParam, sizeof(MotorConfig[0].PIDCurSet1_DParam));
        break;

      case 171:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet1_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet1_IClipping, sizeof(MotorConfig[0].PIDCurSet1_IClipping));
        break;

      case 172:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet2_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet2_PParam, sizeof(MotorConfig[0].PIDCurSet2_PParam));
        break;

      case 173:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet2_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet2_IParam, sizeof(MotorConfig[0].PIDCurSet2_IParam));
        break;

      case 174:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet2_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet2_DParam, sizeof(MotorConfig[0].PIDCurSet2_DParam));
        break;

      case 175:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSet2_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSet2_IClipping, sizeof(MotorConfig[0].PIDCurSet2_IClipping));
        break;

      case 176:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDCurSpeedThreshold-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDCurSpeedThreshold, sizeof(MotorConfig[0].PIDCurSpeedThreshold));
        break;

      case 177:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].StartCurrent-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].StartCurrent, sizeof(MotorConfig[0].StartCurrent));
        break;

      case 230:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet2_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet2_PParam, sizeof(MotorConfig[0].PIDPosSet2_PParam));
        break;

      case 231:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet2_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet2_IParam, sizeof(MotorConfig[0].PIDPosSet2_IParam));
        break;

      case 232:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet2_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet2_DParam, sizeof(MotorConfig[0].PIDPosSet2_DParam));
        break;

      case 233:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDPosSet2_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDPosSet2_IClipping, sizeof(MotorConfig[0].PIDPosSet2_IClipping));
        break;

      case 234:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet2_PParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet2_PParam, sizeof(MotorConfig[0].PIDVelSet2_PParam));
        break;

      case 235:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet2_IParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet2_IParam, sizeof(MotorConfig[0].PIDVelSet2_IParam));
        break;

      case 236:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet2_DParam-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet2_DParam, sizeof(MotorConfig[0].PIDVelSet2_DParam));
        break;

      case 237:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
                               (UINT) &MotorConfig[ActualCommand.Motor].PIDVelSet2_IClipping-(UINT) &MotorConfig[ActualCommand.Motor],
                               (UCHAR *) &MotorConfig[ActualCommand.Motor].PIDVelSet2_IClipping, sizeof(MotorConfig[0].PIDVelSet2_IClipping));
        break;

      case 238:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].MassInertiaConst-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].MassInertiaConst, sizeof(MotorConfig[0].MassInertiaConst));
        break;

      case 239:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].BEMFConst-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].BEMFConst, sizeof(MotorConfig[0].BEMFConst));
        break;

      case 240:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].MotorCoilResistance-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].MotorCoilResistance, sizeof(MotorConfig[0].MotorCoilResistance));
        break;

      case 241:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].InitSineSpeed-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].InitSineSpeed, sizeof(MotorConfig[0].InitSineSpeed));
        break;

      case 242:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].CommutationOffsetCW-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].CommutationOffsetCW, sizeof(MotorConfig[0].CommutationOffsetCW));
        break;

      case 243:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].CommutationOffsetCCW-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].CommutationOffsetCCW, sizeof(MotorConfig[0].CommutationOffsetCCW));
        break;

      case 244:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].InitSineDelay-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].InitSineDelay, sizeof(MotorConfig[0].InitSineDelay));
        break;

      case 245:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].OvervoltageProtection-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].OvervoltageProtection, sizeof(MotorConfig[0].OvervoltageProtection));
        break;
      case 247:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].SineCompensationFactor-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].SineCompensationFactor, sizeof(MotorConfig[0].SineCompensationFactor));
        break;

      case 249:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].InitSineMode-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].InitSineMode, sizeof(MotorConfig[0].InitSineMode));
        break;

      case 250:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].EncoderSteps-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].EncoderSteps, sizeof(MotorConfig[0].EncoderSteps));
        break;

      case 251:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].EncoderDirection-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].EncoderDirection, sizeof(MotorConfig[0].EncoderDirection));
        break;

      case 253:
    	  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].MotorPoles-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].MotorPoles, sizeof(MotorConfig[0].MotorPoles));
        break;

      case 254:
    		  eeprom_readConfigBlock(ADDR_MOTOR_CONFIG+ActualCommand.Motor*SIZE_MOTOR_CONFIG+
    				  (UINT) &MotorConfig[ActualCommand.Motor].HallInvertFlag-(UINT) &MotorConfig[ActualCommand.Motor],
    				  (UCHAR *) &MotorConfig[ActualCommand.Motor].HallInvertFlag, sizeof(MotorConfig[0].HallInvertFlag));
        break;

      default:
        ActualReply.Status=REPLY_WRONG_TYPE;
        break;
    }
  }
  else ActualReply.Status=REPLY_INVALID_VALUE;
}


/******************************
   Funktion: SetGlobalParameter()

   Zweck: TMCL-Befehl GGP
 *******************************/
static void SetGlobalParameter(void)
{
  switch(ActualCommand.Motor)
  {
    case 0:
      switch(ActualCommand.Type)
      {
        case 64:                      //64..127: Parameter, die automatisch im EEPROM abgelegt werden
          eeprom_writeConfigByte(ADDR_EEPROM_MAGIC, ActualCommand.Value.Byte[0]);
          break;

        case 65:
          ModuleConfig.Baudrate=ActualCommand.Value.Byte[0];
          eeprom_writeConfigByte(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.Baudrate - (UINT) &ModuleConfig,
                                ModuleConfig.Baudrate);
          break;

        case 66:
          ModuleConfig.SerialModuleAddress=ActualCommand.Value.Byte[0];
          eeprom_writeConfigByte(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.SerialModuleAddress - (UINT) &ModuleConfig,
                                ModuleConfig.SerialModuleAddress);
          break;

        case 67:
          ModuleConfig.ASCIIMode=ActualCommand.Value.Byte[0];
          eeprom_writeConfigByte(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.ASCIIMode - (UINT) &ModuleConfig,
                                ModuleConfig.ASCIIMode);
          break;

        case 68:
          ModuleConfig.SerialHeartbeat=ActualCommand.Value.Int32;
          eeprom_writeConfigBlock(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.SerialHeartbeat - (UINT) &ModuleConfig,
                                  (UCHAR *) &ModuleConfig.SerialHeartbeat, sizeof(ModuleConfig.SerialHeartbeat));
          break;

        case 69:
          ModuleConfig.CANBitrate=ActualCommand.Value.Byte[0];  //�nderungen der CAN-Bitrate wirken sich nicht sofort aus!
          eeprom_writeConfigByte(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.CANBitrate - (UINT) &ModuleConfig,
                                ModuleConfig.CANBitrate);
          break;

        case 70:
          ModuleConfig.CANSendID=ActualCommand.Value.Int32;
          eeprom_writeConfigBlock(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.CANSendID - (UINT) &ModuleConfig,
                                  (UCHAR *) &ModuleConfig.CANSendID, sizeof(ModuleConfig.CANSendID));
          break;

        case 71:
          ModuleConfig.CANReceiveID=ActualCommand.Value.Int32;
          eeprom_writeConfigBlock(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.CANReceiveID - (UINT) &ModuleConfig,
                                  (UCHAR *) &ModuleConfig.CANReceiveID, sizeof(ModuleConfig.CANReceiveID));
          break;

        case 73:
          if(ActualCommand.Value.Byte[0]==0)
            ModuleConfig.EEPROMLockFlag=FALSE;
          else
          {
            ModuleConfig.EEPROMLockFlag=TRUE;
            ActualReply.Value.Int32=1;
          }
          eeprom_writeConfigByte(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.EEPROMLockFlag - (UINT) &ModuleConfig,
                                ModuleConfig.EEPROMLockFlag);
          break;

      #if defined(UART_INTERFACE)
        case 75:
          ModuleConfig.TelegramPauseTime=ActualCommand.Value.Byte[0];
          eeprom_writeConfigByte(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.TelegramPauseTime - (UINT) &ModuleConfig,
                                ModuleConfig.TelegramPauseTime);
          uart_setTransmitDelay(ModuleConfig.TelegramPauseTime);
          break;
      #endif

        case 76:
          ModuleConfig.SerialHostAddress=ActualCommand.Value.Byte[0];
          eeprom_writeConfigByte(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.SerialHostAddress - (UINT) &ModuleConfig,
                                ModuleConfig.SerialHostAddress);
          break;

        case 77:
          ModuleConfig.TMCLAutostartFlag=ActualCommand.Value.Byte[0];
          eeprom_writeConfigByte(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.TMCLAutostartFlag - (UINT) &ModuleConfig,
                                ModuleConfig.TMCLAutostartFlag);
          break;

        case 80:
          ModuleConfig.ShutdownPinMode=ActualCommand.Value.Byte[0];
          eeprom_writeConfigByte(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.ShutdownPinMode - (UINT) &ModuleConfig,
                                ModuleConfig.ShutdownPinMode);
          break;

        case 82:
          ModuleConfig.CANHeartbeat=ActualCommand.Value.Int32;
          eeprom_writeConfigBlock(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.CANHeartbeat - (UINT) &ModuleConfig,
                                  (UCHAR *) &ModuleConfig.CANHeartbeat, sizeof(ModuleConfig.CANHeartbeat));
          break;

        case 83:
          ModuleConfig.CANSecondaryID=ActualCommand.Value.Int32;
          eeprom_writeConfigBlock(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.CANSecondaryID - (UINT) &ModuleConfig,
                                  (UCHAR *) &ModuleConfig.CANSecondaryID, sizeof(ModuleConfig.CANSecondaryID));
          break;

        case 85:
          if(ActualCommand.Value.Int32==0 || ActualCommand.Value.Int32==1)
          {
            ModuleConfig.ZeroUserVariables=ActualCommand.Value.Byte[0];
            eeprom_writeConfigBlock(ADDR_MODULE_CONFIG+(UINT) &ModuleConfig.ZeroUserVariables - (UINT) &ModuleConfig,
                                    (UCHAR *) &ModuleConfig.ZeroUserVariables, sizeof(ModuleConfig.ZeroUserVariables));
          }
          else ActualReply.Status=REPLY_INVALID_VALUE;
          break;

        case 90:
        	ModuleConfig.ethercatTimout = ActualCommand.Value.Int32;
            eeprom_writeConfigBlock(ADDR_MODULE_CONFIG+(UINT)&ModuleConfig.ethercatTimout - (UINT) &ModuleConfig,
                                    (UCHAR *)&ModuleConfig.ethercatTimout, sizeof(ModuleConfig.ethercatTimout));
        	break;


        case 255:
          TMCLSuppressReply=ActualCommand.Value.Byte[0];
          break;

        default:
          ActualReply.Status=REPLY_WRONG_TYPE;
          break;
      }
      break;

    case 2:	//TMCL user variables
    	if (ActualCommand.Type < TMCL_EEPROM_USER_VARS)
    		TMCLUserVariable[ActualCommand.Type] = ActualCommand.Value.Int32;
    	else
    		ActualReply.Status = REPLY_WRONG_TYPE;
    	break;
    default:
    	ActualReply.Status = REPLY_INVALID_VALUE;
    	break;
  }
}

/******************************
   Funktion: GetGlobalParameter()

   Zweck: TMCL-Befehl GGP
 *******************************/
static void GetGlobalParameter(void)
{
  switch(ActualCommand.Motor)
  {
    case 0:
    	// module config values
      switch(ActualCommand.Type)
      {
        case 64:
          ActualReply.Value.Int32 = eeprom_readConfigByte(ADDR_EEPROM_MAGIC);
          break;

        case 65:
          ActualReply.Value.Int32=ModuleConfig.Baudrate;
          break;

        case 66:
          ActualReply.Value.Int32=ModuleConfig.SerialModuleAddress;
          break;

        case 67:
          ActualReply.Value.Int32=ModuleConfig.ASCIIMode;
          break;

        case 68:
          ActualReply.Value.Int32=ModuleConfig.SerialHeartbeat;
          break;

        case 69:
          ActualReply.Value.Int32=ModuleConfig.CANBitrate;
          break;

        case 70:
          ActualReply.Value.Int32=ModuleConfig.CANSendID;
          break;

        case 71:
          ActualReply.Value.Int32=ModuleConfig.CANReceiveID;
          break;

        case 73:
          ActualReply.Value.Int32=ModuleConfig.EEPROMLockFlag ? 1:0;
          break;

      #if !defined(UART_INTERFACE)
        case 75:
          ActualReply.Value.Int32=ModuleConfig.TelegramPauseTime;
          break;
      #endif

        case 76:
          ActualReply.Value.Int32=ModuleConfig.SerialHostAddress;
          break;

        case 77:
          ActualReply.Value.Int32=ModuleConfig.TMCLAutostartFlag;
          break;

        case 80:
          ActualReply.Value.Int32=ModuleConfig.ShutdownPinMode;
          break;

        case 81:
          ActualReply.Value.Int32=ModuleConfig.TMCLProtectionMode;
          break;

        case 82:
          ActualReply.Value.Int32=ModuleConfig.CANHeartbeat;
          break;

        case 83:
          ActualReply.Value.Int32=ModuleConfig.CANSecondaryID;
          break;

        case 85:
          ActualReply.Value.Int32=ModuleConfig.ZeroUserVariables;
          break;

        case 90:
        	ActualReply.Value.Int32=ModuleConfig.ethercatTimout;
        	break;

        case 128:
          ActualReply.Value.Int32=TMCLMode;
          break;

        case 129:
          ActualReply.Value.Int32=(TMCLMode==TM_DOWNLOAD) ? 1:0;
          break;

        case 240:
          ActualReply.Value.Int32=ExtClockFlag;
          break;

        case 254:
          ActualReply.Value.Int32=ExtClockFlag;
          break;

        case 255:
          ActualReply.Value.Int32=TMCLSuppressReply ? 1:0;
          break;

        default:
          ActualReply.Status=REPLY_WRONG_TYPE;
          break;
      }
      break;

    case 2:
    	// user variables
    	ActualReply.Value.Int32 = TMCLUserVariable[ActualCommand.Type];
    	break;
    default:
      ActualReply.Status=REPLY_INVALID_VALUE;
      break;
  }
}


/***********************************
   Funktion: StoreGlobalParameter()

   Zweck: TMCL-Befehl STGP
 ***********************************/
static void StoreGlobalParameter(void)
{
	switch(ActualCommand.Motor)
	{
    	case 2:
    		// store user variables
    		if(ActualCommand.Type<TMCL_EEPROM_USER_VARS)
    			eeprom_writeConfigBlock(ADDR_TMCL_USER_VARS+ActualCommand.Type*4, (UCHAR *) &TMCLUserVariable[ActualCommand.Type], 4);
    		else
    			ActualReply.Status=REPLY_WRONG_TYPE;
    		break;
    	default:
    		ActualReply.Status=REPLY_INVALID_VALUE;
    		break;
	}
}


/*************************************
   Funktion: RestoreGlobalParameter()

   Zweck: TMCL-Befehl RSGP
 *************************************/
static void RestoreGlobalParameter(void)
{
	switch(ActualCommand.Motor)
	{
    	case 2: // restore user variables
    		if(ActualCommand.Type < TMCL_EEPROM_USER_VARS)
    			eeprom_readConfigBlock(ADDR_TMCL_USER_VARS+ActualCommand.Type*4, (UCHAR *) &TMCLUserVariable[ActualCommand.Type], 4);
    		else
    			ActualReply.Status=REPLY_WRONG_TYPE;
    		break;
    	default:
    		ActualReply.Status=REPLY_INVALID_VALUE;
    		break;
	}
}

/******************************
   Funktion: SetOutput()
   Zweck: TMCL-Befehl SIO
 *******************************/
static void SetOutput(void)
{
	switch(ActualCommand.Motor)
	{
    	case 1:
    		if(ActualCommand.Type<N_O_MOTORS)
    		{
    			if(ActualCommand.Value.Int32==0)
    				io_disableSingleMotor(ActualCommand.Type);
    			else
    				io_enableSingleMotor(ActualCommand.Type);
    		}
    		else ActualReply.Status=REPLY_WRONG_TYPE;
    		break;
    	case 2:
    		if(ActualCommand.Value.Int32==0)
    			io_clearPin(ActualCommand.Type);
    		else
    			io_setPin(ActualCommand.Type);
    		break;
    	default:
    		ActualReply.Status=REPLY_INVALID_VALUE;
    		break;
	}
}

/******************************
   Funktion: GetInput()

   Zweck: TMCL-Befehl GIO
 *******************************/
static void GetInput(void)
{
	switch(ActualCommand.Motor)
	{
    	case 0:
    		ActualReply.Value.Int32 = io_getPin(ActualCommand.Type);
    		break;
    	case 1:
    		switch(ActualCommand.Type)
    		{
#if defined(ADC_IN0) && ADC_IN!=ADC_INVALID_VALUE
    			case 0:
    				ActualReply.Value.Int32 = tmcm_getModuleSpecificADCValue(ActualCommand.Type);
    				break;
#endif
#if defined(ADC_IN1) && ADC_IN!=ADC_INVALID_VALUE
    			case 1:
    				ActualReply.Value.Int32 = tmcm_getModuleSpecificADCValue(ActualCommand.Type);
    				break;
#endif
#if defined(ADC_IN2) && ADC_IN!=ADC_INVALID_VALUE
    			case 2:
    				ActualReply.Value.Int32 = tmcm_getModuleSpecificADCValue(ActualCommand.Type);
    				break;
#endif
#if defined(ADC_IN3) && ADC_IN!=ADC_INVALID_VALUE
    			case 3:
    				ActualReply.Value.Int32 = tmcm_getModuleSpecificADCValue(ActualCommand.Type);
    				break;
#endif
        default:
          ActualReply.Status=REPLY_WRONG_TYPE;
          break;
      }
      break;

    case 2:
      ActualReply.Value.Int32 = io_getPinStatus(ActualCommand.Type);
      break;

    default:
      ActualReply.Status=REPLY_INVALID_VALUE;
      break;
  }
}

/******************************
   Funktion: GetVersion()

   Zweck: TMCL-Befehl 136
         (Get Version)
 *******************************/
static void GetVersion(void)
{
	UINT i;

	if(ActualCommand.Type==0)
	{
		TMCLReplyFormat=RF_SPECIAL;
		SpecialReply[0]=ModuleConfig.SerialHostAddress;
		for(i=0; i<8; i++)
			SpecialReply[i+1]=VersionString[i];
	}
	else if(ActualCommand.Type==1)
	{
		ActualReply.Value.Byte[3]=SW_TYPE_HIGH;
		ActualReply.Value.Byte[2]=SW_TYPE_LOW;
		ActualReply.Value.Byte[1]=SW_VERSION_HIGH;
		ActualReply.Value.Byte[0]=SW_VERSION_LOW;
	}
}

/*********************************
   Funktion: SecurityCode()

   Zweck: TMCL-Befehl 140
          (set security code)
 *********************************/
static void SecurityCode(void)
{
  UINT Code;

  switch(ActualCommand.Type)
  {
    case 0:
    	eeprom_readConfigBlock(ADDR_SECURITY_CODE, (UCHAR *) &Code, 4);
      if((UINT) ActualCommand.Value.Int32==Code)
        ActualReply.Value.Int32=1;
      else
        ActualReply.Value.Int32=0;
      break;

    case 1:
      if(ActualCommand.Motor==42)
        eeprom_writeConfigBlock(ADDR_SECURITY_CODE, (UCHAR *) &ActualCommand.Value.Int32, 4);
      else
        ActualReply.Status=REPLY_WRONG_TYPE;
      break;

    default:
      ActualReply.Status=REPLY_WRONG_TYPE;
      break;
  }
}

/****************************************
   Funktion: FactoryDefault()

   Zweck: Zur�cksetzen auf
          Werkseinstellungen.
 ***************************************/
static void FactoryDefault(void)
{
	if(ActualCommand.Type==0 && ActualCommand.Motor==0 && ActualCommand.Value.Int32==1234)
	{
		eeprom_writeConfigByte(ADDR_EEPROM_MAGIC, 0);
		io_resetCPU(TRUE);
	}
}

/****************************************
   Funktion: Boot()

   Zweck: Spezialbefehl zum Aufruf des
          Bootloaders.
 ***************************************/
static void Boot(void)
{
	if(ActualCommand.Type==0x81 && ActualCommand.Motor==0x92 &&
		ActualCommand.Value.Byte[3]==0xa3 && ActualCommand.Value.Byte[2]==0xb4 &&
		ActualCommand.Value.Byte[1]==0xc5 && ActualCommand.Value.Byte[0]==0xd6)
	{
		DISABLE_DRIVER();

#if defined(USB_INTERFACE)
		usb_stm_detachUSB();
		UINT Delay = systick_stm_getTimer();
		while(abs(systick_stm_getTimer()-Delay)<1000) RESET_WATCHDOG();
#endif

		io_disableInterrupts();
		NVIC_DeInit();
		SysTick_ITConfig(DISABLE);
		DMA_Cmd(DMA1_Channel1, DISABLE);
		DMA_DeInit(DMA1_Channel1);
		ADC_DeInit(ADC1);

		io_resetCPU(FALSE);
	}
}

/******************************
   Funktion: SoftwareReset()

   Zweck: TMCL-Befehl 255
          (Reset)
 *******************************/
static void SoftwareReset(void)
{
	if(ActualCommand.Value.Int32==1234) ResetRequested=TRUE;
}
