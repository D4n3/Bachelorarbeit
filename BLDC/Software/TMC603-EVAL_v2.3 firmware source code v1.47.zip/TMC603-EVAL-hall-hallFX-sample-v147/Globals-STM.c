/****************************************************
  Projekt: TMCM-STM

  Modul:   Globals-STM.c
           Globale Variablen

  Datum:   26.5.2009 OK
*****************************************************/

#include "Globals-STM.h"

//Datenstruktur f�r allgemeine Konfigurationsdaten.
//Diese ist hier nur eine Grundinitialisierung, falls das
//EEPROM noch neu ist. Deshalb hier nicht "const".
TModuleConfig ModuleConfig=
{
  0,     //Baudrate RS232/RS485 (9600bps)
  1,     //Moduladresse RS232/RS485
  2,     //Anwortadresse RS232/RS485
  0,     //Pausenzeit RS232/RS485
  0,     //Startmodus (bin�r/ASCII)
  8,     //CAN-Bitrate (1000kBit/s)
  0,     //CAN Ext/Std-Flag (nicht verwendet)
  1,     //CAN-Empfangs-ID
  2,     //CAN-Sende-ID
  0,     //zweite CAN-ID
  0,     //Schutz f�r TMCL-Programm
  0,     //TMCL-Autostart
  0,     //Shutdown-Pin
  0,     //EEPROM-Lock
  0,     //User-Variablen aus EEPROM oder mit Null initialisiern (0=EEPROM (default), 1=Null)
  0,     //SerialHeartbeat (ausgeschaltet)
  0,     //CAN Heartbeat (ausgeschaltet)
  DEFAULT_EthercatTimeout,	 // Time to trigger an EtherCat timeout
  {0, 0, 0, 0, 0, 0, 0, 0,	 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,	 0}  //Reserve
};

TMotorConfig MotorConfig[N_O_MOTORS]=
{{
  DEFAULT_MAX_POSITIONING_SPEED,       //MaxPositioningSpeed
  DEFAULT_PWM_LIMIT,                   //PWMLimit
  DEFAULT_MAXIMUM_CURRENT,             //MaximumCurrent
  DEFAULT_MVP_TARGET_REACHED_VELOCITY, //MVPTargetReachedVelocity
  DEFAULT_MIN_VEL_PID_SPEED,           //MinVelPIDSpeed
  DEFAULT_MVP_TARGET_REACHED_DISTANCE, //MVPTargetReachedDistance
  DEFAULT_MOTOR_HALTED_VELOCITY,
  DEFAULT_ACCELERATION,                //Acceleration
  DEFAULT_MIN_POS_PID_SPEED,           //MinPosPIDSpeed
  DEFAULT_PID_POS_PPARAM,              //PIDPos_PParam
  DEFAULT_PID_POS_IPARAM,              //PIDPos_IParam
  DEFAULT_PID_POS_DPARAM,              //PIDPos_DParam
  DEFAULT_PID_POS_ICLIPPING,           //PIDPos_IClipping
  DEFAULT_PID_REGULATION_DELAY,        //PIDRegulationDelay
  DEFAULT_CURRENT_REGULATION_DELAY,    //CurrentRegulationDelay
  DEFAULT_PWM_HYSTERESIS,              //PWMHysteresis
  DEFAULT_PID_VEL_PPARAM,              //PIDVel_PParam
  DEFAULT_PID_VEL_IPARAM,              //PIDVel_IParam
  DEFAULT_PID_VEL_DPARAM,              //PIDVel_DParam
  DEFAULT_PID_VEL_ICLIPPING,           //PIDVel_IClipping
  DEFAULT_VELOCITY_PID_CONTROL,        //VelocityPIDControl
  DEFAULT_COMMUTATION_MODE,            //CommutationMode
  DEFAULT_STOP_SWITCH_ENABLE,          //StopSwitchEnable
  DEFAULT_STOP_SWITCH_POLARITY,        //StopSwitchPolarity
  DEFAULT_HALL_INVERT_FLAG,            //HallInvertFlag
  DEFAULT_MOTOR_POLES,                 //MotorPoles
  DEFAULT_HARD_STOP_FLAG,              //HardStopFlag
  DEFAULT_INIT_SINE_SPEED,             //InitSineSpeed
  DEFAULT_COMMUTATION_OFFSET_CCW,      //CommutationOffsetCCW
  DEFAULT_COMMUTATION_OFFSET_CW,       //CommutationOffsetCW
  DEFAULT_INIT_SINE_DELAY,             //InitSineDelay
  DEFAULT_MASS_INERTIA_CONST,          //MassInertiaConst
  DEFAULT_RDS_ON,                      //RdsOn
  DEFAULT_INIT_SINE_MODE,              //InitSineMode
  DEFAULT_OVERVOLTAGE_PROTECTION,      //OvervoltageProtection
  DEFAULT_ENCODER_DIRECTION,           //EncoderDirection
  DEFAULT_BLOCK_PWM_SCHEME,            //BlockPwmScheme
  DEFAULT_PID_SLOW_CUR_PPARAM,         //PIDSlowCur_PParam
  DEFAULT_PID_SLOW_CUR_IPARAM,         //PIDSlowCur_IParam
  DEFAULT_PID_SLOW_CUR_DPARAM,         //PIDSlowCur_DParam
  DEFAULT_PID_SLOW_CUR_ICLIPPING,      //PIDSlowCur_IClipping
  DEFAULT_PID_FAST_CUR_PPARAM,         //PIDFastCur_PParam
  DEFAULT_PID_FAST_CUR_IPARAM,         //PIDFastCur_IParam
  DEFAULT_PID_FAST_CUR_DPARAM,         //PIDFastCur_DParam
  DEFAULT_PID_FAST_CUR_ICLIPPING,      //PIDFastCur_IClipping
  DEFAULT_PID_CUR_VTHRESHOLD,          //PIDCurVThreshold
  DEFAULT_START_CURRENT,               //StartCurrent
  DEFAULT_ENCODER_STEPS,               //EncoderSteps
  DEFAULT_ENCODER_COMMUTATION_OFFSET,  //EncoderCommutationOffset
  DEFAULT_ENCODER_FLAGS,               //EncoderFlags
  DEFAULT_BEMF_CONST,                  //BEMFConst
  DEFAULT_MOTOR_COIL_RESISTANCE,       //MotorCoilResistance
  DEFAULT_PID_POS_HIGH_PPARAM,         //PIDPosHigh_PParam
  DEFAULT_PID_POS_HIGH_IPARAM,         //PIDPosHigh_IParam
  DEFAULT_PID_POS_HIGH_DPARAM,         //PIDPosHigh_DParam
  DEFAULT_PID_POS_HIGH_ICLIPPING,      //PIDPosHigh_IClipping
  DEFAULT_PID_VEL_HIGH_PPARAM,         //PIDVelHigh_PParam
  DEFAULT_PID_VEL_HIGH_IPARAM,         //PIDVelHigh_IParam
  DEFAULT_PID_VEL_HIGH_DPARAM,         //PIDVelHigh_DParam
  DEFAULT_PID_VEL_HIGH_ICLIPPING,      //PIDVelHigh_IClipping
  DEFAULT_SINE_COMPENSATION_FACTOR,    //SineCompensationFactor
  DEFAULT_EXTERNAL_SHUNT,              //ExternalShunt
  DEFAULT_POSITIONING_FLAGS,           //PositioningFlags
  DEFAULT_IIT_LIMIT,
  DEFAULT_THERMAL_WINDING_TIME_CONSTANT,
  0,									// iitExceededFlag
  DEFAULT_HALLFX_SPEED_THRESHOLD,
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0} // for further use
}};

UCHAR ExtClockFlag;                    //TRUE wenn externer Takt (8MHz-Quarz aktiv), FALSE wenn interner Takt aktiv
UCHAR ResetToFactoryDefaultRequested;  //TRUE wenn ein Reset auf Werkseinstellungen erfolgen soll
UCHAR USBInterface;                    //TRUE wenn USB-Interface vorhanden (FALSE bei CAN)
PIrqFunction CanRx0UsbLpIrqVector;     //Interrupt-Vektor f�r CAN-RX0 oder USB
UINT SerialHeartbeatTimer;             //Timer f�r RS232/RS485/USB-Heartbeat
UCHAR SerialHeartbeatFlag;             //TRUE wenn Motor durch RS232/RS485/USB-Heartbeat-Timeout gestoppt wurde
