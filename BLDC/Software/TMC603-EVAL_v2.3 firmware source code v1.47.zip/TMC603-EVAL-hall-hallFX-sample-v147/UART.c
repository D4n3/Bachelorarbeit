/****************************************************
  Projekt: TMCM-STM

  Modul:   UART.c
           UART-Funktionen (Bytes Senden/Empfangen)

  Datum:   6.3.2009 OK (reworked by ed)
*****************************************************/

#include "UART.h"

#if defined(UART_INTERFACE)

#define UART1_INTR_PRI        7
#define UART2_INTR_PRI        6
#define UART3_INTR_PRI        5

#define UART_BUFFER_SIZE 32
#define UART_TIMEOUT_VALUE 10   //Timeout-Wert in 0.5ms (also 10 => 5ms)

static volatile char UART3RxBuffer[UART_BUFFER_SIZE];
static volatile char UART3TxBuffer[UART_BUFFER_SIZE];
static volatile int UART3RxReadPtr;
static volatile int UART3RxWritePtr;
static volatile int UART3TxReadPtr;
static volatile int UART3TxWritePtr;
volatile UCHAR UART3TimeoutFlag;
volatile UINT UART3TimeoutTimer;
static volatile UINT UART3TransmitDelay;
volatile UINT UART3TransmitDelayTimer;

/* initialize UART3 (bitrate code: 0..11) */
void uart_init(int baudRate)
{
	// activate UART3
	USART_DeInit(USART3);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

	// activate GPIOB (UART3-Pins)
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_GPIOB, DISABLE);
	GPIO_PinRemapConfig(GPIO_PartialRemap_USART3, DISABLE);

	// assign UART3-Pins (PB10 and PB11)
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// configure UART3
	USART_InitTypeDef  UART_InitStructure;
	USART_StructInit(&UART_InitStructure);
	switch(baudRate)
	{
    	case 0:
    		UART_InitStructure.USART_BaudRate=9600;
    		break;
    	case 1:
    		UART_InitStructure.USART_BaudRate=14400;
    		break;
    	case 2:
    		UART_InitStructure.USART_BaudRate=19200;
    		break;
    	case 3:
    		UART_InitStructure.USART_BaudRate=28800;
    		break;
    	case 4:
    		UART_InitStructure.USART_BaudRate=38400;
    		break;
    	case 5:
    		UART_InitStructure.USART_BaudRate=57600;
    		break;
    	case 6:
    		UART_InitStructure.USART_BaudRate=76800;
    		break;
    	case 7:
    		UART_InitStructure.USART_BaudRate=115200;
    		break;
    	case 8:
    		UART_InitStructure.USART_BaudRate=230400;
    		break;
    	case 9:
    		UART_InitStructure.USART_BaudRate=250000;
    		break;
    	case 10:
    		UART_InitStructure.USART_BaudRate=500000;
    		break;
    	case 11:
    		UART_InitStructure.USART_BaudRate=1000000;
    		break;
    	default:
    		UART_InitStructure.USART_BaudRate=9600;
    		break;
	}
	USART_Init(USART3,&UART_InitStructure);

	// activate interrupt for UART3
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQChannel;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = UART3_INTR_PRI;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	USART_ClearFlag(USART3, USART_FLAG_CTS | USART_FLAG_LBD  | USART_FLAG_TXE  |
			USART_FLAG_TC  | USART_FLAG_RXNE | USART_FLAG_IDLE |
			USART_FLAG_ORE | USART_FLAG_NE   | USART_FLAG_FE | USART_FLAG_PE);
	USART_ITConfig(USART3,USART_IT_PE  ,DISABLE);
	USART_ITConfig(USART3,USART_IT_TXE ,ENABLE);
	USART_ITConfig(USART3,USART_IT_TC  ,ENABLE);
	USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);
	USART_ITConfig(USART3,USART_IT_IDLE,DISABLE);
	USART_ITConfig(USART3,USART_IT_LBD ,DISABLE);
	USART_ITConfig(USART3,USART_IT_CTS ,DISABLE);
	USART_ITConfig(USART3,USART_IT_ERR ,DISABLE);

	USART_Cmd(USART3, ENABLE);
}


/*******************************************************************
  UART-Interrupthandler f�r UART 3
  Wird durch den NVIC aufgerufen, wenn ein UART-Interrupt auftritt.
  Dies paasiert, wenn ein Zeichen angekommen ist oder
  ein Zeichen gesendet werden kann.
  Der Aufruf dieser Funktion mu� in stm32f10x_it.c eingetragen werden.
********************************************************************/
void UART3Irq(void)
{
  int i;

  //Ist ein Zeichen  angekommen?
  if(USART3->SR & USART_FLAG_RXNE)
  {
    //Wenn RS485 gerade auf Senden geschaltet ist, dann ist
    //es ein Echo, das hier ignoriert wird.
    if(IS_RS485_SENDING())
    {
      i=USART3->DR;
    }
    else
    {
      //Zeichen in den Empfangspuffer kopieren
      i=UART3RxWritePtr+1;
      if(i==UART_BUFFER_SIZE) i=0;

      if(i!=UART3RxReadPtr)
      {
        UART3RxBuffer[UART3RxWritePtr]=USART3->DR;
        UART3RxWritePtr=i;
      }

      //Empfangs-Timeout auf Startwert setzen
      UART3TimeoutTimer=UART_TIMEOUT_VALUE;

      //Sendeverz�gerung auf Startwert setzen
      UART3TransmitDelayTimer=UART3TransmitDelay;
    }
  }

  //Kann das n�chste Zeichen gesendet werden?
  if(USART3->SR & USART_FLAG_TXE)
  {
    if(UART3TransmitDelayTimer==0)
    {
      if(UART3TxWritePtr!=UART3TxReadPtr)
      {
        SET_RS485_SEND_MODE();
        USART3->DR=UART3TxBuffer[UART3TxReadPtr++];
        if(UART3TxReadPtr==UART_BUFFER_SIZE) UART3TxReadPtr=0;
      }
      else
      {
        //Sendeinterrupt deaktivieren, wenn kein Zeichen im Sendepuffer ist
        USART_ITConfig(USART3,USART_IT_TXE ,DISABLE);
      }
    }
  }

  //Allerletztes Bit gesendet?
  if(USART3->SR & USART_FLAG_TC)
  {
    USART_ClearITPendingBit(USART3, USART_IT_TC);
    if(UART3TxReadPtr==UART3TxWritePtr)
    {
    	SET_RS485_RECEIVE_MODE();
    }
  }
}

/* write a character to the UART3 interface */
void uart_write(char ch)
{
	//Zeichen in die Warteschlange stellen
	int i = UART3TxWritePtr+1;
	if(i==UART_BUFFER_SIZE)
		i=0;

	if(i!=UART3TxReadPtr)
	{
		UART3TxBuffer[UART3TxWritePtr]=ch;
		UART3TxWritePtr=i;

		// activate send interrupt
		USART_ITConfig(USART3, USART_IT_TXE, ENABLE);
	}
}

/* read a character from UART3 input buffer (false if there is no available character)*/
char uart_read(char *ch)
{
	// no character available?
	if(UART3RxReadPtr==UART3RxWritePtr)
		return FALSE;

	// get the char from the buffer
	*ch = UART3RxBuffer[UART3RxReadPtr++];
	if(UART3RxReadPtr==UART_BUFFER_SIZE)
		UART3RxReadPtr=0;

	return TRUE;
}

/* set send time-delay (important for some RS485 adapter) */
void uart_setTransmitDelay(UINT delay)
{
	UART3TransmitDelay = delay;
}

/* check if a timeout had occured (whether time between two bytes was > 5ms) */
UINT uart_checkTimeout()
{
	if(UART3TimeoutFlag)
	{
		UART3TimeoutFlag = FALSE;
		return TRUE;
	} else return FALSE;
}

/* send a debug message to UART3 */
void uart_printDebug(char *message)
{
	UINT i;
	for(i=0; message[i]!=0; i++)
		uart_write((char) message[i]);
}

#endif
