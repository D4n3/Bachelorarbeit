/****************************************************
  Projekt: TMCM-STM

  Modul:   TMCL-STM.h
           TMCL-Interpreter f�r BLDC-Module mit STM32

  Datum:   26.5.2009 OK (updated by ed)
*****************************************************/

#ifndef TMCL_STM_H_
#define TMCL_STM_H_

	#include "TMCM-STM.h"
	#include "TMCL-Defines.h"
	#include "TMCL-Variables.h"

	void tmcl_stm_init();
	void tmcl_stm_processCommand();
	void tmcl_executeBinaryCommand(UCHAR *BinaryCommand, UCHAR *BinaryResult);

#endif
