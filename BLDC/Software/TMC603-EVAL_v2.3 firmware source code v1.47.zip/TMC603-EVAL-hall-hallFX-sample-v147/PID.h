/*
 * PID.h
 *
 *  Created on: 15.02.2011
 *      Author: ed
 */

#ifndef PID_H_
#define PID_H_

	#include "TMCM-STM.h"

	typedef struct
	{
		int error;            //Regelabweichung
		int errorSum;         //Integrationssumme f�r I-Anteil
		int errorOld;		  //vorheriger Fehler f�r D-Anteil
		int pParam;           //P-Parameter
		int iParam;           //I-Parameter
		int dParam;           //D-Parameter
		int iClipping;        //I-Clipping-Parameter
		int FeedForward;      //Ergebnis der Feed-Forward-Regelung
		int result;			  //Ergebnis des PID-Reglers
	} TPIDControl;

	void pid_resetPIDControl(TPIDControl *pidControl);
	void pid_checkParamSet(TPIDControl *pidControl, int speed, int switchSpeed, int pSet1, int iSet1, int dSet1, int iClippSet1, int pSet2, int iSet2, int dSet2, int iClippSet2);

#endif /* PID_H_ */
