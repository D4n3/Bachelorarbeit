/*
 * Debug.h
 *
 *  Created on: 14.07.2011
 *      Author: ed
 */

#ifndef DEBUG_H_
#define DEBUG_H_

	#include "../../TMCM-STM.h"

	// getter/setter for test variables
	int debug_getTestVar0();
	int debug_getTestVar1();
	int debug_getTestVar2();
	int debug_getTestVar3();
	int debug_getTestVar4();
	int debug_getTestVar5();
	int debug_getTestVar6();
	int debug_getTestVar7();

	void debug_setTestVar0(int value);
	void debug_setTestVar1(int value);
	void debug_setTestVar2(int value);
	void debug_setTestVar3(int value);
	void debug_setTestVar4(int value);
	void debug_setTestVar5(int value);
	void debug_setTestVar6(int value);
	void debug_setTestVar7(int value);

#endif /* DEBUG_H_ */
