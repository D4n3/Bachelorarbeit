/*
 * PWM.c
 *
 *  Created on: 20.06.2011
 *      Author: ed (based on work of OK)
 */
#include "PWM.h"

UINT actualADCPhaseUsed;					// actual used phase for ADC measurement

UCHAR pwm_getActualUsedPhase()
{
	return actualADCPhaseUsed;
}

/* block pwm scheme (depending by the actual chopper mode) */
void pwm_scheme_block(UCHAR chopperMode, UCHAR hardStopFlag, int actualPWM, UCHAR actualMotorDirection,  UCHAR hallState, UCHAR motorHaltedFlag)
{
    if(actualMotorDirection)
    	hallState ^= 0x07;

	switch(chopperMode)
	{
		case CHOP_MODE_HIGH_SIDE:
			if(actualPWM == 0)
			{
				if(hardStopFlag == STOP_FLAG_FREE_RUNNING)
					pwm_scheme_HOffLOff();
				else if(hardStopFlag == STOP_FLAG_EMERGENCY_STOP)
					pwm_scheme_FullBrake();
				else
					pwm_scheme_HOffLOn(actualMotorDirection, hallState, motorHaltedFlag);
			}else{
				pwm_scheme_HPwmLOn(actualMotorDirection, hallState, motorHaltedFlag);
			}
			break;
		case CHOP_MODE_LOW_SIDE:
			if(actualPWM == 0)
			{
				if(hardStopFlag == STOP_FLAG_FREE_RUNNING)
					pwm_scheme_HOffLOff();
				else if(hardStopFlag == STOP_FLAG_EMERGENCY_STOP)
					pwm_scheme_FullBrake();
				else
					pwm_scheme_HOffLOn(actualMotorDirection, hallState, motorHaltedFlag);
			}else{
				pwm_scheme_HOnLPwm(actualMotorDirection, hallState, motorHaltedFlag);
			}
			break;
		case CHOP_MODE_DUAL_SIDE:
			if(actualPWM == 0)
			{
				if(hardStopFlag == STOP_FLAG_FREE_RUNNING)
					pwm_scheme_HOffLOff();
				else if(hardStopFlag == STOP_FLAG_EMERGENCY_STOP)
					pwm_scheme_FullBrake();
				else
					pwm_scheme_HOffLOn(actualMotorDirection, hallState, motorHaltedFlag);
			}else{
				pwm_scheme_HPwmLPwm(actualMotorDirection, hallState, motorHaltedFlag);
			}
			break;
		case CHOP_MODE_HALLFX:
		    if(actualMotorDirection)
		    	hallState ^= 0x07;

			pwm_scheme_HallFX(actualMotorDirection, hallState, motorHaltedFlag);
			break;
		case CHOP_MODE_LOW_SIDE_ON:
			pwm_scheme_HOffLOn(actualMotorDirection, hallState, motorHaltedFlag);
			break;
		case CHOP_MODE_FULL_BRAKE:
			pwm_scheme_FullBrake();
			break;
		case CHOP_MODE_DUAL_SIDE_OFF:
			pwm_scheme_HOffLOff();
			break;
	}
}

/* pwm scheme (chopper on high side) */
void pwm_scheme_HPwmLOn(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag)
{
    switch(hallState)
    {
    	case 0:
    		// hall error
    		break;
    	case 3:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_pwm_hi(PWM_PHASE_B);
    		pwm_set_____lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 1:
    		pwm_set_pwm_hi(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_____lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 5:
    		pwm_set_pwm_hi(PWM_PHASE_A);
    		pwm_set_____lo(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 4:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_____lo(PWM_PHASE_B);
    		pwm_set_pwm_hi(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 6:
    		pwm_set_____lo(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_pwm_hi(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 2:
    		pwm_set_____lo(PWM_PHASE_A);
    		pwm_set_pwm_hi(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 7:
    		// hall error
    		break;
    }
}

/* pwm scheme for current measurement (turns high-side off, low-side on, and toggles "sample") */
void pwm_scheme_HOffLOn(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag)
{
    switch(hallState)
    {
    	case 0:
    		// hall error
    		break;
    	case 3:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_____lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 1:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_____lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 5:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_____lo(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 4:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_____lo(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 6:
    		pwm_set_____lo(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 2:
    		pwm_set_____lo(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 7:
    		// hall error
    		break;
    }
}

/* pwm sheme with chopper on low-side */
void pwm_scheme_HOnLPwm(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag)
{
    switch(hallState)
    {
    	case 0:
    		// hall error
    		break;
    	case 3:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_____hi(PWM_PHASE_B);
    		pwm_set_pwm_lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 1:
    		pwm_set_____hi(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_pwm_lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 5:
    		pwm_set_____hi(PWM_PHASE_A);
    		pwm_set_pwm_lo(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 4:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_pwm_lo(PWM_PHASE_B);
    		pwm_set_____hi(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 6:
    		pwm_set_pwm_lo(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_____hi(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 2:
    		pwm_set_pwm_lo(PWM_PHASE_A);
    		pwm_set_____hi(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 7:
    		// hall error
    		break;
    }
}

/* pwm scheme with chopper on high side and low side */
void pwm_scheme_HPwmLPwm(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag)
{
    switch(hallState)
    {
    	case 0:
    		// hall error
    		break;
    	case 3:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_pwm_hi(PWM_PHASE_B);
    		pwm_set_pwm_lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 1:
    		pwm_set_pwm_hi(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_pwm_lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 5:
    		pwm_set_pwm_hi(PWM_PHASE_A);
    		pwm_set_pwm_lo(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 4:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_pwm_lo(PWM_PHASE_B);
    		pwm_set_pwm_hi(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 6:
    		pwm_set_pwm_lo(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_pwm_hi(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 2:
    		pwm_set_pwm_lo(PWM_PHASE_A);
    		pwm_set_pwm_hi(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 7:
    		// hall error
    		break;
    }
}

/* pwm scheme for hallFX (chopper on high side and low side) */
void pwm_scheme_HallFX(UCHAR actualMotorDirection, UCHAR hallState, UCHAR motorHaltedFlag)
{
    switch (hallState)
    {
    	case 0:
    		// hall error
    		break;
    	case 4:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_pwm_lo(PWM_PHASE_B);
    		pwm_set_pwm_hi(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 6:
    		pwm_set_pwm_lo(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_pwm_hi(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 2:
    		pwm_set_pwm_lo(PWM_PHASE_A);
    		pwm_set_pwm_hi(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_A : ADC_INVALID_VALUE;
    		break;
    	case 3:
    		pwm_set____off(PWM_PHASE_A);
    		pwm_set_pwm_hi(PWM_PHASE_B);
    		pwm_set_pwm_lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 1:
    		pwm_set_pwm_hi(PWM_PHASE_A);
    		pwm_set____off(PWM_PHASE_B);
    		pwm_set_pwm_lo(PWM_PHASE_C);
    		actualADCPhaseUsed = (actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_C : ADC_INVALID_VALUE;
    		break;
    	case 5:
    		pwm_set_pwm_hi(PWM_PHASE_A);
    		pwm_set_pwm_lo(PWM_PHASE_B);
    		pwm_set____off(PWM_PHASE_C);
    		actualADCPhaseUsed = (!actualMotorDirection || motorHaltedFlag) ? ADC_PHASE_B : ADC_INVALID_VALUE;
    		break;
    	case 7:
    		// hall error
    		break;
    }
}

/* pwm scheme for free-running (turns high-side and low-side off */
void pwm_scheme_HOffLOff()
{
	pwm_set____off(PWM_PHASE_A);
	pwm_set____off(PWM_PHASE_B);
	pwm_set____off(PWM_PHASE_C);
}

/* pwm scheme for full-brake (turns high-sides off and low-sides on) */
void pwm_scheme_FullBrake()
{
	pwm_set_____lo(PWM_PHASE_A);
	pwm_set_____lo(PWM_PHASE_B);
	pwm_set_____lo(PWM_PHASE_C);
}

/* set phase to "positive without PWM" */
inline void pwm_set_____hi(USHORT phase)
{
	TIM_SelectOCxM(TIM1, phase, TIM_ForcedAction_Active);
	TIM_CCxCmd(TIM1, phase, TIM_CCx_Enable);
	TIM_CCxNCmd(TIM1, phase, TIM_CCxN_Enable);
}

/* set phase to "negative without PWM */
inline void pwm_set_____lo(USHORT phase)
{
    TIM_SelectOCxM(TIM1, phase, TIM_ForcedAction_InActive );
    TIM_CCxCmd(TIM1, phase, TIM_CCx_Enable);
    TIM_CCxNCmd(TIM1, phase, TIM_CCxN_Enable);
}

/* set phase to "positive with PWM */
inline void pwm_set_pwm_hi(USHORT phase)
{
    TIM_SelectOCxM(TIM1, phase, TIM_OCMode_PWM1);
    TIM_CCxCmd(TIM1, phase, TIM_CCx_Enable);
    TIM_CCxNCmd(TIM1, phase, TIM_CCxN_Disable);
}

/* set phase to "negative with PWM */
inline void pwm_set_pwm_lo(USHORT phase)
{
    TIM_SelectOCxM(TIM1, phase, TIM_OCMode_PWM1);
    TIM_CCxCmd(TIM1, phase, TIM_CCx_Disable);
    TIM_CCxNCmd(TIM1, phase, TIM_CCxN_Enable);
}

/* set phase to "not energized" */
inline void pwm_set____off(USHORT phase)
{
    TIM_CCxCmd(TIM1, phase, TIM_CCx_Disable);
    TIM_CCxNCmd(TIM1, phase, TIM_CCxN_Disable);
}
