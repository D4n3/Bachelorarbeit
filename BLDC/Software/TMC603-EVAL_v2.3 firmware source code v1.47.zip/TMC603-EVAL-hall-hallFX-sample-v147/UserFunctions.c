/****************************************************
  Projekt: TMCM-STM

  Modul:   UserFunctions.c
           Kundenspezifische TMCL-Befehle

  Datum:   26.5.2010 OK
*****************************************************/

#include "UserFunctions.h"

extern TTMCLCommand ActualCommand;
extern TTMCLReply ActualReply;
extern UCHAR TMCLModifyAccu;
extern int TMCLAccu;
extern int TMCLXReg;

/*******************************************************************
   Funktion: userfunctions_init()
   Zweck: Initialisierung der kundenspezifischen Erweiterungen.
********************************************************************/
void userfunctions_init(){}

/*******************************************************************
   Funktion: userfunctions_Appl()
   Zweck: Periodische Aufgaben f�r kundenspezifische Erweiterung.
   Diese Funktion mu� periodisch aus der Hauptschleife heraus
   aufgerufen werden.
********************************************************************/
void userfunctions_Appl(){}

/*******************************************************************
   Funktion: userfunctions_F0
   Zweck: TMCL-Befehl UF0.
********************************************************************/
void userfunctions_F0(){}

/*******************************************************************
   Funktion: userfunctions_F1
   Zweck: TMCL-Befehl UF0.
********************************************************************/
void userfunctions_F1(){}

/*******************************************************************
   Funktion: userfunctions_F2
   Zweck: TMCL-Befehl UF2.
********************************************************************/
void userfunctions_F2(){}

/*******************************************************************
   Funktion: userfunctions_F3
   Zweck: TMCL-Befehl UF3.
********************************************************************/
void userfunctions_F3(){}

/*******************************************************************
   Funktion: userfunctions_F4
   Zweck: TMCL-Befehl UF4.
********************************************************************/
void userfunctions_F4(){}

/*******************************************************************
   Funktion: userfunctions_F5
   Zweck: TMCL-Befehl UF5.
********************************************************************/
void userfunctions_F5(){}

/*******************************************************************
   Funktion: userfunctions_F6
   Zweck: TMCL-Befehl UF6.
********************************************************************/
void userfunctions_F6(){}

/*******************************************************************
   Funktion: userfunctions_F7
   Zweck: TMCL-Befehl UF7.
********************************************************************/
void userfunctions_F7(){}
