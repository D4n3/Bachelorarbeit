/*
 * BLDC_Regulator.h
 *
 *  Created on: 09.03.2011
 *      Author: ed
 */

#ifndef BLDC_REGULATOR_H_
#define BLDC_REGULATOR_H_

	#include "Functions.h"
	#include "PID.h"

	int bldc_regulator_getTargetCurrentFromVelocityPIDRegulator(TMotorConfig *motorConfig, TPIDControl *velocityPID, int targetSpeed, int actualSpeed);
	int bldc_regulator_getTargetSpeedFromPositionPIDRegulator(TMotorConfig *motorConfig, TPIDControl *positionPID, int targetPosition, int actualPosition, int actualSpeed);
	int bldc_regulator_getPWMFromCurrentPIDRegulator(TMotorConfig *motorConfig, TPIDControl *currentPID, int targetCurrent, int actualCurrent, int actualSpeed);

#endif /* BLDC_REGULATOR_H_ */
