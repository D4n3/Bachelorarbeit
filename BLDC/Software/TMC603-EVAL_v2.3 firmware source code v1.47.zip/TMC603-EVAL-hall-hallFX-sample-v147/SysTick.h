/****************************************************
  Projekt: TMCM-STM

  Modul:   SysTick.h
           Systick-Timer f�r 1ms-Takt

  Datum:   17.8.2009 OK (updated by ed)
*****************************************************/

#ifndef SYSTICK_H_
#define SYSTICK_H_

	#include "TMCM-STM.h"

	void systick_stm_init();
	UINT systick_stm_getTimer();

#endif
