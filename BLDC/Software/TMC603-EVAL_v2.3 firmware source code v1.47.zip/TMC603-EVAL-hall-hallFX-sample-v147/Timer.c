/*
 * Timer.c
 *
 *  Created on: 21.06.2011
 *      Author: ed (based on work of OK)
 */
#include "Timer.h"

/* configure Timer 1 (TIM1) for motor pwm */
void timer_initPWMTimer(UCHAR commutationMode)
{
	TIM_TimeBaseInitTypeDef TIM_Base;
	TIM_OCInitTypeDef       TIM_Oc;
	TIM_BDTRInitTypeDef     TIM_Bdtr;

	//Clock f�r Timer 1 einschalten
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1|RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB, ENABLE);

	//Kommutierungsinterrupt im NVIC eintragen
	NVIC_InitTypeDef NVICInit;
	NVICInit.NVIC_IRQChannel = TIM1_TRG_COM_IRQChannel;
	NVICInit.NVIC_IRQChannelPreemptionPriority = TIM1_PRE_EMPTION_PRIORITY;
	NVICInit.NVIC_IRQChannelSubPriority = TIM1_SUB_PRIORITY;
	NVICInit.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVICInit);

	//�berlauf-Interrupt (Update-Interrupt) im NVIC eintragen
	NVICInit.NVIC_IRQChannel = TIM1_UP_IRQChannel;
	NVICInit.NVIC_IRQChannelPreemptionPriority = TIM1_PRE_EMPTION_PRIORITY;
	NVICInit.NVIC_IRQChannelSubPriority = TIM1_SUB_PRIORITY;
	NVICInit.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVICInit);

	//Pins f�r PWM konfigurieren
	GPIO_InitTypeDef GPIOInit;
	// (PA8/PA9/PA10 = High Side, PB13/PB14/PB15 = Low Side)
	GPIOInit.GPIO_Pin   = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;
	GPIOInit.GPIO_Mode  = GPIO_Mode_AF_PP;
	GPIOInit.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIOInit);

	GPIOInit.GPIO_Pin   = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_Init(GPIOB, &GPIOInit);

	//Deinitializes the TIM1 peripheral registers to their default reset values
	TIM_DeInit(TIM1);

	switch(commutationMode)
	{
		case COMM_MODE_BLOCK_HALL:
		case COMM_MODE_BLOCK_HALLFX:
		case COMM_MODE_BLOCK_CONTROLLED:
			//Timer 1 f�r Kommutierung konfigurieren
			//Basis-Frequenz und Modus
			//(TIM1CLK = SYSCLK = 72MHz) => MAX_PWM_VALUE=3600 => f_PWM=20kHz (unsymmetrische PWM)
			TIM_Base.TIM_Period = MAX_PWM_VALUE;
			TIM_Base.TIM_Prescaler = 0;
			TIM_Base.TIM_ClockDivision = TIM_CKD_DIV1;
#if DEVICE==TMC603EVAL
			TIM_Base.TIM_CounterMode = TIM_CounterMode_Up;
			TIM_Base.TIM_RepetitionCounter = 0;
#else
			TIM_Base.TIM_CounterMode = TIM_CounterMode_CenterAligned2;
			TIM_Base.TIM_RepetitionCounter = 1;
#endif
			TIM_TimeBaseInit(TIM1, &TIM_Base);

			//Einstellungen f�r Kanal 1, 2 und 3 (alle gleich)
			TIM_Oc.TIM_OCMode       = TIM_OCMode_Timing;
			TIM_Oc.TIM_OutputState  = TIM_OutputState_Enable;
			TIM_Oc.TIM_OutputNState = TIM_OutputNState_Enable;
			TIM_Oc.TIM_Pulse        = 0;
			TIM_Oc.TIM_OCPolarity   = TIM_OCPolarity_High;
			TIM_Oc.TIM_OCNPolarity  = TIM_OCNPolarity_High;
			TIM_Oc.TIM_OCIdleState  = TIM_OCIdleState_Set;
			TIM_Oc.TIM_OCNIdleState = TIM_OCNIdleState_Set;
			TIM_OC1Init(TIM1, &TIM_Oc);
			TIM_OC2Init(TIM1, &TIM_Oc);
			TIM_OC3Init(TIM1, &TIM_Oc);

			//Einstellungen f�r Totzeit und automatische Ausgabe der PWMs
			TIM_Bdtr.TIM_OSSRState       = TIM_OSSRState_Enable;
			TIM_Bdtr.TIM_OSSIState       = TIM_OSSIState_Enable;
			TIM_Bdtr.TIM_LOCKLevel       = TIM_LOCKLevel_OFF;
			TIM_Bdtr.TIM_DeadTime        = 1;
			TIM_Bdtr.TIM_Break           = TIM_Break_Disable;
			TIM_Bdtr.TIM_BreakPolarity   = TIM_BreakPolarity_High;
			TIM_Bdtr.TIM_AutomaticOutput = TIM_AutomaticOutput_Enable;
			TIM_BDTRConfig(TIM1, &TIM_Bdtr);

			//Interrupt f�r Kommutierungs-Event aktivieren
			TIM_ITConfig(TIM1, TIM_IT_COM, ENABLE);
			TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);
			break;
	}

	//Shadow-Register f�r Kommutierung aktivieren
	//Es k�nnen nun jeweils die Einstellungen f�r den n�chsten Kommutierungsschritt
	//vorgegeben und per Kommutierungs-Event �bernommen werden.
	TIM_CCPreloadControl(TIM1, ENABLE);

	//TIM1 aktivieren
	TIM_Cmd(TIM1, ENABLE);

	//PWM-Ausg�nge aktivieren
	TIM_CtrlPWMOutputs(TIM1, ENABLE);
}

/* configure Timer 2 or 4 (TIM2 or TIM4) to handle hall events */
void timer_initHallTimer(UCHAR commutationMode)
{
#if HALL_IRQ_HANDLER!=NOT_USED
	TIM_TimeBaseInitTypeDef TIM_HALLTimeBaseInitStructure;
	TIM_ICInitTypeDef       TIM_HALLICInitStructure;
	NVIC_InitTypeDef        NVIC_InitHALLStructure;
	GPIO_InitTypeDef        GPIO_InitStructure;
	TIM_OCInitTypeDef       TIM_OCInitStructure;
#endif

	switch(commutationMode)
	{
		case COMM_MODE_BLOCK_HALL:
#if HALL_IRQ_HANDLER==NOT_USED
			/* Hall IRQ Handler wird nicht verwendet */

#elif HALL_IRQ_HANDLER==TIM2_IRQ_HANDLER
			//Clock f�r TIM2 einschalten
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

			//Clock f�r GPIOA einschalten
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

			//PA0, PA1 und PA2 als Hall-Sensor-Eing�nge konfigurieren
			GPIO_StructInit(&GPIO_InitStructure);
			GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
			GPIO_Init(GPIOA, &GPIO_InitStructure);

			//Timer konfigurieren (Clear on Capture Mode)
			TIM_DeInit(TIM2);

			TIM_TimeBaseStructInit(&TIM_HALLTimeBaseInitStructure);
			TIM_HALLTimeBaseInitStructure.TIM_Period = U16_MAX;   //16-Bit-Z�hler (gesamter Bereich)
			TIM_HALLTimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;  //Clk/1
			TIM_TimeBaseInit(TIM2,&TIM_HALLTimeBaseInitStructure);

			//Digitales Filter f�r die Hall-Signale aktivieren
			TIM_ICStructInit(&TIM_HALLICInitStructure);
			TIM_HALLICInitStructure.TIM_Channel = TIM_Channel_1;
			TIM_HALLICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
			TIM_HALLICInitStructure.TIM_ICFilter = HALL_INPUT_FILTER;
			TIM_HALLICInitStructure.TIM_ICSelection = TIM_ICSelection_TRC;

			TIM_ICInit(TIM2,&TIM_HALLICInitStructure);

			// Force the TIM2 prescaler with immediate access (no need of an update event)
			TIM_PrescalerConfig(TIM2, (u16) HALL_MAX_RATIO, TIM_PSCReloadMode_Immediate);
			TIM_InternalClockConfig(TIM2);

			//XOR f�r Hall 1, 2 und 3 aktivieren
			TIM_SelectHallSensor(TIM2, ENABLE);
			//TIM_SelectInputTrigger(TIM2, TIM_TS_TI1FP1);  //dies w�rde ein Capture-Event nur bei steigender XOR-Flanke aktivieren (=> nur bei jeder zweiter �nderung)
			TIM_SelectInputTrigger(TIM2, TIM_TS_TI1F_ED);   //Capture-Event bei jeder �nderung (beide Flanken des XOR-Signals)
			TIM_SelectSlaveMode(TIM2,TIM_SlaveMode_Reset);  //das Event f�hrt zum Nullsetzen des Timers

			TIM_UpdateRequestConfig(TIM2, TIM_UpdateSource_Regular);  //Update-Event bei �berlauf des Z�hlers (f�r Hall-Time-Out)

			//TIM 2 Channel 2: PWM 2 Mode f�r zus�tzliche Verz�gerung bei hardwareunterst�tzter Kommutierung
			TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
			TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
			TIM_OCInitStructure.TIM_Pulse = 400;
			TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
			TIM_OC2Init(TIM2, &TIM_OCInitStructure);
			TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
			TIM_ARRPreloadConfig(TIM2, ENABLE);

			//Interrupt Handler f�r TIM2 aktivieren
			NVIC_InitHALLStructure.NVIC_IRQChannel = TIM2_IRQChannel;
			NVIC_InitHALLStructure.NVIC_IRQChannelPreemptionPriority =  TIM2_PRE_EMPTION_PRIORITY;
			NVIC_InitHALLStructure.NVIC_IRQChannelSubPriority = TIM2_SUB_PRIORITY;
			NVIC_InitHALLStructure.NVIC_IRQChannelCmd = ENABLE;
			NVIC_Init(&NVIC_InitHALLStructure);

			//Alle Interruptflags l�schen
			TIM_ClearFlag(TIM2, TIM_FLAG_Update + TIM_FLAG_CC1 + TIM_FLAG_CC2 + \
					TIM_FLAG_CC3 + TIM_FLAG_CC4 + TIM_FLAG_Trigger + TIM_FLAG_CC1OF + \
                    TIM_FLAG_CC2OF + TIM_FLAG_CC3OF + TIM_FLAG_CC4OF);

			//Interrupts f�r Capture Kanal 1 und f�r �berlauf einschalten
			TIM_ITConfig(TIM2, TIM_IT_CC1, ENABLE);
			TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

			//Trigger ausgang selektieren (wird dann mit TIM1 verbunden)
			TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_OC2Ref);
			//TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_Reset);

			//Timer 2 auf Null setzen und starten
			TIM_SetCounter(TIM2, 0);
			TIM_Cmd(TIM2, ENABLE);

#elif HALL_IRQ_HANDLER==TIM4_IRQ_HANDLER
			//Clock f�r TIM4 einschalten
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

			//Clock f�r GPIOB einschalten
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

			//PB6, PB7 und PB8 als Hall-Sensor-Eing�nge konfigurieren
			GPIO_StructInit(&GPIO_InitStructure);
			GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_7 | GPIO_Pin_6;
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
			GPIO_Init(GPIOB, &GPIO_InitStructure);

			//Timer konfigurieren (Clear on Capture Mode)
			TIM_DeInit(TIM4);

			TIM_TimeBaseStructInit(&TIM_HALLTimeBaseInitStructure);
			TIM_HALLTimeBaseInitStructure.TIM_Period = U16_MAX;   //16-Bit-Z�hler (gesamter Bereich)
			TIM_HALLTimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;  //Clk/1
			TIM_TimeBaseInit(TIM4,&TIM_HALLTimeBaseInitStructure);

			//Digitales Filter f�r die Hall-Signale aktivieren
			TIM_ICStructInit(&TIM_HALLICInitStructure);
			TIM_HALLICInitStructure.TIM_Channel = TIM_Channel_1;
			TIM_HALLICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
			TIM_HALLICInitStructure.TIM_ICFilter = HALL_INPUT_FILTER;
			TIM_HALLICInitStructure.TIM_ICSelection = TIM_ICSelection_TRC;

			TIM_ICInit(TIM4,&TIM_HALLICInitStructure);

			// Force the TIM4 prescaler with immediate access (no need of an update event)
			TIM_PrescalerConfig(TIM4, (u16) HALL_MAX_RATIO, TIM_PSCReloadMode_Immediate);
			TIM_InternalClockConfig(TIM4);

			// XOR f�r Hall 1, 2 und 3 aktivieren
			TIM_SelectHallSensor(TIM4, ENABLE);
			//TIM_SelectInputTrigger(TIM4, TIM_TS_TI1FP1);  //dies w�rde ein Capture-Event nur bei steigender XOR-Flanke aktivieren (=> nur bei jeder zweiter �nderung)
			TIM_SelectInputTrigger(TIM4, TIM_TS_TI1F_ED);   //Capture-Event bei jeder �nderung (beide Flanken des XOR-Signals)
			TIM_SelectSlaveMode(TIM4,TIM_SlaveMode_Reset);  //das Event f�hrt zum Nullsetzen des Timers

			TIM_UpdateRequestConfig(TIM4, TIM_UpdateSource_Regular);  //Update-Event bei �berlauf des Z�hlers (f�r Hall-Time-Out)

			//TIM 4 Channel 2: PWM 2 Mode f�r zus�tzliche Verz�gerung bei hardwareunterst�tzter Kommutierung
			TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
			TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
			TIM_OCInitStructure.TIM_Pulse = 400;
			TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
			TIM_OC2Init(TIM4, &TIM_OCInitStructure);
			TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);
			TIM_ARRPreloadConfig(TIM4, ENABLE);

			//Interrupt Handler f�r TIM4 aktivieren
			NVIC_InitHALLStructure.NVIC_IRQChannel = TIM4_IRQChannel;
			NVIC_InitHALLStructure.NVIC_IRQChannelPreemptionPriority =  TIM4_PRE_EMPTION_PRIORITY;
			NVIC_InitHALLStructure.NVIC_IRQChannelSubPriority = TIM4_SUB_PRIORITY;
			NVIC_InitHALLStructure.NVIC_IRQChannelCmd = ENABLE;
			NVIC_Init(&NVIC_InitHALLStructure);

			//Alle Interruptflags l�schen
			TIM_ClearFlag(TIM4, TIM_FLAG_Update + TIM_FLAG_CC1 + TIM_FLAG_CC2 + \
                    TIM_FLAG_CC3 + TIM_FLAG_CC4 + TIM_FLAG_Trigger + TIM_FLAG_CC1OF + \
                    TIM_FLAG_CC2OF + TIM_FLAG_CC3OF + TIM_FLAG_CC4OF);

			//Interrupts f�r Capture Kanal 1 und f�r �berlauf einschalten
			TIM_ITConfig(TIM4, TIM_IT_CC1, ENABLE);
			TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);

			//Triggerausgang selektieren (wird dann mit TIM1 verbunden)
			TIM_SelectOutputTrigger(TIM4, TIM_TRGOSource_OC2Ref);
			//TIM_SelectOutputTrigger(TIM4, TIM_TRGOSource_Reset);

			//Timer 4 auf Null setzen und starten
			TIM_SetCounter(TIM4, 0);
			TIM_Cmd(TIM4, ENABLE);
#else
	#error "Routine not available!"
#endif
			break;
		default:
			break;
	}
}

/* configure Timer 2 or 4 (TIM2 or TIM4) to handle hallFX events */
void timer_initHallFXTimer(UCHAR commutationMode)
{
#if HALLFX_IRQ_HANDLER!=NOT_USED
  TIM_TimeBaseInitTypeDef TIM_HALLTimeBaseInitStructure;
  TIM_ICInitTypeDef       TIM_HALLICInitStructure;
  NVIC_InitTypeDef        NVIC_InitHALLStructure;
  GPIO_InitTypeDef        GPIO_InitStructure;
  TIM_OCInitTypeDef       TIM_OCInitStructure;
#endif

  switch(commutationMode)
  {
  case COMM_MODE_BLOCK_HALLFX:
  case COMM_MODE_BLOCK_CONTROLLED:

    #if HALLFX_IRQ_HANDLER==NOT_USED
      /* HallFX IRQ Handler wird nicht verwendet */

    #elif HALLFX_IRQ_HANDLER==TIM2_IRQ_HANDLER
      //Clock f�r TIM2 einschalten
      RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

      //Clock f�r GPIOA einschalten
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

      //PA0, PA1 und PA2 als Hall-Sensor-Eing�nge konfigurieren
      GPIO_StructInit(&GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
      GPIO_Init(GPIOA, &GPIO_InitStructure);

      //Timer konfigurieren (Clear on Capture Mode)
      TIM_DeInit(TIM2);

      TIM_TimeBaseStructInit(&TIM_HALLTimeBaseInitStructure);
      TIM_HALLTimeBaseInitStructure.TIM_Period = U16_MAX;   //16-Bit-Z�hler (gesamter Bereich)
      TIM_HALLTimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;  //Clk/1
      TIM_TimeBaseInit(TIM2,&TIM_HALLTimeBaseInitStructure);

      //Digitales Filter f�r die Hall-Signale aktivieren
      TIM_ICStructInit(&TIM_HALLICInitStructure);
      TIM_HALLICInitStructure.TIM_Channel = TIM_Channel_1;
      TIM_HALLICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
      TIM_HALLICInitStructure.TIM_ICFilter = HALL_INPUT_FILTER;
      TIM_HALLICInitStructure.TIM_ICSelection = TIM_ICSelection_TRC;

      TIM_ICInit(TIM2,&TIM_HALLICInitStructure);

      // Force the TIM2 prescaler with immediate access (no need of an update event)
      TIM_PrescalerConfig(TIM2, (u16) HALL_MAX_RATIO, TIM_PSCReloadMode_Immediate);
      TIM_InternalClockConfig(TIM2);

      //XOR f�r Hall 1, 2 und 3 aktivieren
      TIM_SelectHallSensor(TIM2, ENABLE);
      //TIM_SelectInputTrigger(TIM2, TIM_TS_TI1FP1);  //dies w�rde ein Capture-Event nur bei steigender XOR-Flanke aktivieren (=> nur bei jeder zweiter �nderung)
      TIM_SelectInputTrigger(TIM2, TIM_TS_TI1F_ED);   //Capture-Event bei jeder �nderung (beide Flanken des XOR-Signals)

      if (commutationMode == COMM_MODE_BLOCK_HALLFX)
        TIM_SelectSlaveMode(TIM2,TIM_SlaveMode_Reset);  //das Event f�hrt zum Nullsetzen des Timers
      else
        TIM_SelectSlaveMode(TIM2,0);  //Slave Mode disabled

      TIM_UpdateRequestConfig(TIM2, TIM_UpdateSource_Regular);  //Update-Event bei �berlauf des Z�hlers (f�r Hall-Time-Out)

      //TIM 2 Channel 2: PWM 2 Mode f�r zus�tzliche Verz�gerung bei hardwareunterst�tzter Kommutierung
      TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
      TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
      TIM_OCInitStructure.TIM_Pulse = 400;
      TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
      TIM_OC2Init(TIM2, &TIM_OCInitStructure);
      TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);
      TIM_ARRPreloadConfig(TIM2, ENABLE);

      //Interrupt Handler f�r TIM2 aktivieren
      NVIC_InitHALLStructure.NVIC_IRQChannel = TIM2_IRQChannel;
      NVIC_InitHALLStructure.NVIC_IRQChannelPreemptionPriority =  TIM2_PRE_EMPTION_PRIORITY;
      NVIC_InitHALLStructure.NVIC_IRQChannelSubPriority = TIM2_SUB_PRIORITY;
      NVIC_InitHALLStructure.NVIC_IRQChannelCmd = ENABLE;
      NVIC_Init(&NVIC_InitHALLStructure);

      //Alle Interruptflags l�schen
      TIM_ClearFlag(TIM2, TIM_FLAG_Update + TIM_FLAG_CC1 + TIM_FLAG_CC2 + \
                    TIM_FLAG_CC3 + TIM_FLAG_CC4 + TIM_FLAG_Trigger + TIM_FLAG_CC1OF + \
                    TIM_FLAG_CC2OF + TIM_FLAG_CC3OF + TIM_FLAG_CC4OF);

      //Interrupts f�r Capture Kanal 1 und f�r �berlauf einschalten
      TIM_ITConfig(TIM2, TIM_IT_CC1, ENABLE);
      TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

      //Trigger ausgang selektieren (wird dann mit TIM1 verbunden)
      TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_OC2Ref);
      //TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_Reset);

      //Timer 2 auf Null setzen und starten
      TIM_SetCounter(TIM2, 0);
      TIM_Cmd(TIM2, ENABLE);

    #elif HALLFX_IRQ_HANDLER==TIM4_IRQ_HANDLER
      //Clock f�r TIM4 einschalten
      RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

      //Clock f�r GPIOB einschalten
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

      //PB6, PB7 und PB8 als Hall-Sensor-Eing�nge konfigurieren
      GPIO_StructInit(&GPIO_InitStructure);
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_7 | GPIO_Pin_6;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
      //GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
      GPIO_Init(GPIOB, &GPIO_InitStructure);

      //Timer konfigurieren (Clear on Capture Mode)
      TIM_DeInit(TIM4);

      TIM_TimeBaseStructInit(&TIM_HALLTimeBaseInitStructure);
      TIM_HALLTimeBaseInitStructure.TIM_Period = U16_MAX;   //16-Bit-Z�hler (gesamter Bereich)
      TIM_HALLTimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;  //Clk/1
      TIM_TimeBaseInit(TIM4,&TIM_HALLTimeBaseInitStructure);

      //Digitales Filter f�r die Hall-Signale aktivieren
      TIM_ICStructInit(&TIM_HALLICInitStructure);
      TIM_HALLICInitStructure.TIM_Channel = TIM_Channel_1;
      TIM_HALLICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
      TIM_HALLICInitStructure.TIM_ICFilter = HALL_INPUT_FILTER;
      TIM_HALLICInitStructure.TIM_ICSelection = TIM_ICSelection_TRC;

      TIM_ICInit(TIM4,&TIM_HALLICInitStructure);

      // Force the TIM4 prescaler with immediate access (no need of an update event)
      TIM_PrescalerConfig(TIM4, (u16) HALL_MAX_RATIO, TIM_PSCReloadMode_Immediate);
      TIM_InternalClockConfig(TIM4);

      //XOR f�r Hall 1, 2 und 3 aktivieren
      TIM_SelectHallSensor(TIM4, ENABLE);
      //TIM_SelectInputTrigger(TIM4, TIM_TS_TI1FP1);  //dies w�rde ein Capture-Event nur bei steigender XOR-Flanke aktivieren (=> nur bei jeder zweiter �nderung)
      TIM_SelectInputTrigger(TIM4, TIM_TS_TI1F_ED);   //Capture-Event bei jeder �nderung (beide Flanken des XOR-Signals)

      if (commutationMode == COMM_MODE_BLOCK_HALLFX)
        TIM_SelectSlaveMode(TIM4,TIM_SlaveMode_Reset);  //das Event f�hrt zum Nullsetzen des Timers
      else
        TIM_SelectSlaveMode(TIM4,0);  //Slave Mode disabled

      TIM_UpdateRequestConfig(TIM4, TIM_UpdateSource_Regular);  //Update-Event bei �berlauf des Z�hlers (f�r Hall-Time-Out)

      //TIM 4 Channel 2: PWM 2 Mode f�r zus�tzliche Verz�gerung bei hardwareunterst�tzter Kommutierung
      TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
      TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
      TIM_OCInitStructure.TIM_Pulse = 400;
      TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
      TIM_OC2Init(TIM4, &TIM_OCInitStructure);
      TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);
      TIM_ARRPreloadConfig(TIM4, ENABLE);

      //Interrupt Handler f�r TIM4 aktivieren
      NVIC_InitHALLStructure.NVIC_IRQChannel = TIM4_IRQChannel;
      NVIC_InitHALLStructure.NVIC_IRQChannelPreemptionPriority =  TIM4_PRE_EMPTION_PRIORITY;
      NVIC_InitHALLStructure.NVIC_IRQChannelSubPriority = TIM4_SUB_PRIORITY;
      NVIC_InitHALLStructure.NVIC_IRQChannelCmd = ENABLE;
      NVIC_Init(&NVIC_InitHALLStructure);

      //Alle Interruptflags l�schen
      TIM_ClearFlag(TIM4, TIM_FLAG_Update + TIM_FLAG_CC1 + TIM_FLAG_CC2 + \
                    TIM_FLAG_CC3 + TIM_FLAG_CC4 + TIM_FLAG_Trigger + TIM_FLAG_CC1OF + \
                    TIM_FLAG_CC2OF + TIM_FLAG_CC3OF + TIM_FLAG_CC4OF);

      //Interrupts f�r Capture Kanal 1 und f�r �berlauf einschalten
      TIM_ITConfig(TIM4, TIM_IT_CC1, ENABLE);
      TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);

      //Trigger ausgang selektieren (wird dann mit TIM1 verbunden)
      TIM_SelectOutputTrigger(TIM4, TIM_TRGOSource_OC2Ref);
      //TIM_SelectOutputTrigger(TIM4, TIM_TRGOSource_Reset);

      //Timer 4 auf Null setzen und starten
      TIM_SetCounter(TIM4, 0);
      TIM_Cmd(TIM4, ENABLE);

    #else
      #error "Routine not available!"
    #endif

    break;

  default:
    break;
  }
}

/* configure Timer 4 for the SCCLK-beat (Switched-Capacitor-Clock of the TMC603) */
void timer_initSCClockTimer(UCHAR commutationMode)
{
#if SCCLK_IRQ_HANDLER!=NOT_USED
	GPIO_InitTypeDef        GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef       TIM_OCInitStructure;
#endif

	switch(commutationMode)
	{
		case COMM_MODE_BLOCK_HALLFX:
		case COMM_MODE_BLOCK_CONTROLLED:
#if SCCLK_IRQ_HANDLER == NOT_USED
			/* SCCLK IRQ Handler wird nicht verwendet */
#elif SCCLK_IRQ_HANDLER == TIM2_IRQ_HANDLER
			//Clock f�r TIM2 einschalten
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

			//Clock f�r GPIOA einschalten
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

			//Pin 3 f�r Takt-Ausgang konfigurieren
			GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_3;
			GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
			GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_Init(GPIOA, &GPIO_InitStructure);

			TIM_DeInit(TIM2);

			//Timer 2 f�r  konfigurieren
			//Basis-Frequenz und Modus
			TIM_TimeBaseInitStructure.TIM_Period = SCCLK_PWM_VALUE;
			TIM_TimeBaseInitStructure.TIM_Prescaler = 0;
			TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
			TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
			TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
			TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

			//Einstellungen f�r Kanal 4
			TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_Toggle;
			TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;
			TIM_OCInitStructure.TIM_Pulse        = 0;
			TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_High;
			TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Reset;
			TIM_OC4Init(TIM2, &TIM_OCInitStructure);

			//Compare Register f�r 50% PWM konfigurieren
			TIM_SetCompare4(TIM2, SCCLK_PWM_VALUE/2);

			//Shadow-Register f�r SCCLK-Takt aktivieren
			TIM_ARRPreloadConfig(TIM2, ENABLE);

			//TIM2 aktivieren
			TIM_Cmd(TIM2, ENABLE);

			//PWM-Ausg�nge aktivieren
			TIM_CtrlPWMOutputs(TIM2, ENABLE);

#elif SCCLK_IRQ_HANDLER == TIM4_IRQ_HANDLER
			//Clock f�r TIM4 einschalten
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

			//Clock f�r GPIOB einschalten
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

			//Pin 9 f�r Takt-Ausgang konfigurieren
			GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_9;
			GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
			GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_Init(GPIOB, &GPIO_InitStructure);

			TIM_DeInit(TIM4);

			//Timer 4 f�r  konfigurieren
			//Basis-Frequenz und Modus
			TIM_TimeBaseInitStructure.TIM_Period = SCCLK_PWM_VALUE;
			TIM_TimeBaseInitStructure.TIM_Prescaler = 0;
			TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
			TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
			TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
			TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);

			//Einstellungen f�r Kanal 4
			TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_Toggle;
			TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable;
			TIM_OCInitStructure.TIM_Pulse        = 0;
			TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_High;
			TIM_OCInitStructure.TIM_OCIdleState  = TIM_OCIdleState_Reset;
			TIM_OC4Init(TIM4, &TIM_OCInitStructure);

			//Compare Register f�r 50% PWM konfigurieren
			TIM_SetCompare4(TIM4, SCCLK_PWM_VALUE/2);

			//Shadow-Register f�r SCCLK-Takt aktivieren
			TIM_ARRPreloadConfig(TIM4, ENABLE);

			//TIM4 aktivieren
			TIM_Cmd(TIM4, ENABLE);

			//PWM-Ausg�nge aktivieren
			TIM_CtrlPWMOutputs(TIM4, ENABLE);
#else
	#error "Routine not available!"
#endif
			break;
		default:
#if SCCLK_IRQ_HANDLER == NOT_USED
			/* SCCLK IRQ Handler wird nicht verwendet */
#elif SCCLK_IRQ_HANDLER == TIM2_IRQ_HANDLER
			if(commutationMode != COMM_MODE_BLOCK_HALL)
				TIM_DeInit(TIM2);

#elif SCCLK_IRQ_HANDLER == TIM4_IRQ_HANDLER
			if(commutationMode != COMM_MODE_BLOCK_HALL)
				TIM_DeInit(TIM4);
#else
	#error "Routine not available!"
#endif
			break;
	}
}
