/*
 * Timer.h
 *
 *  Created on: 21.06.2011
 *      Author: ed
 */

#ifndef TIMER_H_
#define TIMER_H_

	#include "../../TMCM-STM.h"

	#define TIM1_PRE_EMPTION_PRIORITY 0
	#define TIM1_SUB_PRIORITY 1

	#define TIM2_PRE_EMPTION_PRIORITY 2      //Priorit�t f�r Timer-Interrupt (TIM2)
	#define TIM2_SUB_PRIORITY 0

	#define TIM3_PRE_EMPTION_PRIORITY 2      //Priorit�t f�r Timer-Interrupt (TIM3)
	#define TIM3_SUB_PRIORITY 0

	#define TIM4_PRE_EMPTION_PRIORITY 2      //Priorit�t f�r Timer-Interrupt (TIM4)
	#define TIM4_SUB_PRIORITY 0

	#define SCCLK_PWM_VALUE 28               // period of the SCCLK (28 => 1.24MHz clock => 3kHz SC-Filter-bandwidth)

	void timer_initPWMTimer(UCHAR commutationMode);
	void timer_initHallTimer(UCHAR commutationMode);
	void timer_initHallFXTimer(UCHAR commutationMode);
	void timer_initSCClockTimer(UCHAR commutationMode);

#endif /* TIMER_H_ */
