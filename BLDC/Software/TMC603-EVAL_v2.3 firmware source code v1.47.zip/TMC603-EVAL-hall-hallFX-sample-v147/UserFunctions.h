/****************************************************
  Projekt: TMCM-STM

  Modul:   UserFunctions.h
           Kundenspezifische TMCL-Befehle

  Datum:   26.5.2010 OK
*****************************************************/

#ifndef USER_FUNCTIONS_H_
#define USER_FUNCTIONS_H_

	#include "TMCM-STM.h"
	#include "TMCL-STM.h"
	#include "SysTick.h"
	#include "BLDC-STM.h"

	void userfunctions_init();
	void userfunctions_Appl();
	void userfunctions_F0();
	void userfunctions_F1();
	void userfunctions_F2();
	void userfunctions_F3();
	void userfunctions_F4();
	void userfunctions_F5();
	void userfunctions_F6();
	void userfunctions_F7();

#endif
