/*
 * PID.c
 *
 *  Created on: 15.02.2011
 *      Author: ed
 */

#include "PID.h"

/* reset PID regulator */
void pid_resetPIDControl(TPIDControl *pidControl)
{
	pidControl->error = 0;
	pidControl->errorSum = 0;
	pidControl->errorOld = 0;
	pidControl->result = 0;
}

/* control and switching between velocity parameter sets for revolution control */
void pid_checkParamSet(TPIDControl *pidControl, int speed, int switchSpeed, int pSet1, int iSet1, int dSet1, int iClippSet1, int pSet2, int iSet2, int dSet2, int iClippSet2)
{
	if(abs(speed) >= abs(switchSpeed))
	{
		pidControl->pParam = pSet2;
		pidControl->iParam = iSet2;
		pidControl->dParam = dSet2;
		pidControl->iClipping = iClippSet2;
	}else{
		pidControl->pParam = pSet1 + (float)((pSet2-pSet1)*abs(speed))/switchSpeed;
		pidControl->iParam = iSet1 + (float)((iSet2-iSet1)*abs(speed))/switchSpeed;
		pidControl->dParam = dSet1 + (float)((dSet2-dSet1)*abs(speed))/switchSpeed;
		pidControl->iClipping = iClippSet1 + ((iClippSet2-iClippSet1)*abs(speed))/switchSpeed;
	}
}

