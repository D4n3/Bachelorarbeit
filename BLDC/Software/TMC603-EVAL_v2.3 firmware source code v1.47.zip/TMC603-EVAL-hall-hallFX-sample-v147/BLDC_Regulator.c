/*
 * BLDC_Regulator.c
 *
 *  Created on: 09.03.2011
 *      Author: ed
 */

#include "BLDC_Regulator.h"

int bldc_regulator_getTargetSpeedFromPositionPIDRegulator(TMotorConfig *motorConfig, TPIDControl *positionPID, int targetPosition, int actualPosition, int actualSpeed)
{
	// update the resulting PID parameter set
	pid_checkParamSet(positionPID, actualSpeed, motorConfig->PIDPosSpeedThreshold,
			motorConfig->PIDPosSet1_PParam, motorConfig->PIDPosSet1_IParam, motorConfig->PIDPosSet1_DParam, motorConfig->PIDPosSet1_IClipping,
			motorConfig->PIDPosSet2_PParam, motorConfig->PIDPosSet2_IParam, motorConfig->PIDPosSet2_DParam, motorConfig->PIDPosSet2_IClipping);

	int pDivisor = 256;
	int iDivisor = 65536;
	int dDivisor = 256;

	// limit iClipping to 1000
	int iClipping = functions_limitIntBetweenMinAndMax(positionPID->iClipping, 0, 1000);

	// compute max possible errorSum to reach the max positioning speed to (iClipping/10)%
	int maxIPart = (motorConfig->MaxPositioningSpeed * iClipping)/1000;
	int maxErrorSum = (positionPID->iParam == 0) ? 0 : (maxIPart * iDivisor)/positionPID->iParam;

	positionPID->error = targetPosition-actualPosition;
	// limit the error in case of high position differences
	// to prevent overruns in the following calculations
	positionPID->error = functions_limitIntBetweenMinAndMax(positionPID->error, -65535, 65535);

	positionPID->errorSum += positionPID->error;
	positionPID->errorSum = functions_limitIntBetweenMinAndMax(positionPID->errorSum, -maxErrorSum, maxErrorSum);

	int pValue = (positionPID->pParam*positionPID->error)/pDivisor;
	int iValue = (positionPID->iParam*positionPID->errorSum)/iDivisor;
	int dValue = (positionPID->dParam*(positionPID->error-positionPID->errorOld))/dDivisor;
	positionPID->errorOld = positionPID->error;
	positionPID->result = pValue + iValue + dValue;

	// limit the result to the max allowed speed
	return functions_limitIntBetweenMinAndMax(positionPID->result, -motorConfig->MaxPositioningSpeed, motorConfig->MaxPositioningSpeed);
}

int bldc_regulator_getTargetCurrentFromVelocityPIDRegulator(TMotorConfig *motorConfig, TPIDControl *velocityPID, int targetSpeed, int actualSpeed)
{
	// update the resulting PID parameter set
	pid_checkParamSet(velocityPID, actualSpeed, motorConfig->PIDVelSpeedThreshold,
			motorConfig->PIDVelSet1_PParam, motorConfig->PIDVelSet1_IParam, motorConfig->PIDVelSet1_DParam, motorConfig->PIDVelSet1_IClipping,
			motorConfig->PIDVelSet2_PParam, motorConfig->PIDVelSet2_IParam, motorConfig->PIDVelSet2_DParam, motorConfig->PIDVelSet2_IClipping);

	// limit the target speed
	targetSpeed = functions_limitIntBetweenMinAndMax(targetSpeed, -motorConfig[0].MaxPositioningSpeed, motorConfig[0].MaxPositioningSpeed);

	int pDivisor = 256;
	int iDivisor = 65536;
	int dDivisor = 256;

	// limit iClipping to 1000 (100.0%)
	int iClipping = functions_limitIntBetweenMinAndMax(velocityPID->iClipping, 0, 1000);

	// compute max possible errorSum to reach the max current to (iClipping/10)%
	int maxIPart = (motorConfig->MaximumCurrent * iClipping) / 1000;
	int maxErrorSum = (velocityPID->iParam == 0) ? 0: (maxIPart * iDivisor) / velocityPID->iParam;

	velocityPID->error = targetSpeed-actualSpeed;
	// limit the error in case of high velocity differences
	// to prevent overruns in the following calculations
	velocityPID->error = functions_limitIntBetweenMinAndMax(velocityPID->error, -65535, 65535);

	velocityPID->errorSum += velocityPID->error;
	velocityPID->errorSum = functions_limitIntBetweenMinAndMax(velocityPID->errorSum, -maxErrorSum, maxErrorSum);

	int pPart = (velocityPID->pParam*velocityPID->error)/pDivisor;
	int iPart = (velocityPID->iParam*velocityPID->errorSum)/iDivisor;
	int dPart = (velocityPID->dParam*(velocityPID->error-velocityPID->errorOld))/dDivisor;
	velocityPID->errorOld = velocityPID->error;
	velocityPID->result = pPart + iPart + dPart;

	// limit the result to the max allowed current
	return functions_limitIntBetweenMinAndMax(velocityPID->result, -motorConfig->MaximumCurrent, motorConfig->MaximumCurrent);
}

int bldc_regulator_getPWMFromCurrentPIDRegulator(TMotorConfig *motorConfig, TPIDControl *currentPID, int targetCurrent, int actualCurrent, int actualSpeed/*, UCHAR actualMotorDirection*/)
{
	// update the resulting PID parameter set
	pid_checkParamSet(currentPID, actualSpeed, motorConfig->PIDCurSpeedThreshold,
			motorConfig->PIDCurSet1_PParam, motorConfig->PIDCurSet1_IParam, motorConfig->PIDCurSet1_DParam, motorConfig->PIDCurSet1_IClipping,
			motorConfig->PIDCurSet2_PParam, motorConfig->PIDCurSet2_IParam, motorConfig->PIDCurSet2_DParam, motorConfig->PIDCurSet2_IClipping);

	// limit the target current
	targetCurrent = functions_limitIntBetweenMinAndMax(targetCurrent, -motorConfig[0].MaximumCurrent, motorConfig[0].MaximumCurrent);

	int pDivisor = 256;
	int iDivisor = 262144; //4*65536;
	int dDivisor = 256;

	// limit iClipping to 1000 (100.0%)
	int iClipping = functions_limitIntBetweenMinAndMax(currentPID->iClipping, 0, 1000);

	// compute max possible errorSum to reach the max PWM to (iClipping/10)%
	int maxIPart = (motorConfig->PWMLimit * iClipping) / 1000;
	int maxErrorSum = (currentPID->iParam == 0) ? 0 : (maxIPart * iDivisor) / currentPID->iParam;

	currentPID->error = targetCurrent - actualCurrent;
	currentPID->errorSum += currentPID->error;
	currentPID->errorSum = functions_limitIntBetweenMinAndMax(currentPID->errorSum, -maxErrorSum, maxErrorSum);

	int pPart = (currentPID->pParam*currentPID->error)/pDivisor;
	int iPart = (currentPID->iParam*currentPID->errorSum)/iDivisor;
	int dPart = (currentPID->dParam*(currentPID->error-currentPID->errorOld))/dDivisor;
	currentPID->errorOld = currentPID->error;
	currentPID->result = pPart + iPart + dPart;

	// limit the result to the max allowed pwm
	return functions_limitIntBetweenMinAndMax(currentPID->result, -motorConfig->PWMLimit, motorConfig->PWMLimit);
}
