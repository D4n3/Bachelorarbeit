/*
 * Definitions.h
 *
 *  Created on: 19.05.2011
 *      Author: ed (based on work of ok)
 */

#ifndef DEFINITIONS_STM_H_
#define DEFINITIONS_STM_H_

	typedef unsigned char UCHAR;
  	typedef unsigned short USHORT;
  	typedef unsigned int UINT;
  	typedef signed long long INT64;
  	typedef unsigned long long UINT64;

  	typedef void (*PIrqFunction) (void);

	#define FALSE     0
	#define TRUE      1
	#define RIGHT_MOTOR_DIRECTION	  0
	#define LEFT_MOTOR_DIRECTION	  1
	#define READY     2
	#define UNDEFINED 255

	#define MIN(a,b) (a<b) ? (a) : (b)
	#define MAX(a,b) (a>b) ? (a) : (b)

	#define NOP() asm volatile ("nop")

	// timer IRQ handler
	#define NOT_USED            0
	#define TIM2_IRQ_HANDLER	2
	#define TIM3_IRQ_HANDLER    3
	#define TIM4_IRQ_HANDLER    4
	#define TIM5_IRQ_HANDLER    5

	// commutation modes
	#define COMM_MODE_BLOCK_HALL       	0
	#define COMM_MODE_BLOCK_HALLFX     	1
	#define COMM_MODE_BLOCK_CONTROLLED	4

	// PWM schemes for block commutation
	#define CHOP_MODE_HIGH_SIDE     	0
	#define CHOP_MODE_LOW_SIDE      	1
	#define CHOP_MODE_DUAL_SIDE     	2
	#define CHOP_MODE_HALLFX        	128
	#define CHOP_MODE_LOW_SIDE_ON   	129
	#define CHOP_MODE_FULL_BRAKE    	130
	#define CHOP_MODE_DUAL_SIDE_OFF 	131

	// HallFX states
	#define HALLFX_STATE_STOP        	0
	#define HALLFX_STATE_INITSTART   	1
	#define HALLFX_STATE_WAIT_FOR_CURRENT  2
	#define HALLFX_STATE_SETCURRENT  	3
	#define HALLFX_STATE_RAMP_SINUS  	4
	#define HALLFX_STATE_RAMP_BLOCK  	5
	#define HALLFX_STATE_WAIT        	6
	#define HALLFX_STATE_RUN         	7

	// encoder states
	#define INITENC_STATE_INITSTART  			1
	#define INITENC_STATE_SETCURRENT 			2
	#define INITENC_STATE_ROTATE     			3
	#define INITENC_STATE_WAIT       			4
	#define INITENC_STATE_READY      			5
	#define INITENC_STATE_WAIT_FOR_ROTATE 		6
	#define INITENC_STATE_ERROR		 			7
	#define INITENC_STATE_WAIT_FOR_VEL_UPDATED	8

	// hard stop flags
	#define STOP_FLAG_EMERGENCY_STOP 	1
	#define STOP_FLAG_FREE_RUNNING   	2

	// positioning flags
	#define POSITION_CLEAR_ON_NULL    	0x01
	#define POSITION_CLEAR_ON_SWITCH  	0x02
	#define POSITION_CLEAR_ONLY_ONCE  	0x04

	// error- and status flags
	#define OVERCURRENT             0x00000001
	#define UNDERVOLTAGE            0x00000002
	#define OVERVOLTAGE             0x00000004
	#define OVERTEMPERATURE         0x00000008

	#define MOTORHALTED             0x00000010
	#define HALLERROR               0x00000020
//	#define ENCODERERROR            0x00000040
//	#define INITSINECOMMERROR       0x00000080

	#define PWM_MODE			 	0x00000100
	#define VELOCITY_MODE			0x00000200
	#define POSITION_MODE           0x00000400
	#define TORQUE_MODE				0x00000800

	#define EMERGENCYSTOP           0x00001000
	#define FREERUNNING             0x00002000
	#define POSITION_END            0x00004000
	#define MODULE_INITIALIZED		0x00008000

	#define ETHERCAT_TIMEOUT		0x00010000
	#define IIT_EXCEEDED			0x00020000

	//ACHTUNG: Bei Datenstrukturen f�gt der Compiler F�llbytes ein, so da� int/UINT-Werte immer auf
	//4-Byte-Grenzen beginnen. Das ist besser als __attribute__((__packed__)) zu verwenden, da sonst
	//Zugriffe auf int/UINT-Werte zu hohem Overhead f�hren k�nnen!
	typedef struct   //F�r diese Struktur sind 64 Bytes im EEPROM reserviert!
	{                //Achtung, Compiler f�gt F�llbytes ein!
		UCHAR Baudrate;
		UCHAR SerialModuleAddress;
		UCHAR SerialHostAddress;
		UCHAR TelegramPauseTime;
		UCHAR ASCIIMode;
		UCHAR CANBitrate;
		UCHAR CANExtStdFlag;
		UINT  CANReceiveID;
		UINT  CANSendID;
		UINT  CANSecondaryID;
		UCHAR TMCLProtectionMode;
		UCHAR TMCLAutostartFlag;
		UCHAR ShutdownPinMode;
		UCHAR EEPROMLockFlag;
		UCHAR ZeroUserVariables;
		UINT SerialHeartbeat;
		UINT CANHeartbeat;
		UINT ethercatTimout;				// Time to trigger an EtherCat timeout
		UCHAR Reserve[25];  //Auff�llen auf 64 Bytes, dabei F�llbytes beachten
	} TModuleConfig;

	typedef struct    //F�r diese Struktur sind 128 Bytes im EEPROM reserviert!
	{                 //Achtung, Compiler f�gt F�llbytes ein!
		int MaxPositioningSpeed;
		int PWMLimit;
		UINT MaximumCurrent;
		int MVPTargetReachedVelocity;
		int PIDVelSpeedThreshold;
		int MVPTargetReachedDistance;
		int MotorHaltedVelocity;
		int Acceleration;
		int PIDPosSpeedThreshold;
		int PIDPosSet1_PParam;
		int PIDPosSet1_IParam;
		int PIDPosSet1_DParam;
		int PIDPosSet1_IClipping;
		UINT PIDRegulationDelay;
		UINT CurrentRegulationDelay;
		UINT PWMHysteresis;
		int PIDVelSet1_PParam;
		int PIDVelSet1_IParam;
		int PIDVelSet1_DParam;
		int PIDVelSet1_IClipping;
		UCHAR VelocityPIDControl;
		UCHAR CommutationMode;
		UCHAR StopSwitchEnable;
		UCHAR StopSwitchPolarity;
		UCHAR HallInvertFlag;
		UCHAR MotorPoles;
		UCHAR HardStopFlag;
		short InitSineSpeed;
		short CommutationOffsetCCW;
		short CommutationOffsetCW;
		short InitSineDelay;
		int MassInertiaConst;
		USHORT RdsOn;
		UCHAR InitSineMode;
		UCHAR OvervoltageProtection;
		UCHAR EncoderDirection;
		UCHAR BlockPwmScheme;
		int PIDCurSet1_PParam;
		int PIDCurSet1_IParam;
		int PIDCurSet1_DParam;
		int PIDCurSet1_IClipping;
		int PIDCurSet2_PParam;
		int PIDCurSet2_IParam;
		int PIDCurSet2_DParam;
		int PIDCurSet2_IClipping;
		int PIDCurSpeedThreshold;
		UINT StartCurrent;
		UINT EncoderSteps;
		UINT EncoderCommutationOffset;
		UCHAR EncoderFlags;
		UINT BEMFConst;
		UINT MotorCoilResistance;
		int PIDPosSet2_PParam;
		int PIDPosSet2_IParam;
		int PIDPosSet2_DParam;
		int PIDPosSet2_IClipping;
		int PIDVelSet2_PParam;
		int PIDVelSet2_IParam;
		int PIDVelSet2_DParam;
		int PIDVelSet2_IClipping;
		int SineCompensationFactor;
		UCHAR ExternalShunt;
		UCHAR PositioningFlags;
		unsigned int iitLimit;
		unsigned int thermalWindingTimeConstant;
		UCHAR iitExceededFlag;
		int hallFXSpeedThreshold;
		UCHAR Reserve[39];  //Auff�llen auf 256 Bytes, dabei F�llbytes beachten
	} TMotorConfig;

#endif /* DEFINITIONS_STM_H_ */
