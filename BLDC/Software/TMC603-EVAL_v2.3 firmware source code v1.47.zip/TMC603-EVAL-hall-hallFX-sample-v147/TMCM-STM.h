/****************************************************
  Projekt: TMCM-STM

  Modul:   TMCM-STM.h
           Allgemeine Definitionen

  Datum:   25.5.2009 OK / ed
*****************************************************/

#ifndef TMCM_STM_H_
#define TMCM_STM_H_

	#include "stm32f10x_lib.h"
	#include "Bits.h"
	#include "Definitions.h"
	#include "Functions.h"
	#include "modules/SelectModule.h"

	#define SW_VERSION_HIGH 1
	#define SW_VERSION_LOW  47

	// constants for the EEPROM
	#define EEPROM_MAGIC 0x39	// 147
	#define ADDR_MODULE_CONFIG 		0
	#define ADDR_MOTOR_CONFIG 		64
	#define ADDR_TMCL_USER_VARS 	1818
	#define ADDR_SECURITY_CODE 		2043
	#define ADDR_EEPROM_MAGIC 		2047
	#define ADDR_TMCL_PROG 			2048     //Beginn des Bereiches f�r TMCL-Programme im EEPROM
	#define ADDR_HOUR_METER_MINUTES 1810
	#define ADDR_IIT_MONITOR		1814

	#define SIZE_MODULE_CONFIG 64
	#define SIZE_MOTOR_CONFIG 256    //max. zwei Motoren pro Prozessor (also 512 Bytes, n�chste freie Adresse also 577)
	#define SIZE_TMCL_USER_VARS 56*4

	#define HALL_MAX_RATIO 40		//niedrigste erwartete Hall-Frequenz (40 => 20Hz)


#if DEVICE==TMC603EVAL

	/* device configuration for TMCM-603eval */
	#include "modules/TMCM-603eval.h"

#elif DEVICE==TMCM603EVAL_V2_3

	/* device configuration for TMCM-603eval v2.3 */
	#include "modules/TMCM-603eval_v2.3.h"

#else
	/* Device not found */
	#error "Device not defined!"
#endif

#endif
