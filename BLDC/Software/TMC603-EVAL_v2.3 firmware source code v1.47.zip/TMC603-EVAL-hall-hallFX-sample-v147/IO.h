/****************************************************
  Projekt: TMCM-STM

  Modul:   IO.h
           I/O-Funktionen

  Datum:   26.5.2009 OK (reworked by ed)
*****************************************************/

#ifndef IO_H_
#define IO_H_

	#include "TMCM-STM.h"
	#include "Globals-STM.h"
	#include "ADC.h"

	void io_checkResetToDefault();
	void io_init();
	void io_clearPin(UCHAR pin);
	void io_setPin(UCHAR pin);
	UCHAR io_getPin(UCHAR pin);
	UCHAR io_getPinStatus(UCHAR pin);

	void io_resetCPU(UCHAR resetPeripherals);
	void io_enableInterrupts();
	void io_disableInterrupts();

	void io_enableSingleMotor(UINT motor);
	void io_disableSingleMotor(UINT motor);

#endif
