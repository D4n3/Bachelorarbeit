/****************************************************
  Projekt: TMCM-STM

  Modul:   ADC.h
           Funktionen f�r den A/D-Wandler

  Datum:   18.8.2009 OK (reworked by ed)
*****************************************************/

#ifndef ADC_H_
#define ADC_H_

	#include "TMCM-STM.h"

	#define ADC_INVALID_VALUE 255

	void adc_init();
	void adc_setOffset(UINT channel, UINT offset);
	UINT adc_getADCOffset(UINT channel);
	UINT adc_getADCValue(UINT channel);

	// motor current measured by TMC603 with gain change
	void adc_setTMC603GainFlag(UCHAR enable);
	void adc_setExtSenseFlag(UCHAR enable);
	UCHAR adc_isTMC603GainChanged();
	void adc_clearTMC603GainChanged();
	void adc_checkTMC603Amplifier(int measuredMotorCurrent);
	UINT adc_getTMC603MeasuredBlockMotorCurrent(UCHAR actualUsedPhase);
	int adc_calcTMC603MotorCurrent(int motorCurrent, USHORT RdsOn);

#endif
