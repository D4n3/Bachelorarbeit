/*
 * TMCM-Variables.c
 *
 *  Created on: 17.08.2011
 *      Author: ed
 */
#include "TMCL-Variables.h"

int tmcl_variables_getUserVariable(int variable)
{
	if ((variable >= 0) && (variable < TMCL_RAM_USER_VARS))
		return TMCLUserVariable[variable];
	else
		return 0;
}
