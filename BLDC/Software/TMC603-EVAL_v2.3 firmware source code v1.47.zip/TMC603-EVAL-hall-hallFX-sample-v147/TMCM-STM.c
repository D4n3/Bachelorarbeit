/****************************************************
  Projekt: TMCM-STM

  Modul:   TMCM-STM.c
           Hauptprogramm f�r BLDC-Module mit dem STM32

  Datum:   25.5.2009 OK (updated by ed)
*****************************************************/

#include "TMCM-STM.h"
#include "Globals-STM.h"
#include "UART.h"
#include "IO.h"
#include "SPI-STM.h"
#include "BLDC-STM.h"
#include "SysTick.h"
#include "ADC.h"
#include "Eeprom.h"
#include "USB-STM.h"
#include "UserFunctions.h"

/*******************************************************************************
* Function Name  : RCC_Configuration
* Description    : Configures the different system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static void RCC_Configuration(void)
{
  ErrorStatus HSEStartUpStatus;

  /* RCC system reset(for debug purpose) */
  RCC_DeInit();
  ExtClockFlag=FALSE;

  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if(HSEStartUpStatus == SUCCESS)
  {
    /* Enable Prefetch Buffer */
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

    /* Flash 2 wait state */
    FLASH_SetLatency(FLASH_Latency_2);

    /* HCLK = SYSCLK */
    RCC_HCLKConfig(RCC_SYSCLK_Div1);

    /* PCLK2 = HCLK */
    RCC_PCLK2Config(RCC_HCLK_Div1);

    /* PCLK1 = HCLK/2 */
    RCC_PCLK1Config(RCC_HCLK_Div2);

    /* PLLCLK = 8MHz * 9 = 72 MHz */
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

    /* Enable PLL */
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
    ExtClockFlag=TRUE;
  }

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
}

/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures Vector Table base location.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static void NVIC_Configuration(void)
{
#ifdef  VECT_TAB_RAM
  /* Set the Vector Table base location at 0x20000000 */
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);
#else  /* VECT_TAB_FLASH  */
  #if defined(BOOTLOADER)
  //Set the vector table base location at 0x08004000 (right after the TMCM boot loader)
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x4000);
  #else
  /* Set the Vector Table base location at 0x08000000 */
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);
  #endif
#endif
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
}

int main(void)
{
	// configure system clock
	RCC_Configuration();

	// configure NVIC
	NVIC_Configuration();

	// set usb interrupt vector
	USBInterface=TRUE;
	CanRx0UsbLpIrqVector = usb_stm_ISTR;

	io_enableInterrupts();

	// initialize periphery
	io_init();
	spi_stm_init();
	adc_init();
	eeprom_init();
	systick_stm_init();
	io_checkResetToDefault();

#if defined(UART_INTERFACE)
	uart_init(ModuleConfig.Baudrate);
	uart_setTransmitDelay(ModuleConfig.TelegramPauseTime);
#endif

#if defined(USB_INTERFACE)
	 USB_ENABLE();
	if(USBInterface)
		usb_stm_initUSB();
#endif

	// initialize software
	bldc_stm_init();
	tmcl_stm_init();
	userfunctions_init();

	// main control loop
	for(;;)
	{
		RESET_WATCHDOG();
		tmcl_stm_processCommand();
		bldc_stm_processBLDC();
		bldc_stm_checkTMC603();
		userfunctions_Appl();
	}
}
