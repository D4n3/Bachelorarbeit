/****************************************************
  Projekt: TMCM-STM

  Modul:   ADC.c
           Funktionen f�r den A/D-Wandler

  Datum:   18.8.2009 OK (reworked by ed)
*****************************************************/

#include "ADC.h"

#define ADC1_DR_Address    ((u32)0x4001244C)
static volatile USHORT ADCValue[7];	// array for analog values (filled by DMA)
static USHORT ADCOffset[7];   		// array for the zero offsets of the analog values
UCHAR TMC603GainFlag;				// TRUE if HIGH_SENSE, FALSE if LOW_SENSE
UCHAR TMC603GainChanged;      		// TRUE if current gain had been changed
UCHAR ExtSenseFlag;					// TRUE if extern sense resistors are used

/* initialize the A/D converter */
void adc_init()
{
    // Init module specific ADC pins. Use this function to prevent defines for every module here!
	tmcm_initModuleSpecificADC();

	// enable clock for ADC and DMA
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

	// DMA configuration
	DMA_InitTypeDef DMAInit;
	DMA_DeInit(DMA1_Channel1);
	DMAInit.DMA_PeripheralBaseAddr = ADC1_DR_Address;
	DMAInit.DMA_MemoryBaseAddr = (UINT)ADCValue;
	DMAInit.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMAInit.DMA_BufferSize = 7;
	DMAInit.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMAInit.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMAInit.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMAInit.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMAInit.DMA_Mode = DMA_Mode_Circular;
	DMAInit.DMA_Priority = DMA_Priority_High;
	DMAInit.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel1, &DMAInit);

	// enable DMA
	DMA_Cmd(DMA1_Channel1, ENABLE);

	// ADC configuration
	ADC_InitTypeDef ADCInit;
	ADCInit.ADC_Mode = ADC_Mode_Independent;
	ADCInit.ADC_ScanConvMode = ENABLE;
	ADCInit.ADC_ContinuousConvMode = DISABLE;					// DISABLE: every scan on demand (timed with the pwm timer)
	ADCInit.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADCInit.ADC_DataAlign = ADC_DataAlign_Right;
	ADCInit.ADC_NbrOfChannel = 7;
	ADC_Init(ADC1, &ADCInit);

	ADC_RegularChannelConfig(ADC1, ADC_CH_RANK1, 1, ADC_SampleTime_28Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_CH_RANK2, 2, ADC_SampleTime_28Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_CH_RANK3, 3, ADC_SampleTime_28Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_CH_RANK4, 4, ADC_SampleTime_28Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_CH_RANK5, 5, ADC_SampleTime_28Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_CH_RANK6, 6, ADC_SampleTime_28Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_CH_RANK7, 7, ADC_SampleTime_28Cycles5);
	ADC_ITConfig(ADC1, ADC_IT_EOC|ADC_IT_AWD|ADC_IT_JEOC, DISABLE);

	// enable ADC-DMA
	ADC_DMACmd(ADC1, ENABLE);

	// enable ADC1
	ADC_Cmd(ADC1, ENABLE);

	// calibrate ADC1 automatically
	ADC_ResetCalibration(ADC1);
	while(ADC_GetResetCalibrationStatus(ADC1));

	ADC_StartCalibration(ADC1);
	while(ADC_GetCalibrationStatus(ADC1));
}

/* get adc value(0..4095) of a channel(0..6) */
UINT adc_getADCValue(UINT channel)
{
	return ADCValue[channel];
}

/* set the adc zero offset(0..4095) of a channel(0..6) */
void adc_setOffset(UINT channel, UINT offset)
{
	ADCOffset[channel] = offset;
}

/* get adc offset(0..4095) of a channel (0..6) */
UINT adc_getADCOffset(UINT channel)
{
	return ADCOffset[channel];
}

/* get motor current in block commutation mode*/
UINT adc_getTMC603MeasuredBlockMotorCurrent(UCHAR actualUsedPhase)
{
	return ADCOffset[actualUsedPhase] - ADCValue[actualUsedPhase];
}

/* monitor measured current and switch the gain factor if necessary */
void adc_checkTMC603Amplifier(int measuredMotorCurrent)
{
	switch(TMC603GainFlag)
	{
		case TRUE:   // actual gain factor A=20.8
			//0...2047
			if (abs(measuredMotorCurrent) > 1800)
			{
				//Neuer Verst�rkungsfaktor A=4.82
				ENABLE_LOW_SENSE();
				TMC603GainFlag = FALSE;
				TMC603GainChanged = TRUE;
			}
			break;
		case FALSE:  // actual gain factor A=4.82
			//2047...8838
			if (abs(measuredMotorCurrent) < 200)
			{
				//Neuer Verst�rkungsfaktor A=20.8
				ENABLE_HIGH_SENSE();
				TMC603GainFlag = TRUE;
				TMC603GainChanged = TRUE;
			}
			break;
	}
}

/*******************************************************************
 Funktion: calc actual motor current [mA]
 Zweck: Abfragen des aktuell flie�enden Motorstroms (in mA).
          Der Sense-Widerstand wird als reziproker Wert (Leitwert)
          angegeben (Bsp. R=0.005Ohm -> G=200S), um die Berechnung
          ohne Float durchf�hren zu k�nnen und trotzdem eine hohe
          Genauigkeit zu erzielen. Der Verstr�rkungsfaktor (Gain)
          wird mit dem Faktor 100 multiipliziert (Bsp. A=20 -> 2000)
          und als A*100 angegeben. Um den Faktor 100 wieder
          anzuziehen, dient die Zahl 100 in der Berechnung. Die Zahl
          1241 dient als Normierungsfaktor zwischen der Aufl�sung
          des ADCs (12Bit) und der Referenzspannung (+3.3V). Mit der
          Zahl 1000 wird das Ergebnis in der Einheit mA angegeben.
********************************************************************/
int adc_calcTMC603MotorCurrent(int measuredCurrent, USHORT RdsOn)
{
	// select sense resistors
    int currentSense = (ExtSenseFlag) ? CURRENT_SENSE_EXT : (RdsOn==0) ? CURRENT_SENSE_INT : RdsOn;

    // select gain factor
    int currentGain = (TMC603GainFlag) ? CURRENT_GAIN_HIGH : CURRENT_GAIN_LOW;

    return ((measuredCurrent*currentSense*1000)/1241)*100/currentGain;
}

UCHAR adc_isTMC603GainChanged()
{
	return TMC603GainChanged;
}

void adc_clearTMC603GainChanged()
{
	TMC603GainChanged = FALSE;
}

void adc_setTMC603GainFlag(UCHAR enable)
{
	TMC603GainFlag = enable;
}

void adc_setExtSenseFlag(UCHAR enable)
{
	ExtSenseFlag = enable;
}
