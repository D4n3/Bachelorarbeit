/****************************************************
  Projekt: TMCM-STM

  Modul:   SPI-STM.h
           SPI-Funktionen

  Datum:   26.5.2009 OK (updated by ed)
*****************************************************/

#ifndef SPI_STM_H_
#define SPI_STM_H_

	#include "TMCM-STM.h"

	void spi_stm_init();
	UCHAR spi_stm_readWrite(UCHAR DeviceNumber, UCHAR Data, UCHAR LastTransfer);

#endif
