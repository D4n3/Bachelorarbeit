/****************************************************
  Projekt: TMCM-STM

  Modul:   IO.c
           I/O-Funktionen

  Datum:   26.5.2009 OK (reworked by ed)
*****************************************************/

#include "IO.h"

/* initialize I/O-ports*/
void io_init()
{
	// Init module specific IO pins. Use this function to prevent defines for every module here!
	ResetToFactoryDefaultRequested = tmcm_initModuleSpecificIO();
}

/* check whether a reset to factory default was requested, toggle the LEDs continuously */
void io_checkResetToDefault()
{
	volatile UINT i;

	if(ResetToFactoryDefaultRequested)
	{
		for(;;)
		{
			RESET_WATCHDOG();
			LED_TEMP_ON();
			LED_OVC_OFF();
			for(i=0; i<200000; i++);
			LED_TEMP_OFF();
			LED_OVC_ON();
			for(i=0; i<200000; i++);
		}
	}
}

/* clear output pin (0..7) */
void io_clearPin(UCHAR pin)
{
	tmcm_clearModuleSpecificIOPin(pin);
}

/* set output pin (0..7) */
void io_setPin(UCHAR pin)
{
	tmcm_setModuleSpecificIOPin(pin);
}

/* read the digital input (pin: 0..7) (result: 0/1) */
UCHAR io_getPin(UCHAR pin)
{
	return tmcm_getModuleSpecificIOPin(pin);
}

/* read the pin status (pin: 0..8) (result: 0/1) */
UCHAR io_getPinStatus(UCHAR pin)
{
	return tmcm_getModuleSpecificIOPinStatus(pin);
}

/* reset cpu with or without peripherals */
void io_resetCPU(UCHAR resetPeripherals)
{
	if(resetPeripherals)
		NVIC_GenerateSystemReset();
	else
		NVIC_GenerateCoreReset();
}

/* enable interrupts globally */
void io_enableInterrupts(void)
{
	asm volatile("CPSIE I\n");
}

/* disable interrupts globally */
void io_disableInterrupts(void)
{
	asm volatile("CPSID I\n");
}

/* enable a single motor (if disabled before by io_disableSingleMotor)*/
/* (only for CANopen support of the 3-axis modules) */
void io_enableSingleMotor(UINT motor)
{
	motor = 0;
	ENABLE_DRIVER();
}

/* disable single motor */
/* (only for CANopen support of the 3-axis modules) */
void io_disableSingleMotor(UINT motor)
{
	motor = 0;
	DISABLE_DRIVER();
}
