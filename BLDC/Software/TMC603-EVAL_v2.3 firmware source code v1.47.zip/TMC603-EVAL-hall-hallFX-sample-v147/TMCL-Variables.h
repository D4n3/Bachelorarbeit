/*
 * TMCM-Variables.h
 *
 *  Created on: 17.08.2011
 *      Author: ed
 */

#ifndef TMCL_VARIABLES_H_
#define TMCL_VARIABLES_H_

	#include "TMCL-Defines.h"

	int TMCLUserVariable[TMCL_RAM_USER_VARS];
	UCHAR TMCLReplyFormat;

	int tmcl_variables_getUserVariable(int variable);

#endif /* TMCL_VARIABLES_H_ */
