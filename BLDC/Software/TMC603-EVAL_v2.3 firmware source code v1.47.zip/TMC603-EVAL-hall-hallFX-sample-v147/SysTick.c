/****************************************************
  Projekt: TMCM-STM

  Modul:   SysTick.c
           Systick-Timer f�r 1ms-Takt

  Datum:   17.8.2009 OK (updated by ed)
*****************************************************/

#include "SysTick.h"

#define SYSTICK_PRE_EMPTION_PRIORITY 3
#define SYSTICK_SUB_PRIORITY 0

static volatile UINT sysTickTimer = 0;
static volatile UCHAR sysTickDivFlag = 0;
extern volatile UINT pidRegulationTickTimer;
extern volatile UINT currentRefreshTickTime;
extern volatile UINT ChangeCommModeDelay;
extern volatile UCHAR UART3TimeoutFlag;
extern volatile UINT UART3TimeoutTimer;
extern volatile UINT UART3TransmitDelayTimer;

/* handler for SysTick interrupt */
void SysTickHandler(void)
{
	if(sysTickDivFlag)
	{
		// increment 1ms timer for systick_stm_getTimer
		sysTickTimer++;

		// different 1ms timer for the BLDC-Modul
		pidRegulationTickTimer++;
		currentRefreshTickTime++;
		ChangeCommModeDelay++;

		// decrease timer for RS485 delay
#if defined(UART_INTERFACE)
		if(UART3TransmitDelayTimer > 0)
			UART3TransmitDelayTimer--;
#endif

		sysTickDivFlag=0;
	}
	else
	{
		sysTickDivFlag=1;
	}

	// decrease timer for RS232/RS485 timeout with 0,5ms clock
#if defined(UART_INTERFACE)
	if(UART3TimeoutTimer > 0)
	{
		UART3TimeoutTimer--;
		if(UART3TimeoutTimer==0)
			UART3TimeoutFlag=TRUE;
	}
#endif
}

/* initialize SysTick timer */
void systick_stm_init()
{
	/* Select AHB clock(HCLK) as SysTick clock source */
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);
	/* SysTick interrupt each 500usec with Core clock equal to 72MHz */
	SysTick_SetReload(36000);
	/* Enable SysTick Counter */
	SysTick_CounterCmd(SysTick_Counter_Enable);

	NVIC_SystemHandlerPriorityConfig(SystemHandler_SysTick, SYSTICK_PRE_EMPTION_PRIORITY, SYSTICK_SUB_PRIORITY);
	/* Enable SysTick interrupt */
	SysTick_ITConfig(ENABLE);
}

/* get system timer in [ms] */
UINT systick_stm_getTimer()
{
	return sysTickTimer;
}
